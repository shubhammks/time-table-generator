#!/usr/bin/env python3
"""
Generate a timetable using the sample data created.
"""

import sys
from pathlib import Path

# Add the project root to the Python path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from app import models
from app.database import SessionLocal
from app.services.generator import TimetableGenerator
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def generate_timetable():
    """Generate timetable using the sample data."""
    db = SessionLocal()
    
    try:
        logger.info("Starting timetable generation...")
        
        # Get the sample data IDs
        dept = db.query(models.Department).filter(models.Department.name == "Computer Science & Engineering").first()
        class_obj = db.query(models.Class).filter(models.Class.name == "Second Year").first()
        
        if not dept or not class_obj:
            logger.error("Sample data not found. Please run create_sample_data.py first.")
            return
        
        logger.info(f"Generating timetable for Department: {dept.name}, Class: {class_obj.name}")
        
        # Create generator
        generator = TimetableGenerator(db)
        
        # Create generation request
        from app.services.generator import GenerationRequest
        
        request = GenerationRequest(
            name="Sample Timetable - Second Year",
            class_id=class_obj.id,
            department_id=dept.id,
            mode="college",
            user_id=1,  # Coordinator user ID
            options={
                "balance_teacher_workload": True,
                "minimize_gaps": True,
                "allow_conflicts": False,
                "ensure_same_floor": True,
                "lab_consecutive_periods": True,
                "max_daily_hours": 8,
                "allow_subject_twice_in_day": False
            }
        )
        
        # Generate timetable
        result = generator.generate_timetable(request)
        
        if result.success:
            logger.info("✅ Timetable generated successfully!")
            logger.info(f"Timetable ID: {result.timetable_id}")
            logger.info(f"Generated timetable with ID: {result.timetable_id}")
            
            # Show some sample entries
            logger.info("\nSample schedule entries:")
            for i, entry in enumerate(result.diagnostics[:5]):
                logger.info(f"  {i+1}. {entry}")
            
            if len(result.diagnostics) > 5:
                logger.info(f"  ... and {len(result.diagnostics) - 5} more entries")
                
        else:
            logger.error("❌ Timetable generation failed!")
            logger.error(f"Message: {result.message}")
            for diagnostic in result.diagnostics:
                logger.error(f"  - {diagnostic.message}")
                
    except Exception as e:
        logger.error(f"Error generating timetable: {str(e)}")
        raise
    finally:
        db.close()

if __name__ == "__main__":
    generate_timetable()
