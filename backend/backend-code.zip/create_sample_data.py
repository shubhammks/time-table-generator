#!/usr/bin/env python3
"""
Create sample data for timetable generation with exact requirements:
- 1 department
- 4 teachers  
- 4 subjects (3 lecture+lab, 1 tutorial)
- 1 class with 2 divisions
- 3 batches per division (6 total)
- Rooms: 3 labs, 3 classrooms, 2 tutorial rooms
"""

import sys
from pathlib import Path

# Add the project root to the Python path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from sqlalchemy.orm import Session
from app import models
from app.database import SessionLocal, engine
from app.auth import hash_password
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_sample_data():
    """Create sample data matching the requirements."""
    # Create tables
    models.Base.metadata.create_all(bind=engine)
    
    # Create database session
    db = SessionLocal()
    
    try:
        logger.info("Creating sample data...")
        
        # 1. Create coordinator user (skip if exists)
        existing_user = db.query(models.User).filter(models.User.email == "coordinator@example.com").first()
        if not existing_user:
            coordinator = models.User(
                email="coordinator@example.com",
                password_hash="coord123",  # Simple password for demo
                role=models.UserRole.coordinator
            )
            db.add(coordinator)
            db.flush()
            logger.info("Created coordinator user")
        else:
            logger.info("Coordinator user already exists")
        
        # 2. Create 1 department
        dept = models.Department(
            name="Computer Science & Engineering",
            type=models.DepartmentType.college
        )
        db.add(dept)
        db.flush()
        logger.info(f"Created department: {dept.name}")
        
        # 3. Create 4 teachers
        teachers_data = [
            {"name": "Dr. Alice Sharma", "email": "alice@example.com", "phone": "9876543210"},
            {"name": "Prof. Bharat Iyer", "email": "bharat@example.com", "phone": "9876543211"},
            {"name": "Dr. Chitra Naik", "email": "chitra@example.com", "phone": "9876543212"},
            {"name": "Prof. Deepak Joshi", "email": "deepak@example.com", "phone": "9876543213"}
        ]
        
        teachers = []
        for teacher_data in teachers_data:
            teacher = models.Teacher(
                department_id=dept.id,
                **teacher_data
            )
            db.add(teacher)
            teachers.append(teacher)
        db.flush()
        logger.info(f"Created {len(teachers)} teachers")
        
        # 4. Create 1 class (Second Year)
        class_obj = models.Class(
            name="Second Year",
            number_of_divisions=2,
            department_id=dept.id
        )
        db.add(class_obj)
        db.flush()
        logger.info(f"Created class: {class_obj.name}")
        
        # 5. Create 2 divisions
        divisions = []
        for i in range(2):
            division = models.Division(
                name=f"SE-{chr(65 + i)}",  # SE-A, SE-B
                class_id=class_obj.id
            )
            db.add(division)
            divisions.append(division)
        db.flush()
        logger.info(f"Created {len(divisions)} divisions")
        
        # 6. Create 3 batches per division (6 total)
        batches = []
        for division in divisions:
            for i in range(3):
                batch = models.Batch(
                    number=i + 1,
                    division_id=division.id
                )
                db.add(batch)
                batches.append(batch)
        db.flush()
        logger.info(f"Created {len(batches)} batches")
        
        # 7. Create 4 subjects (3 lecture+lab, 1 tutorial)
        subjects_data = [
            {"name": "Data Structures", "type": models.SubjectType.lecture, "hours_per_week": 3, "class_id": class_obj.id},
            {"name": "Database Systems", "type": models.SubjectType.lecture, "hours_per_week": 3, "class_id": class_obj.id},
            {"name": "Software Engineering", "type": models.SubjectType.lecture, "hours_per_week": 2, "class_id": class_obj.id},
            {"name": "Applied Mathematics", "type": models.SubjectType.tutorial, "hours_per_week": 1, "class_id": class_obj.id}
        ]
        
        subjects = []
        for subject_data in subjects_data:
            subject = models.Subject(**subject_data)
            db.add(subject)
            subjects.append(subject)
        db.flush()
        
        # Create lab subjects for the 3 lecture subjects
        lab_subjects = []
        for i in range(3):
            lab_subject = models.Subject(
                name=f"{subjects[i].name} Lab",
                type=models.SubjectType.lab,
                hours_per_week=2,
                class_id=class_obj.id
            )
            db.add(lab_subject)
            lab_subjects.append(lab_subject)
        db.flush()
        
        all_subjects = subjects + lab_subjects
        logger.info(f"Created {len(all_subjects)} subjects ({len(subjects)} lectures, {len(lab_subjects)} labs, 1 tutorial)")
        
        # 8. Create rooms: 3 labs, 3 classrooms, 2 tutorial rooms
        rooms_data = [
            # Classrooms
            {"room_number": "D301", "type": models.RoomType.classroom, "capacity": 60, "floor": 3, "department_id": dept.id},
            {"room_number": "D302", "type": models.RoomType.classroom, "capacity": 60, "floor": 3, "department_id": dept.id},
            {"room_number": "D303", "type": models.RoomType.classroom, "capacity": 60, "floor": 3, "department_id": dept.id},
            # Labs
            {"room_number": "D351", "type": models.RoomType.lab, "capacity": 30, "floor": 3, "department_id": dept.id},
            {"room_number": "D352", "type": models.RoomType.lab, "capacity": 30, "floor": 3, "department_id": dept.id},
            {"room_number": "D353", "type": models.RoomType.lab, "capacity": 30, "floor": 3, "department_id": dept.id},
            # Tutorial rooms
            {"room_number": "D321", "type": models.RoomType.tutorial, "capacity": 30, "floor": 3, "department_id": dept.id},
            {"room_number": "D322", "type": models.RoomType.tutorial, "capacity": 30, "floor": 3, "department_id": dept.id}
        ]
        
        rooms = []
        for room_data in rooms_data:
            room = models.Room(**room_data)
            db.add(room)
            rooms.append(room)
        db.flush()
        logger.info(f"Created {len(rooms)} rooms (3 classrooms, 3 labs, 2 tutorial rooms)")
        
        # 9. Create teacher-subject assignments for each division
        assignments = []
        for division in divisions:
            # Assign teachers to subjects for this division
            for i, subject in enumerate(subjects):
                teacher = teachers[i % len(teachers)]  # Cycle through teachers
                assignment = models.SubjectTeacher(
                    subject_id=subject.id,
                    teacher_id=teacher.id,
                    division_id=division.id
                )
                db.add(assignment)
                assignments.append(assignment)
            
            # Assign teachers to lab subjects for this division
            for i, lab_subject in enumerate(lab_subjects):
                teacher = teachers[i % len(teachers)]  # Same teacher as lecture
                assignment = models.SubjectTeacher(
                    subject_id=lab_subject.id,
                    teacher_id=teacher.id,
                    division_id=division.id
                )
                db.add(assignment)
                assignments.append(assignment)
        
        db.flush()
        logger.info(f"Created {len(assignments)} teacher-subject assignments")
        
        # 10. Create timetable slots configuration
        slots_data = []
        for day_idx in range(6):  # Monday to Saturday
            for period_idx in range(8):  # 8 periods per day
                start_hour = 9 + (period_idx // 2)
                start_minute = 0 if period_idx % 2 == 0 else 50
                end_hour = start_hour if period_idx % 2 == 0 else start_hour + 1
                end_minute = 50 if period_idx % 2 == 0 else 40
                
                # Handle breaks
                is_break = False
                break_type = None
                if period_idx == 2:  # Short break after 2nd period
                    is_break = True
                    break_type = "short_break"
                    start_hour = 10
                    start_minute = 40
                    end_hour = 10
                    end_minute = 50
                elif period_idx == 5:  # Lunch break after 5th period
                    is_break = True
                    break_type = "lunch_break"
                    start_hour = 13
                    start_minute = 0
                    end_hour = 13
                    end_minute = 50
                
                start_time = f"{start_hour:02d}:{start_minute:02d}"
                end_time = f"{end_hour:02d}:{end_minute:02d}"
                
                slot = models.TimetableSlots(
                    department_id=dept.id,
                    day_index=day_idx,
                    period_index=period_idx,
                    start_time=start_time,
                    end_time=end_time,
                    is_break=is_break,
                    break_type=break_type,
                    is_active=True
                )
                db.add(slot)
                slots_data.append(slot)
        
        db.flush()
        logger.info(f"Created {len(slots_data)} timetable slots")
        
        # Commit all changes
        db.commit()
        
        logger.info("✅ Sample data created successfully!")
        logger.info(f"Department ID: {dept.id}")
        logger.info(f"Class ID: {class_obj.id}")
        logger.info(f"Division IDs: {[d.id for d in divisions]}")
        logger.info(f"Teacher IDs: {[t.id for t in teachers]}")
        logger.info(f"Subject IDs: {[s.id for s in all_subjects]}")
        logger.info(f"Room IDs: {[r.id for r in rooms]}")
        
        return {
            "department_id": dept.id,
            "class_id": class_obj.id,
            "division_ids": [d.id for d in divisions],
            "teacher_ids": [t.id for t in teachers],
            "subject_ids": [s.id for s in all_subjects],
            "room_ids": [r.id for r in rooms]
        }
        
    except Exception as e:
        logger.error(f"Error creating sample data: {str(e)}")
        db.rollback()
        raise
    finally:
        db.close()

if __name__ == "__main__":
    create_sample_data()
