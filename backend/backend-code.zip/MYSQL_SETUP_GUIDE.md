# MySQL Setup Guide for Windows

This guide will help you set up MySQL on your Windows machine for the Timetable Management System.

## Option 1: MySQL Installer (Recommended)

### Step 1: Download MySQL Installer
1. Go to [MySQL Downloads](https://dev.mysql.com/downloads/installer/)
2. Download **MySQL Installer for Windows** (mysql-installer-web-community-8.0.xx.x.msi)
3. You don't need to create an Oracle account - click "No thanks, just start my download"

### Step 2: Install MySQL
1. Run the downloaded installer
2. Choose **"Developer Default"** setup type
3. Click "Next" through the requirements check
4. Click "Execute" to download and install components
5. When prompted, set a **root password** (remember this!)
6. Keep the default port **3306**
7. Complete the installation

### Step 3: Verify Installation
Open Command Prompt and run:
```cmd
mysql --version
```

You should see something like: `mysql  Ver 8.0.xx for Win64`

## Option 2: Portable MySQL (Alternative)

If you prefer a portable installation:

1. Download MySQL Community Server from [MySQL Downloads](https://dev.mysql.com/downloads/mysql/)
2. Extract to a folder like `C:\mysql`
3. Create a `my.ini` configuration file in the MySQL folder
4. Initialize the database and set up the service manually

## Option 3: Using XAMPP (Easiest for Development)

### Step 1: Download XAMPP
1. Go to [XAMPP Downloads](https://www.apachefriends.org/download.html)
2. Download XAMPP for Windows
3. Install XAMPP to `C:\xampp`

### Step 2: Start MySQL
1. Open XAMPP Control Panel
2. Click "Start" next to MySQL
3. MySQL will be available on port 3306

### Step 3: Access MySQL
- **phpMyAdmin**: http://localhost/phpmyadmin
- **Command Line**: Use XAMPP shell or `C:\xampp\mysql\bin\mysql.exe`

## Setting Up the Timetable Database

### Option A: Using the Setup Script (Recommended)

1. Open Command Prompt in the `backend` directory
2. Activate your virtual environment:
   ```cmd
   venv\Scripts\activate
   ```
3. Run the setup script:
   ```cmd
   python setup_mysql.py
   ```
4. Follow the prompts to enter your MySQL root credentials

### Option B: Manual Setup

1. Open MySQL Command Line Client or phpMyAdmin
2. Create the database:
   ```sql
   CREATE DATABASE timetable_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```
3. Create a user:
   ```sql
   CREATE USER 'timetable_user'@'localhost' IDENTIFIED BY 'timetable_pass';
   GRANT ALL PRIVILEGES ON timetable_db.* TO 'timetable_user'@'localhost';
   FLUSH PRIVILEGES;
   ```

## Troubleshooting

### Common Issues:

#### 1. "Access denied for user" error
- Make sure you're using the correct password
- Check if the user has proper privileges
- Try connecting as root first

#### 2. "Can't connect to MySQL server" error
- Ensure MySQL service is running
- Check if port 3306 is not blocked by firewall
- Verify the host and port settings

#### 3. "Authentication plugin 'caching_sha2_password' cannot be loaded"
- This happens with newer MySQL versions
- Solution: Change the authentication method:
  ```sql
  ALTER USER 'timetable_user'@'localhost' IDENTIFIED WITH mysql_native_password BY 'timetable_pass';
  ```

### Windows Services

To manage MySQL as a Windows service:

```cmd
# Start MySQL service
net start mysql80

# Stop MySQL service  
net stop mysql80

# Check service status
sc query mysql80
```

### Testing Connection

Test your connection using Python:

```python
import pymysql

try:
    connection = pymysql.connect(
        host='localhost',
        port=3306,
        user='timetable_user',
        password='timetable_pass',
        database='timetable_db'
    )
    print("✅ Connection successful!")
    connection.close()
except Exception as e:
    print(f"❌ Connection failed: {e}")
```

## Environment Configuration

Ensure your `.env` file in the backend directory contains:

```env
DATABASE_URL=mysql+pymysql://timetable_user:timetable_pass@localhost:3306/timetable_db
```

## Next Steps

Once MySQL is set up:

1. Run the database setup script: `python setup_mysql.py`
2. Start the FastAPI server: `uvicorn app.main:app --reload`
3. The API will be available at: http://localhost:8000
4. API documentation: http://localhost:8000/docs

## Need Help?

- MySQL Documentation: https://dev.mysql.com/doc/
- XAMPP Documentation: https://www.apachefriends.org/faq_windows.html
- Common MySQL errors: https://dev.mysql.com/doc/mysql-errors/8.0/en/
