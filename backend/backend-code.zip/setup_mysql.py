#!/usr/bin/env python3
"""
MySQL Database Setup Script for Timetable Management System

This script will:
1. Create the MySQL database
2. Create a database user 
3. Set up the initial database schema
4. Run any pending migrations

Prerequisites:
- MySQL server running on localhost:3306
- Root access to MySQL server

Usage:
    python setup_mysql.py
"""

import pymysql
import os
import sys
from getpass import getpass

def create_database_and_user():
    """Create the database and user for timetable system"""
    
    print("MySQL Database Setup for Timetable Management System")
    print("=" * 50)
    
    # Get MySQL root credentials
    mysql_host = input("MySQL Host (default: localhost): ").strip() or "localhost"
    mysql_port = int(input("MySQL Port (default: 3306): ").strip() or "3306")
    mysql_root_user = input("MySQL Root Username (default: root): ").strip() or "root"
    mysql_root_password = getpass("MySQL Root Password: ")
    
    # Database configuration
    db_name = "timetable_db"
    db_user = "timetable_user"
    db_password = "timetable_pass"
    
    try:
        # Connect to MySQL server
        print(f"\n🔌 Connecting to MySQL server at {mysql_host}:{mysql_port}...")
        connection = pymysql.connect(
            host=mysql_host,
            port=mysql_port,
            user=mysql_root_user,
            password=mysql_root_password,
            charset='utf8mb4'
        )
        
        cursor = connection.cursor()
        
        # Create database
        print(f"📊 Creating database '{db_name}'...")
        cursor.execute(f"CREATE DATABASE IF NOT EXISTS {db_name} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
        
        # Create user and grant privileges
        print(f"👤 Creating user '{db_user}' and granting privileges...")
        cursor.execute(f"CREATE USER IF NOT EXISTS '{db_user}'@'localhost' IDENTIFIED BY '{db_password}'")
        cursor.execute(f"GRANT ALL PRIVILEGES ON {db_name}.* TO '{db_user}'@'localhost'")
        cursor.execute("FLUSH PRIVILEGES")
        
        # Verify database creation
        cursor.execute("SHOW DATABASES")
        databases = cursor.fetchall()
        if any(db_name in db for db in databases):
            print(f"✅ Database '{db_name}' created successfully!")
        else:
            print(f"❌ Failed to create database '{db_name}'")
            return False
            
        cursor.close()
        connection.close()
        
        print(f"✅ MySQL setup completed successfully!")
        print("\nDatabase Configuration:")
        print(f"  Host: {mysql_host}")
        print(f"  Port: {mysql_port}")
        print(f"  Database: {db_name}")
        print(f"  Username: {db_user}")
        print(f"  Password: {db_password}")
        
        # Update .env file
        update_env_file(mysql_host, mysql_port, db_name, db_user, db_password)
        
        return True
        
    except Exception as e:
        print(f"❌ Error setting up MySQL: {e}")
        return False

def update_env_file(host, port, db_name, db_user, db_password):
    """Update the .env file with database configuration"""
    
    env_path = ".env"
    database_url = f"mysql+pymysql://{db_user}:{db_password}@{host}:{port}/{db_name}"
    
    try:
        # Read existing .env file
        env_lines = []
        if os.path.exists(env_path):
            with open(env_path, 'r') as f:
                env_lines = f.readlines()
        
        # Update DATABASE_URL
        database_url_found = False
        for i, line in enumerate(env_lines):
            if line.startswith('DATABASE_URL='):
                env_lines[i] = f'DATABASE_URL={database_url}\n'
                database_url_found = True
                break
        
        # Add DATABASE_URL if not found
        if not database_url_found:
            env_lines.append(f'DATABASE_URL={database_url}\n')
        
        # Write updated .env file
        with open(env_path, 'w') as f:
            f.writelines(env_lines)
        
        print(f"✅ Updated {env_path} with database configuration")
        
    except Exception as e:
        print(f"⚠️  Warning: Could not update .env file: {e}")
        print(f"Please manually update your .env file with:")
        print(f"DATABASE_URL={database_url}")

def test_connection():
    """Test the database connection"""
    
    from app.database import engine
    from sqlalchemy import text
    
    try:
        print("\n🧪 Testing database connection...")
        with engine.connect() as connection:
            result = connection.execute(text("SELECT 1"))
            if result.fetchone():
                print("✅ Database connection successful!")
                return True
    except Exception as e:
        print(f"❌ Database connection failed: {e}")
        return False

def create_tables():
    """Create database tables using SQLAlchemy models"""
    
    try:
        print("\n📋 Creating database tables...")
        from app.database import Base, engine
        Base.metadata.create_all(bind=engine)
        print("✅ Database tables created successfully!")
        return True
    except Exception as e:
        print(f"❌ Error creating tables: {e}")
        return False

def main():
    """Main setup function"""
    
    print("Starting MySQL setup for Timetable Management System...\n")
    
    # Step 1: Create database and user
    if not create_database_and_user():
        print("❌ Setup failed at database creation step")
        sys.exit(1)
    
    # Step 2: Test connection
    if not test_connection():
        print("❌ Setup failed at connection test step")
        sys.exit(1)
    
    # Step 3: Create tables
    if not create_tables():
        print("❌ Setup failed at table creation step")
        sys.exit(1)
    
    print("\n🎉 MySQL setup completed successfully!")
    print("\nNext steps:")
    print("1. Start the FastAPI server: uvicorn app.main:app --reload")
    print("2. Access the API documentation at: http://localhost:8000/docs")
    print("3. Start the React frontend: npm start")
    
if __name__ == "__main__":
    main()
