#!/usr/bin/env python3
"""
Test script for concurrent batch scheduling functionality
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from sqlalchemy.orm import Session
from app.database import SessionLocal
from app import models
from app.services.generator import TimetableGenerator, GenerationRequest
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_concurrent_scheduling():
    """Test concurrent batch scheduling with the sample data"""
    db = SessionLocal()
    
    try:
        logger.info("Testing concurrent batch scheduling...")
        
        # Get the sample data
        dept = db.query(models.Department).filter(
            models.Department.name == "Computer Science & Engineering"
        ).first()
        
        if not dept:
            logger.error("Department not found")
            return
        
        class_obj = db.query(models.Class).filter(
            models.Class.department_id == dept.id
        ).first()
        
        if not class_obj:
            logger.error("Class not found")
            return
        
        division = db.query(models.Division).filter(
            models.Division.class_id == class_obj.id
        ).first()
        
        if not division:
            logger.error("Division not found")
            return
        
        batches = db.query(models.Batch).filter(
            models.Batch.division_id == division.id
        ).all()
        
        logger.info(f"Found {len(batches)} batches: {[f'A{batch.number}' for batch in batches]}")
        
        # Get subjects for this division
        subjects = db.query(models.Subject).join(
            models.SubjectTeacher
        ).filter(
            models.SubjectTeacher.division_id == division.id
        ).all()
        
        logger.info(f"Found {len(subjects)} subjects:")
        for subject in subjects:
            logger.info(f"  - {subject.name} ({subject.type.value})")
        
        # Create subject assignments
        subject_assignments = []
        for subject in subjects:
            # Get teacher for this subject
            teacher = db.query(models.Teacher).join(
                models.SubjectTeacher
            ).filter(
                models.SubjectTeacher.subject_id == subject.id,
                models.SubjectTeacher.division_id == division.id
            ).first()
            
            if teacher:
                from app.services.generator import SubjectAssignment
                subject_assignments.append(SubjectAssignment(
                    subject_id=subject.id,
                    teacher_id=teacher.id,
                    subject_type=subject.type.value,
                    subject_name=subject.name,
                    hours_per_week=subject.hours_per_week
                ))
        
        # Create generation request
        request = GenerationRequest(
            name="Concurrent Batch Test Timetable",
            class_id=class_obj.id,
            department_id=dept.id,
            mode="college",
            user_id=1,  # Coordinator user ID
            subject_assignments=subject_assignments,
            options={
                "balance_teacher_workload": True,
                "minimize_gaps": True,
                "allow_conflicts": False,
                "ensure_same_floor": True,
                "lab_consecutive_periods": True,
                "max_daily_hours": 8,
                "allow_subject_twice_in_day": False,
                "lab_duration_hours": 2,  # 2 hours for labs
                "tutorial_duration_hours": 1,  # 1 hour for tutorials
                "lecture_duration_hours": 1,  # 1 hour for lectures
            }
        )
        
        # Generate timetable
        generator = TimetableGenerator(db)
        result = generator.generate_timetable(request)
        
        if result.success:
            logger.info("✅ Timetable generated successfully!")
            logger.info(f"Timetable ID: {result.timetable_id}")
            logger.info(f"Message: {result.message}")
            
            # Get the generated timetable entries
            timetable = db.query(models.Timetable).filter(
                models.Timetable.id == result.timetable_id
            ).first()
            
            if timetable:
                schedule_entries = db.query(models.ScheduleEntry).filter(
                    models.ScheduleEntry.timetable_id == timetable.id
                ).all()
                
                logger.info(f"Generated {len(schedule_entries)} schedule entries")
                
                # Group by day and period to check for concurrent scheduling
                schedule_by_time = {}
                for entry in schedule_entries:
                    key = (entry.day_index, entry.period_index)
                    if key not in schedule_by_time:
                        schedule_by_time[key] = []
                    schedule_by_time[key].append(entry)
                
                # Check for concurrent batch scheduling
                concurrent_slots = []
                for (day, period), entries in schedule_by_time.items():
                    if len(entries) > 1:
                        concurrent_slots.append((day, period, entries))
                
                if concurrent_slots:
                    logger.info(f"🎯 Found {len(concurrent_slots)} concurrent time slots:")
                    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
                    for day, period, entries in concurrent_slots:
                        logger.info(f"  {days[day]}, Period {period}:")
                        for entry in entries:
                            subject = db.query(models.Subject).filter(
                                models.Subject.id == entry.subject_id
                            ).first()
                            teacher = db.query(models.Teacher).filter(
                                models.Teacher.id == entry.teacher_id
                            ).first()
                            room = db.query(models.Room).filter(
                                models.Room.id == entry.room_id
                            ).first()
                            batch = db.query(models.Batch).filter(
                                models.Batch.id == entry.batch_id
                            ).first() if entry.batch_id else None
                            
                            batch_info = f" (Batch A{batch.number})" if batch else ""
                            logger.info(f"    - {subject.name}{batch_info} | {teacher.name} | {room.room_number}")
                else:
                    logger.info("No concurrent time slots found")
                
                # Show sample entries
                logger.info("\nSample schedule entries:")
                for i, entry in enumerate(schedule_entries[:10]):
                    subject = db.query(models.Subject).filter(
                        models.Subject.id == entry.subject_id
                    ).first()
                    teacher = db.query(models.Teacher).filter(
                        models.Teacher.id == entry.teacher_id
                    ).first()
                    room = db.query(models.Room).filter(
                        models.Room.id == entry.room_id
                    ).first()
                    batch = db.query(models.Batch).filter(
                        models.Batch.id == entry.batch_id
                    ).first() if entry.batch_id else None
                    
                    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
                    batch_info = f" (Batch A{batch.number})" if batch else ""
                    logger.info(f"  {i+1}. {days[entry.day_index]}, Period {entry.period_index}: {subject.name}{batch_info} | {teacher.name} | {room.room_number}")
                
                if len(schedule_entries) > 10:
                    logger.info(f"  ... and {len(schedule_entries) - 10} more entries")
        
        else:
            logger.error("❌ Timetable generation failed!")
            logger.error(f"Message: {result.message}")
            for diagnostic in result.diagnostics:
                logger.error(f"  - {diagnostic.message}")
        
    except Exception as e:
        logger.error(f"Test failed: {str(e)}", exc_info=True)
    finally:
        db.close()

if __name__ == "__main__":
    test_concurrent_scheduling()
