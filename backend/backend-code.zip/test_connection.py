#!/usr/bin/env python3
"""
Simple database connection test script
"""

import sys
import os

# Add the current directory to Python path so we can import app modules
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_database_connection():
    """Test database connection"""
    try:
        print("Testing database connection...")
        
        # Import here to avoid issues if dependencies aren't installed
        from app.database import engine
        from sqlalchemy import text
        
        # Test connection
        with engine.connect() as connection:
            result = connection.execute(text("SELECT 1 as test"))
            row = result.fetchone()
            if row and row.test == 1:
                print("✅ Database connection successful!")
                return True
        
        print("❌ Database connection failed - no results returned")
        return False
        
    except ImportError as e:
        print(f"❌ Import error (install dependencies): {e}")
        return False
    except Exception as e:
        print(f"❌ Database connection failed: {e}")
        return False

def test_table_creation():
    """Test table creation"""
    try:
        print("Testing table creation...")
        
        from app.database import Base, engine
        from app import models
        
        # Create tables
        Base.metadata.create_all(bind=engine)
        print("✅ Tables created successfully!")
        return True
        
    except Exception as e:
        print(f"❌ Table creation failed: {e}")
        return False

def test_user_creation():
    """Test user creation"""
    try:
        print("Testing user creation...")
        
        from app.database import SessionLocal
        from app import models
        from app.auth import hash_password
        
        db = SessionLocal()
        
        # Check if test user exists
        existing_user = db.query(models.User).filter(
            models.User.email == "test@example.com"
        ).first()
        
        if existing_user:
            print("Test user already exists, skipping creation")
            db.close()
            return True
        
        # Create test user
        test_user = models.User(
            email="test@example.com",
            full_name="Test User",
            password_hash=hash_password("password123"),
            role=models.UserRole.teacher
        )
        
        db.add(test_user)
        db.commit()
        db.refresh(test_user)
        
        print(f"✅ Test user created successfully! ID: {test_user.id}")
        db.close()
        return True
        
    except Exception as e:
        print(f"❌ User creation failed: {e}")
        return False

def main():
    """Run all tests"""
    print("Database Connection and Setup Tests")
    print("=" * 40)
    
    # Test 1: Database connection
    if not test_database_connection():
        print("\n❌ Database connection failed. Please check:")
        print("1. MySQL server is running")
        print("2. Database 'timetable_db' exists")
        print("3. User 'timetable_user' has proper permissions")
        print("4. .env file has correct DATABASE_URL")
        return False
    
    # Test 2: Table creation
    if not test_table_creation():
        print("\n❌ Table creation failed. Please check:")
        print("1. Database user has CREATE privileges")
        print("2. SQLAlchemy models are properly defined")
        return False
    
    # Test 3: User creation
    if not test_user_creation():
        print("\n❌ User creation failed. Please check:")
        print("1. Database user has INSERT privileges")
        print("2. User model is properly configured")
        return False
    
    print("\n🎉 All tests passed! Database is ready for use.")
    print("\nNext steps:")
    print("1. Start the FastAPI server: uvicorn app.main:app --reload")
    print("2. Test API at: http://localhost:8000/docs")
    print("3. Start the React frontend: npm start")
    
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
