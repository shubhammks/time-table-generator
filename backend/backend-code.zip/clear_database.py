import os
import sys
from sqlalchemy.orm import Session
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import logging

# Add the parent directory to the sys.path to allow importing 'app'
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app import models
from app.config import settings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Database setup
DATABASE_URL = settings.DATABASE_URL
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def clear_all_data():
    """Clear all data from the database."""
    db = SessionLocal()
    try:
        logger.info("🗑️  Clearing all data from database...")
        
        # Delete in reverse order of dependencies
        tables_to_clear = [
            models.ScheduleEntry,
            models.TimetableSlots,
            models.Timetable,
            models.SubjectTeacher,
            models.Batch,
            models.Division,
            models.Class,
            models.Subject,
            models.Room,
            models.Teacher,
            models.Department,
            models.User
        ]
        
        for table in tables_to_clear:
            count = db.query(table).count()
            if count > 0:
                db.query(table).delete()
                logger.info(f"✅ Cleared {count} records from {table.__name__}")
            else:
                logger.info(f"ℹ️  No records found in {table.__name__}")
        
        db.commit()
        logger.info("🎉 Database cleared successfully!")
        
    except Exception as e:
        db.rollback()
        logger.error(f"❌ Error clearing database: {e}", exc_info=True)
        raise
    finally:
        db.close()

if __name__ == "__main__":
    clear_all_data()
