import os
import sys
from sqlalchemy.orm import Session
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import logging

# Add the parent directory to the sys.path to allow importing 'app'
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app import models
from app.config import settings
from app.auth import hash_password

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Database setup
DATABASE_URL = settings.DATABASE_URL
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def create_new_sample_data():
    """Create new sample data with correct durations: lecture/tutorial=1hr, lab=2hr"""
    db = SessionLocal()
    try:
        logger.info("🏗️  Creating new sample data with correct durations...")
        logger.info("📏 Duration Settings: Lecture/Tutorial = 1hr (60min), Lab = 2hr (120min)")

        # 1. Create coordinator user
        coordinator = models.User(
            email="coordinator@example.com",
            password_hash="coord123",
            role=models.UserRole.coordinator
        )
        db.add(coordinator)
        db.flush()
        logger.info("✅ Created coordinator user")

        # 2. Create departments
        departments_data = [
            {"name": "Computer Science & Engineering", "type": "college"},
            {"name": "Information Technology", "type": "college"},
            {"name": "Electronics & Communication", "type": "college"}
        ]
        
        departments = []
        for dept_data in departments_data:
            dept = models.Department(
                name=dept_data["name"],
                type=models.DepartmentType[dept_data["type"]]
            )
            db.add(dept)
            db.flush()
            departments.append(dept)
            logger.info(f"✅ Created department: {dept.name}")

        # 3. Create teachers for each department
        teachers_data = [
            # CSE Department Teachers
            {"name": "Dr. Alice Sharma", "email": "alice@cse.com", "phone": "9876543210", "dept": 0},
            {"name": "Prof. Bob Singh", "email": "bob@cse.com", "phone": "9876543211", "dept": 0},
            {"name": "Dr. Carol Gupta", "email": "carol@cse.com", "phone": "9876543212", "dept": 0},
            {"name": "Prof. David Kumar", "email": "david@cse.com", "phone": "9876543213", "dept": 0},
            {"name": "Dr. Emma Patel", "email": "emma@cse.com", "phone": "9876543214", "dept": 0},
            {"name": "Prof. Frank Verma", "email": "frank@cse.com", "phone": "9876543215", "dept": 0},
            
            # IT Department Teachers
            {"name": "Dr. Grace Iyer", "email": "grace@it.com", "phone": "9876543216", "dept": 1},
            {"name": "Prof. Henry Joshi", "email": "henry@it.com", "phone": "9876543217", "dept": 1},
            {"name": "Dr. Irene Naik", "email": "irene@it.com", "phone": "9876543218", "dept": 1},
            
            # ECE Department Teachers
            {"name": "Dr. Jack Reddy", "email": "jack@ece.com", "phone": "9876543219", "dept": 2},
            {"name": "Prof. Kate Sharma", "email": "kate@ece.com", "phone": "9876543220", "dept": 2},
        ]
        
        teachers = []
        for t_data in teachers_data:
            teacher = models.Teacher(
                name=t_data["name"],
                department_id=departments[t_data["dept"]].id,
                email=t_data["email"],
                phone=t_data["phone"]
            )
            db.add(teacher)
            db.flush()
            teachers.append(teacher)
            logger.info(f"✅ Created teacher: {teacher.name} ({departments[t_data['dept']].name})")

        # 4. Create classes for each department
        classes_data = [
            {"name": "Third Year (TY)", "dept": 0, "divisions": 2},  # CSE - 2 divisions
            {"name": "Second Year (SY)", "dept": 0, "divisions": 1},  # CSE - 1 division
            {"name": "Third Year (TY)", "dept": 1, "divisions": 1},   # IT - 1 division
            {"name": "Third Year (TY)", "dept": 2, "divisions": 1},  # ECE - 1 division
        ]
        
        classes = []
        for class_data in classes_data:
            class_obj = models.Class(
                name=class_data["name"],
                department_id=departments[class_data["dept"]].id,
                number_of_divisions=class_data["divisions"]
            )
            db.add(class_obj)
            db.flush()
            classes.append(class_obj)
            logger.info(f"✅ Created class: {class_obj.name} ({departments[class_data['dept']].name})")

        # 5. Create divisions for each class
        divisions = []
        for class_obj in classes:
            for div_num in range(1, class_obj.number_of_divisions + 1):
                division = models.Division(
                    name=chr(64 + div_num),  # A, B, C, etc.
                    class_id=class_obj.id
                )
                db.add(division)
                db.flush()
                divisions.append(division)
                logger.info(f"✅ Created division: {division.name} ({class_obj.name})")

        # 6. Create batches for each division (3 batches per division)
        batches = []
        for division in divisions:
            for batch_num in range(1, 4):  # A1, A2, A3
                batch = models.Batch(
                    number=batch_num,
                    division_id=division.id
                )
                db.add(batch)
                db.flush()
                batches.append(batch)
                logger.info(f"✅ Created batch: {division.name}{batch_num}")

        # 7. Create subjects with correct durations
        subjects_data = [
            # CSE Third Year subjects
            {"name": "Data Structures", "type": "lecture", "hours": 3, "class": 0, "duration": 60},
            {"name": "Data Structures Lab", "type": "lab", "hours": 2, "class": 0, "duration": 120},
            {"name": "Machine Learning", "type": "lecture", "hours": 3, "class": 0, "duration": 60},
            {"name": "Machine Learning Lab", "type": "lab", "hours": 2, "class": 0, "duration": 120},
            {"name": "Database Systems", "type": "lecture", "hours": 3, "class": 0, "duration": 60},
            {"name": "Database Systems Lab", "type": "lab", "hours": 2, "class": 0, "duration": 120},
            {"name": "Software Engineering", "type": "lecture", "hours": 3, "class": 0, "duration": 60},
            {"name": "Software Engineering Lab", "type": "lab", "hours": 2, "class": 0, "duration": 120},
            {"name": "Programming Tutorial", "type": "tutorial", "hours": 1, "class": 0, "duration": 60},
            {"name": "Math Tutorial", "type": "tutorial", "hours": 1, "class": 0, "duration": 60},
            
            # CSE Second Year subjects
            {"name": "Object Oriented Programming", "type": "lecture", "hours": 3, "class": 1, "duration": 60},
            {"name": "OOP Lab", "type": "lab", "hours": 2, "class": 1, "duration": 120},
            {"name": "Computer Networks", "type": "lecture", "hours": 3, "class": 1, "duration": 60},
            {"name": "Computer Networks Lab", "type": "lab", "hours": 2, "class": 1, "duration": 120},
            
            # IT Third Year subjects
            {"name": "Web Technologies", "type": "lecture", "hours": 3, "class": 2, "duration": 60},
            {"name": "Web Technologies Lab", "type": "lab", "hours": 2, "class": 2, "duration": 120},
            {"name": "Mobile App Development", "type": "lecture", "hours": 3, "class": 2, "duration": 60},
            {"name": "Mobile App Development Lab", "type": "lab", "hours": 2, "class": 2, "duration": 120},
            
            # ECE Third Year subjects
            {"name": "Digital Signal Processing", "type": "lecture", "hours": 3, "class": 3, "duration": 60},
            {"name": "DSP Lab", "type": "lab", "hours": 2, "class": 3, "duration": 120},
            {"name": "Microprocessors", "type": "lecture", "hours": 3, "class": 3, "duration": 60},
            {"name": "Microprocessors Lab", "type": "lab", "hours": 2, "class": 3, "duration": 120},
        ]
        
        subjects = []
        for sub_data in subjects_data:
            subject = models.Subject(
                name=sub_data["name"],
                type=models.SubjectType[sub_data["type"]],
                hours_per_week=sub_data["hours"],
                class_id=classes[sub_data["class"]].id,
                can_be_twice_in_day=False
            )
            db.add(subject)
            db.flush()
            subjects.append(subject)
            duration_text = f"{sub_data['duration']}min" if sub_data['duration'] == 60 else f"{sub_data['duration']//60}hr"
            logger.info(f"✅ Created subject: {subject.name} ({subject.type.value}, {duration_text})")

        # 8. Create rooms for each department
        rooms_data = [
            # CSE Department Rooms
            {"room_number": "D301", "type": "classroom", "capacity": 60, "floor": 3, "dept": 0},
            {"room_number": "D302", "type": "classroom", "capacity": 60, "floor": 3, "dept": 0},
            {"room_number": "D303", "type": "classroom", "capacity": 60, "floor": 3, "dept": 0},
            {"room_number": "D307", "type": "lab", "capacity": 30, "floor": 3, "dept": 0},
            {"room_number": "D308", "type": "lab", "capacity": 30, "floor": 3, "dept": 0},
            {"room_number": "D309", "type": "lab", "capacity": 30, "floor": 3, "dept": 0},
            {"room_number": "D304", "type": "tutorial", "capacity": 20, "floor": 3, "dept": 0},
            {"room_number": "D305", "type": "tutorial", "capacity": 20, "floor": 3, "dept": 0},
            
            # IT Department Rooms
            {"room_number": "E201", "type": "classroom", "capacity": 60, "floor": 2, "dept": 1},
            {"room_number": "E202", "type": "classroom", "capacity": 60, "floor": 2, "dept": 1},
            {"room_number": "E205", "type": "lab", "capacity": 30, "floor": 2, "dept": 1},
            {"room_number": "E206", "type": "lab", "capacity": 30, "floor": 2, "dept": 1},
            {"room_number": "E203", "type": "tutorial", "capacity": 20, "floor": 2, "dept": 1},
            
            # ECE Department Rooms
            {"room_number": "F101", "type": "classroom", "capacity": 60, "floor": 1, "dept": 2},
            {"room_number": "F102", "type": "classroom", "capacity": 60, "floor": 1, "dept": 2},
            {"room_number": "F105", "type": "lab", "capacity": 30, "floor": 1, "dept": 2},
            {"room_number": "F106", "type": "lab", "capacity": 30, "floor": 1, "dept": 2},
            {"room_number": "F103", "type": "tutorial", "capacity": 20, "floor": 1, "dept": 2},
        ]
        
        rooms = []
        for room_data in rooms_data:
            room = models.Room(
                room_number=room_data["room_number"],
                type=models.RoomType[room_data["type"]],
                capacity=room_data["capacity"],
                floor=room_data["floor"],
                department_id=departments[room_data["dept"]].id
            )
            db.add(room)
            db.flush()
            rooms.append(room)
            logger.info(f"✅ Created room: {room.room_number} ({room.type.value}, {departments[room_data['dept']].name})")

        # 9. Assign teachers to subjects for each division
        # CSE Third Year Division A
        cse_ty_division_a = next(d for d in divisions if d.class_id == classes[0].id and d.name == "A")
        cse_ty_subjects = [s for s in subjects if s.class_id == classes[0].id]
        cse_teachers = [t for t in teachers if t.department_id == departments[0].id]
        
        for i, subject in enumerate(cse_ty_subjects):
            teacher = cse_teachers[i % len(cse_teachers)]
            assignment = models.SubjectTeacher(
                subject_id=subject.id,
                teacher_id=teacher.id,
                division_id=cse_ty_division_a.id
            )
            db.add(assignment)
            logger.info(f"✅ Assigned {subject.name} to {teacher.name} (Division {cse_ty_division_a.name})")

        # CSE Third Year Division B
        cse_ty_division_b = next(d for d in divisions if d.class_id == classes[0].id and d.name == "B")
        for i, subject in enumerate(cse_ty_subjects):
            teacher = cse_teachers[(i + 2) % len(cse_teachers)]  # Different teacher
            assignment = models.SubjectTeacher(
                subject_id=subject.id,
                teacher_id=teacher.id,
                division_id=cse_ty_division_b.id
            )
            db.add(assignment)
            logger.info(f"✅ Assigned {subject.name} to {teacher.name} (Division {cse_ty_division_b.name})")

        # Other divisions
        other_divisions = [d for d in divisions if d.class_id != classes[0].id]
        for division in other_divisions:
            class_subjects = [s for s in subjects if s.class_id == division.class_id]
            dept_teachers = [t for t in teachers if t.department_id == classes[division.class_id - classes[0].id].department_id]
            
            for i, subject in enumerate(class_subjects):
                teacher = dept_teachers[i % len(dept_teachers)]
                assignment = models.SubjectTeacher(
                    subject_id=subject.id,
                    teacher_id=teacher.id,
                    division_id=division.id
                )
                db.add(assignment)
                logger.info(f"✅ Assigned {subject.name} to {teacher.name} (Division {division.name})")

        # 10. Create timetable slots with proper time intervals
        # Default: 8 periods per day, 6 days per week
        # Start time will be configurable during teacher allocation
        days_of_week = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
        periods_per_day = 8
        
        for dept in departments:
            for day_idx, day_name in enumerate(days_of_week):
                for period_idx in range(periods_per_day):
                    # Skip break/lunch periods
                    if period_idx == 2:  # Short break
                        is_break = True
                        break_type = "short_break"
                        start_time = "10:00"
                        end_time = "10:15"
                    elif period_idx == 6:  # Lunch break
                        is_break = True
                        break_type = "lunch_break"
                        start_time = "13:00"
                        end_time = "14:00"
                    else:
                        is_break = False
                        break_type = None
                        # Default times - will be updated during teacher allocation
                        start_time = f"{8 + period_idx}:00"
                        end_time = f"{9 + period_idx}:00"

                    slot = models.TimetableSlots(
                        department_id=dept.id,
                        day_index=day_idx,
                        period_index=period_idx,
                        start_time=start_time,
                        end_time=end_time,
                        is_break=is_break,
                        break_type=break_type
                    )
                    db.add(slot)
            logger.info(f"✅ Created timetable slots for {dept.name}")

        db.commit()
        logger.info("🎉 New sample data created successfully!")
        logger.info("📊 Summary:")
        logger.info(f"   - Users: 1")
        logger.info(f"   - Departments: {len(departments)}")
        logger.info(f"   - Teachers: {len(teachers)}")
        logger.info(f"   - Classes: {len(classes)}")
        logger.info(f"   - Divisions: {len(divisions)}")
        logger.info(f"   - Batches: {len(batches)}")
        logger.info(f"   - Subjects: {len(subjects)}")
        logger.info(f"   - Rooms: {len(rooms)}")
        logger.info(f"   - Timetable Slots: {len(departments) * 6 * 8}")

    except Exception as e:
        db.rollback()
        logger.error(f"❌ Error creating new sample data: {e}", exc_info=True)
        raise
    finally:
        db.close()

if __name__ == "__main__":
    create_new_sample_data()
