from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.models import Department
from app.dependencies import get_db
from pydantic import BaseModel

router = APIRouter()

class DepartmentCreate(BaseModel):
    name: str
    type: str

class DepartmentUpdate(BaseModel):
    name: str
    type: str

# Create Department
@router.post("/")
def create_department(dep: DepartmentCreate, db: Session = Depends(get_db)):
    new_dep = Department(name=dep.name, type=dep.type)
    db.add(new_dep)
    db.commit()
    db.refresh(new_dep)
    return new_dep

# Get all Departments
@router.get("/")
def get_departments(db: Session = Depends(get_db)):
    return db.query(Department).all()

# Get Department by ID
@router.get("/{dep_id}")
def get_department(dep_id: int, db: Session = Depends(get_db)):
    dep = db.query(Department).get(dep_id)
    if not dep:
        raise HTTPException(status_code=404, detail="Department not found")
    return dep

# Update Department
@router.put("/{dep_id}")
def update_department(dep_id: int, dep_update: DepartmentUpdate, db: Session = Depends(get_db)):
    dep = db.query(Department).get(dep_id)
    if not dep:
        raise HTTPException(status_code=404, detail="Department not found")
    dep.name = dep_update.name
    dep.type = dep_update.type
    db.commit()
    db.refresh(dep)
    return dep

# Delete Department
@router.delete("/{dep_id}")
def delete_department(dep_id: int, db: Session = Depends(get_db)):
    dep = db.query(Department).get(dep_id)
    if not dep:
        raise HTTPException(status_code=404, detail="Department not found")
    db.delete(dep)
    db.commit()
    return {"detail": "Department deleted"}
