from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.models import ScheduleEntry
from app.dependencies import get_db
from pydantic import BaseModel

router = APIRouter()

class ScheduleEntryCreate(BaseModel):
    timetable_id: int
    day_index: int
    period_index: int
    subject_id: int
    teacher_id: int
    room_id: int
    division_id: int
    batch_id: int

class ScheduleEntryUpdate(BaseModel):
    timetable_id: int
    day_index: int
    period_index: int
    subject_id: int
    teacher_id: int
    room_id: int
    division_id: int
    batch_id: int

@router.post("/")
def create_entry(entry: ScheduleEntryCreate, db: Session = Depends(get_db)):
    new_entry = ScheduleEntry(**entry.dict())
    db.add(new_entry)
    db.commit()
    db.refresh(new_entry)
    return new_entry

@router.get("/")
def get_entries(db: Session = Depends(get_db)):
    return db.query(ScheduleEntry).all()

@router.get("/{entry_id}")
def get_entry(entry_id: int, db: Session = Depends(get_db)):
    entry = db.query(ScheduleEntry).get(entry_id)
    if not entry:
        raise HTTPException(status_code=404, detail="Schedule entry not found")
    return entry

@router.put("/{entry_id}")
def update_entry(entry_id: int, entry_update: ScheduleEntryUpdate, db: Session = Depends(get_db)):
    entry = db.query(ScheduleEntry).get(entry_id)
    if not entry:
        raise HTTPException(status_code=404, detail="Schedule entry not found")
    for key, value in entry_update.dict().items():
        setattr(entry, key, value)
    db.commit()
    db.refresh(entry)
    return entry

@router.delete("/{entry_id}")
def delete_entry(entry_id: int, db: Session = Depends(get_db)):
    entry = db.query(ScheduleEntry).get(entry_id)
    if not entry:
        raise HTTPException(status_code=404, detail="Schedule entry not found")
    db.delete(entry)
    db.commit()
    return {"detail": "Schedule entry deleted"}
