from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.models import Class
from app.dependencies import get_db
from pydantic import BaseModel

router = APIRouter()

class ClassCreate(BaseModel):
    name: str
    number_of_divisions: int
    department_id: int

class ClassUpdate(BaseModel):
    name: str
    number_of_divisions: int
    department_id: int

@router.post("/")
def create_class(cls: ClassCreate, db: Session = Depends(get_db)):
    new_cls = Class(**cls.dict())
    db.add(new_cls)
    db.commit()
    db.refresh(new_cls)
    return new_cls

@router.get("/")
def get_classes(db: Session = Depends(get_db)):
    return db.query(Class).all()

@router.get("/{class_id}")
def get_class(class_id: int, db: Session = Depends(get_db)):
    cls = db.query(Class).get(class_id)
    if not cls:
        raise HTTPException(status_code=404, detail="Class not found")
    return cls

@router.put("/{class_id}")
def update_class(class_id: int, cls_update: ClassUpdate, db: Session = Depends(get_db)):
    cls = db.query(Class).get(class_id)
    if not cls:
        raise HTTPException(status_code=404, detail="Class not found")
    for key, value in cls_update.dict().items():
        setattr(cls, key, value)
    db.commit()
    db.refresh(cls)
    return cls

@router.delete("/{class_id}")
def delete_class(class_id: int, db: Session = Depends(get_db)):
    cls = db.query(Class).get(class_id)
    if not cls:
        raise HTTPException(status_code=404, detail="Class not found")
    db.delete(cls)
    db.commit()
    return {"detail": "Class deleted"}
