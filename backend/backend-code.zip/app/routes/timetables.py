from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.models import Timetable
from app.dependencies import get_db
from pydantic import BaseModel
from datetime import datetime

router = APIRouter()

class TimetableCreate(BaseModel):
    name: str
    class_id: int
    is_published: bool = False

class TimetableUpdate(BaseModel):
    name: str
    class_id: int
    is_published: bool

@router.post("/")
def create_timetable(tt: TimetableCreate, db: Session = Depends(get_db)):
    new_tt = Timetable(**tt.dict())
    db.add(new_tt)
    db.commit()
    db.refresh(new_tt)
    return new_tt

@router.get("/")
def get_timetables(db: Session = Depends(get_db)):
    return db.query(Timetable).all()

@router.get("/{tt_id}")
def get_timetable(tt_id: int, db: Session = Depends(get_db)):
    tt = db.query(Timetable).get(tt_id)
    if not tt:
        raise HTTPException(status_code=404, detail="Timetable not found")
    return tt

@router.put("/{tt_id}")
def update_timetable(tt_id: int, tt_update: TimetableUpdate, db: Session = Depends(get_db)):
    tt = db.query(Timetable).get(tt_id)
    if not tt:
        raise HTTPException(status_code=404, detail="Timetable not found")
    for key, value in tt_update.dict().items():
        setattr(tt, key, value)
    db.commit()
    db.refresh(tt)
    return tt

@router.delete("/{tt_id}")
def delete_timetable(tt_id: int, db: Session = Depends(get_db)):
    tt = db.query(Timetable).get(tt_id)
    if not tt:
        raise HTTPException(status_code=404, detail="Timetable not found")
    db.delete(tt)
    db.commit()
    return {"detail": "Timetable deleted"}
