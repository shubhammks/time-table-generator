"""
Timetable generation and management API routes.
"""

import io
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, BackgroundTasks
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app import models, schemas
from app.auth import get_current_active_user, require_coordinator_or_admin
from app.database import get_db
from app.services.generator import TimetableGenerator, GenerationRequest, SubjectAssignment

router = APIRouter()

@router.post("/generate", response_model=schemas.TimetableGenerationResult)
def generate_timetable(
    request: schemas.TimetableGenerationRequest,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Generate a new timetable using CSP + Optimization."""
    try:
        # Convert subject assignments
        subject_assignments = []
        if request.subject_assignments:
            for assignment in request.subject_assignments:
                subject_assignments.append(SubjectAssignment(
                    subject_id=assignment.subject_id,
                    teacher_id=assignment.teacher_id,
                    subject_type=assignment.subject_type,
                    subject_name=assignment.subject_name,
                    hours_per_week=assignment.hours_per_week
                ))
        
        # Create generation request
        gen_request = GenerationRequest(
            name=request.name,
            class_id=request.class_id,
            department_id=request.department_id,
            mode=request.mode,
            user_id=current_user.id,
            subject_assignments=subject_assignments,
            options=request.options
        )
        
        # Initialize generator and generate timetable
        generator = TimetableGenerator(db)
        result = generator.generate_timetable(gen_request)
        
        # Convert to API response format
        api_result = schemas.TimetableGenerationResult(
            timetable_id=result.timetable_id,
            success=result.success,
            message=result.message,
            diagnostics=result.diagnostics,
            generation_stats={
                "csp_stats": result.csp_stats,
                "optimization_stats": result.optimization_stats,
                "total_time": result.total_time
            }
        )
        
        return api_result
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Timetable generation failed: {str(e)}"
        )

@router.get("/validate", response_model=schemas.ValidationResult)
def validate_timetable_prerequisites(
    class_id: Optional[int] = None,
    department_id: Optional[int] = None,
    mode: str = "school",
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """Validate prerequisites for timetable generation."""
    from app.services.generator import TimetableValidator
    
    validator = TimetableValidator(db)
    result = validator.validate_pre_generation(class_id, department_id, mode)
    
    return result

@router.get("/list", response_model=List[schemas.Timetable])
def get_timetables(
    skip: int = 0,
    limit: int = 100,
    class_id: Optional[int] = None,
    is_published: Optional[bool] = None,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """Get all timetables with optional filters."""
    query = db.query(models.Timetable)
    
    if class_id:
        query = query.filter(models.Timetable.class_id == class_id)
    if is_published is not None:
        query = query.filter(models.Timetable.is_published == is_published)
    
    timetables = query.offset(skip).limit(limit).all()
    return timetables

@router.get("/{timetable_id}", response_model=schemas.Timetable)
def get_timetable(
    timetable_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """Get timetable by ID."""
    timetable = db.query(models.Timetable).filter(
        models.Timetable.id == timetable_id
    ).first()
    
    if not timetable:
        raise HTTPException(status_code=404, detail="Timetable not found")
    
    return timetable

@router.get("/{timetable_id}/schedule", response_model=List[schemas.ScheduleEntry])
def get_timetable_schedule(
    timetable_id: int,
    division_id: Optional[int] = None,
    day_index: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """Get schedule entries for a timetable."""
    # Verify timetable exists
    timetable = db.query(models.Timetable).filter(
        models.Timetable.id == timetable_id
    ).first()
    
    if not timetable:
        raise HTTPException(status_code=404, detail="Timetable not found")
    
    query = db.query(models.ScheduleEntry).filter(
        models.ScheduleEntry.timetable_id == timetable_id
    )
    
    if division_id:
        query = query.filter(models.ScheduleEntry.division_id == division_id)
    if day_index is not None:
        query = query.filter(models.ScheduleEntry.day_index == day_index)
    
    schedule_entries = query.order_by(
        models.ScheduleEntry.day_index,
        models.ScheduleEntry.period_index
    ).all()
    
    return schedule_entries

@router.get("/{timetable_id}/grid")
def get_timetable_grid(
    timetable_id: int,
    division_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """Get timetable in grid format for frontend display."""
    # Verify timetable exists
    timetable = db.query(models.Timetable).filter(
        models.Timetable.id == timetable_id
    ).first()
    
    if not timetable:
        raise HTTPException(status_code=404, detail="Timetable not found")
    
    # Get schedule entries
    query = db.query(models.ScheduleEntry).filter(
        models.ScheduleEntry.timetable_id == timetable_id
    )
    
    if division_id:
        query = query.filter(models.ScheduleEntry.division_id == division_id)
    
    entries = query.all()
    
    # Convert to grid format
    grid = {}
    days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
    
    for entry in entries:
        day = days[entry.day_index]
        period = entry.period_index
        
        if day not in grid:
            grid[day] = {}
        
        # Get related data
        subject = db.query(models.Subject).filter(models.Subject.id == entry.subject_id).first()
        teacher = db.query(models.Teacher).filter(models.Teacher.id == entry.teacher_id).first()
        room = db.query(models.Room).filter(models.Room.id == entry.room_id).first()
        division = None
        batch = None
        if entry.division_id:
            division = db.query(models.Division).filter(models.Division.id == entry.division_id).first()
        if entry.batch_id:
            batch = db.query(models.Batch).filter(models.Batch.id == entry.batch_id).first()
        
        grid[day][period] = {
            "id": entry.id,
            "subject": {
                "id": subject.id if subject else None,
                "name": subject.name if subject else "Unknown",
                "type": subject.type.value if subject else "lecture"
            },
            "teacher": {
                "id": teacher.id if teacher else None,
                "name": teacher.name if teacher else "Unknown"
            },
            "room": {
                "id": room.id if room else None,
                "room_number": room.room_number if room else "Unknown",
                "type": room.type.value if room else "classroom"
            },
            "division": {
                "id": division.id if division else None,
                "name": division.name if division else None
            } if division else None,
            "batch": {
                "id": batch.id if batch else None,
                "number": batch.number if batch else None
            } if batch else None
        }
    
    return {
        "timetable_id": timetable_id,
        "timetable_name": timetable.name,
        "grid": grid,
        "days": days
    }

@router.post("/{timetable_id}/publish")
def publish_timetable(
    timetable_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Publish a timetable."""
    timetable = db.query(models.Timetable).filter(
        models.Timetable.id == timetable_id
    ).first()
    
    if not timetable:
        raise HTTPException(status_code=404, detail="Timetable not found")
    
    timetable.is_published = True
    db.commit()
    
    return {"message": "Timetable published successfully"}

@router.delete("/{timetable_id}")
def delete_timetable(
    timetable_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Delete a timetable and all its schedule entries."""
    timetable = db.query(models.Timetable).filter(
        models.Timetable.id == timetable_id
    ).first()
    
    if not timetable:
        raise HTTPException(status_code=404, detail="Timetable not found")
    
    # Delete all schedule entries first
    db.query(models.ScheduleEntry).filter(
        models.ScheduleEntry.timetable_id == timetable_id
    ).delete()
    
    # Delete timetable
    db.delete(timetable)
    db.commit()
    
    return {"message": "Timetable deleted successfully"}
