from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.models import Teacher
from app.dependencies import get_db
from pydantic import BaseModel

router = APIRouter()

# ---------------------------
# Pydantic Schemas
# ---------------------------
class TeacherCreate(BaseModel):
    name: str
    department_id: int

class TeacherUpdate(BaseModel):
    name: str = None
    department_id: int = None

# ---------------------------
# CRUD Endpoints
# ---------------------------

# Create Teacher
@router.post("/")
def create_teacher(teacher: TeacherCreate, db: Session = Depends(get_db)):
    new_teacher = Teacher(name=teacher.name, department_id=teacher.department_id)
    db.add(new_teacher)
    db.commit()
    db.refresh(new_teacher)
    return new_teacher

# Read all Teachers
@router.get("/")
def get_teachers(db: Session = Depends(get_db)):
    return db.query(Teacher).all()

# Read Teacher by ID
@router.get("/{teacher_id}")
def get_teacher(teacher_id: int, db: Session = Depends(get_db)):
    teacher = db.query(Teacher).filter(Teacher.id == teacher_id).first()
    if not teacher:
        raise HTTPException(status_code=404, detail="Teacher not found")
    return teacher

# Update Teacher
@router.put("/{teacher_id}")
def update_teacher(teacher_id: int, teacher_data: TeacherUpdate, db: Session = Depends(get_db)):
    teacher = db.query(Teacher).filter(Teacher.id == teacher_id).first()
    if not teacher:
        raise HTTPException(status_code=404, detail="Teacher not found")
    
    if teacher_data.name is not None:
        teacher.name = teacher_data.name
    if teacher_data.department_id is not None:
        teacher.department_id = teacher_data.department_id

    db.commit()
    db.refresh(teacher)
    return teacher

# Delete Teacher
@router.delete("/{teacher_id}")
def delete_teacher(teacher_id: int, db: Session = Depends(get_db)):
    teacher = db.query(Teacher).filter(Teacher.id == teacher_id).first()
    if not teacher:
        raise HTTPException(status_code=404, detail="Teacher not found")
    
    db.delete(teacher)
    db.commit()
    return {"message": f"Teacher {teacher_id} deleted"}
