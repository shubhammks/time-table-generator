from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.models import Room
from app.dependencies import get_db
from pydantic import BaseModel

router = APIRouter()

class RoomCreate(BaseModel):
    room_number: str
    type: str
    capacity: int
    floor: int
    department_id: int

class RoomUpdate(BaseModel):
    room_number: str
    type: str
    capacity: int
    floor: int
    department_id: int

@router.post("/")
def create_room(room: RoomCreate, db: Session = Depends(get_db)):
    new_room = Room(**room.dict())
    db.add(new_room)
    db.commit()
    db.refresh(new_room)
    return new_room

@router.get("/")
def get_rooms(db: Session = Depends(get_db)):
    return db.query(Room).all()

@router.get("/{room_id}")
def get_room(room_id: int, db: Session = Depends(get_db)):
    room = db.query(Room).get(room_id)
    if not room:
        raise HTTPException(status_code=404, detail="Room not found")
    return room

@router.put("/{room_id}")
def update_room(room_id: int, room_update: RoomUpdate, db: Session = Depends(get_db)):
    room = db.query(Room).get(room_id)
    if not room:
        raise HTTPException(status_code=404, detail="Room not found")
    for key, value in room_update.dict().items():
        setattr(room, key, value)
    db.commit()
    db.refresh(room)
    return room

@router.delete("/{room_id}")
def delete_room(room_id: int, db: Session = Depends(get_db)):
    room = db.query(Room).get(room_id)
    if not room:
        raise HTTPException(status_code=404, detail="Room not found")
    db.delete(room)
    db.commit()
    return {"detail": "Room deleted"}
