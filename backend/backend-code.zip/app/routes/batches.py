from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.models import Batch
from app.dependencies import get_db
from pydantic import BaseModel

router = APIRouter()

class BatchCreate(BaseModel):
    number: int
    division_id: int

class BatchUpdate(BaseModel):
    number: int
    division_id: int

@router.post("/")
def create_batch(batch: BatchCreate, db: Session = Depends(get_db)):
    new_batch = Batch(**batch.dict())
    db.add(new_batch)
    db.commit()
    db.refresh(new_batch)
    return new_batch

@router.get("/")
def get_batches(db: Session = Depends(get_db)):
    return db.query(Batch).all()

@router.get("/{batch_id}")
def get_batch(batch_id: int, db: Session = Depends(get_db)):
    batch = db.query(Batch).get(batch_id)
    if not batch:
        raise HTTPException(status_code=404, detail="Batch not found")
    return batch

@router.put("/{batch_id}")
def update_batch(batch_id: int, batch_update: BatchUpdate, db: Session = Depends(get_db)):
    batch = db.query(Batch).get(batch_id)
    if not batch:
        raise HTTPException(status_code=404, detail="Batch not found")
    for key, value in batch_update.dict().items():
        setattr(batch, key, value)
    db.commit()
    db.refresh(batch)
    return batch

@router.delete("/{batch_id}")
def delete_batch(batch_id: int, db: Session = Depends(get_db)):
    batch = db.query(Batch).get(batch_id)
    if not batch:
        raise HTTPException(status_code=404, detail="Batch not found")
    db.delete(batch)
    db.commit()
    return {"detail": "Batch deleted"}
