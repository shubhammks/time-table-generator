from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.models import Subject
from app.dependencies import get_db
from pydantic import BaseModel

router = APIRouter()

class SubjectCreate(BaseModel):
    name: str
    type: str
    hours_per_week: int
    class_id: int

class SubjectUpdate(BaseModel):
    name: str
    type: str
    hours_per_week: int
    class_id: int

@router.post("/")
def create_subject(sub: SubjectCreate, db: Session = Depends(get_db)):
    new_sub = Subject(**sub.dict())
    db.add(new_sub)
    db.commit()
    db.refresh(new_sub)
    return new_sub

@router.get("/")
def get_subjects(db: Session = Depends(get_db)):
    return db.query(Subject).all()

@router.get("/{sub_id}")
def get_subject(sub_id: int, db: Session = Depends(get_db)):
    sub = db.query(Subject).get(sub_id)
    if not sub:
        raise HTTPException(status_code=404, detail="Subject not found")
    return sub

@router.put("/{sub_id}")
def update_subject(sub_id: int, sub_update: SubjectUpdate, db: Session = Depends(get_db)):
    sub = db.query(Subject).get(sub_id)
    if not sub:
        raise HTTPException(status_code=404, detail="Subject not found")
    for key, value in sub_update.dict().items():
        setattr(sub, key, value)
    db.commit()
    db.refresh(sub)
    return sub

@router.delete("/{sub_id}")
def delete_subject(sub_id: int, db: Session = Depends(get_db)):
    sub = db.query(Subject).get(sub_id)
    if not sub:
        raise HTTPException(status_code=404, detail="Subject not found")
    db.delete(sub)
    db.commit()
    return {"detail": "Subject deleted"}
