"""
CRUD routes for all entities: departments, teachers, classes, divisions, 
batches, subjects, rooms, and subject-teacher assignments.
"""

from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import func

from app import models, schemas
from app.auth import get_current_active_user, require_coordinator_or_admin
from app.database import get_db

router = APIRouter()

# Department routes
@router.post("/departments", response_model=schemas.Department)
def create_department(
    department: schemas.DepartmentCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Create a new department."""
    db_department = models.Department(**department.dict())
    db.add(db_department)
    db.commit()
    db.refresh(db_department)
    return db_department

@router.get("/departments", response_model=List[schemas.Department])
def get_departments(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """Get all departments."""
    departments = db.query(models.Department).offset(skip).limit(limit).all()
    return departments

@router.get("/departments/{department_id}", response_model=schemas.Department)
def get_department(
    department_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """Get department by ID."""
    department = db.query(models.Department).filter(models.Department.id == department_id).first()
    if not department:
        raise HTTPException(status_code=404, detail="Department not found")
    return department

@router.put("/departments/{department_id}", response_model=schemas.Department)
def update_department(
    department_id: int,
    department: schemas.DepartmentCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Update department."""
    db_department = db.query(models.Department).filter(models.Department.id == department_id).first()
    if not db_department:
        raise HTTPException(status_code=404, detail="Department not found")
    
    for field, value in department.dict().items():
        setattr(db_department, field, value)
    
    db.commit()
    db.refresh(db_department)
    return db_department

@router.delete("/departments/{department_id}")
def delete_department(
    department_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Delete department."""
    db_department = db.query(models.Department).filter(models.Department.id == department_id).first()
    if not db_department:
        raise HTTPException(status_code=404, detail="Department not found")
    
    db.delete(db_department)
    db.commit()
    return {"message": "Department deleted"}

# Teacher routes
@router.post("/teachers", response_model=schemas.Teacher)
def create_teacher(
    teacher: schemas.TeacherCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Create a new teacher."""
    db_teacher = models.Teacher(**teacher.dict())
    db.add(db_teacher)
    db.commit()
    db.refresh(db_teacher)
    return db_teacher

@router.get("/teachers", response_model=List[schemas.Teacher])
def get_teachers(
    skip: int = 0,
    limit: int = 100,
    department_id: int = None,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """Get all teachers, optionally filtered by department."""
    query = db.query(models.Teacher)
    if department_id:
        query = query.filter(models.Teacher.department_id == department_id)
    
    teachers = query.offset(skip).limit(limit).all()
    return teachers

@router.get("/teachers/{teacher_id}", response_model=schemas.Teacher)
def get_teacher(
    teacher_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """Get teacher by ID."""
    teacher = db.query(models.Teacher).filter(models.Teacher.id == teacher_id).first()
    if not teacher:
        raise HTTPException(status_code=404, detail="Teacher not found")
    return teacher

@router.put("/teachers/{teacher_id}", response_model=schemas.Teacher)
def update_teacher(
    teacher_id: int,
    teacher: schemas.TeacherCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Update teacher."""
    db_teacher = db.query(models.Teacher).filter(models.Teacher.id == teacher_id).first()
    if not db_teacher:
        raise HTTPException(status_code=404, detail="Teacher not found")
    
    for field, value in teacher.dict().items():
        setattr(db_teacher, field, value)
    
    db.commit()
    db.refresh(db_teacher)
    return db_teacher

@router.delete("/teachers/{teacher_id}")
def delete_teacher(
    teacher_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Delete teacher."""
    db_teacher = db.query(models.Teacher).filter(models.Teacher.id == teacher_id).first()
    if not db_teacher:
        raise HTTPException(status_code=404, detail="Teacher not found")
    
    db.delete(db_teacher)
    db.commit()
    return {"message": "Teacher deleted"}

# Class routes
@router.post("/classes", response_model=schemas.Class)
def create_class(
    class_data: schemas.ClassCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Create a new class."""
    db_class = models.Class(**class_data.dict())
    db.add(db_class)
    db.commit()
    db.refresh(db_class)
    
    # Auto-create divisions based on number_of_divisions
    for i in range(db_class.number_of_divisions):
        division_name = f"{db_class.name}{chr(65 + i)}"  # A, B, C, etc.
        division = models.Division(
            name=division_name,
            class_id=db_class.id
        )
        db.add(division)
    
    db.commit()
    return db_class

@router.get("/classes", response_model=List[schemas.Class])
def get_classes(
    skip: int = 0,
    limit: int = 100,
    department_id: int = None,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """Get all classes, optionally filtered by department."""
    query = db.query(models.Class)
    if department_id:
        query = query.filter(models.Class.department_id == department_id)
    
    classes = query.offset(skip).limit(limit).all()
    return classes

@router.get("/classes/{class_id}", response_model=schemas.Class)
def get_class(
    class_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """Get class by ID."""
    class_obj = db.query(models.Class).filter(models.Class.id == class_id).first()
    if not class_obj:
        raise HTTPException(status_code=404, detail="Class not found")
    return class_obj

@router.put("/classes/{class_id}", response_model=schemas.Class)
def update_class(
    class_id: int,
    class_data: schemas.ClassCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Update class."""
    db_class = db.query(models.Class).filter(models.Class.id == class_id).first()
    if not db_class:
        raise HTTPException(status_code=404, detail="Class not found")
    
    for field, value in class_data.dict().items():
        setattr(db_class, field, value)
    
    db.commit()
    db.refresh(db_class)
    return db_class

@router.delete("/classes/{class_id}")
def delete_class(
    class_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Delete class."""
    db_class = db.query(models.Class).filter(models.Class.id == class_id).first()
    if not db_class:
        raise HTTPException(status_code=404, detail="Class not found")
    
    db.delete(db_class)
    db.commit()
    return {"message": "Class deleted"}

# Division routes
@router.post("/divisions", response_model=schemas.Division)
def create_division(
    division: schemas.DivisionCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Create a new division."""
    db_division = models.Division(**division.dict())
    db.add(db_division)
    db.commit()
    db.refresh(db_division)
    return db_division

@router.get("/divisions", response_model=List[schemas.Division])
def get_divisions(
    skip: int = 0,
    limit: int = 100,
    class_id: int = None,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """Get all divisions, optionally filtered by class."""
    query = db.query(models.Division)
    if class_id:
        query = query.filter(models.Division.class_id == class_id)
    
    divisions = query.offset(skip).limit(limit).all()
    return divisions

@router.get("/divisions/{division_id}", response_model=schemas.Division)
def get_division(
    division_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """Get division by ID."""
    division = db.query(models.Division).filter(models.Division.id == division_id).first()
    if not division:
        raise HTTPException(status_code=404, detail="Division not found")
    return division

@router.put("/divisions/{division_id}", response_model=schemas.Division)
def update_division(
    division_id: int,
    division: schemas.DivisionCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Update division."""
    db_division = db.query(models.Division).filter(models.Division.id == division_id).first()
    if not db_division:
        raise HTTPException(status_code=404, detail="Division not found")
    
    for field, value in division.dict().items():
        setattr(db_division, field, value)
    
    db.commit()
    db.refresh(db_division)
    return db_division

@router.delete("/divisions/{division_id}")
def delete_division(
    division_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Delete division."""
    db_division = db.query(models.Division).filter(models.Division.id == division_id).first()
    if not db_division:
        raise HTTPException(status_code=404, detail="Division not found")
    
    db.delete(db_division)
    db.commit()
    return {"message": "Division deleted"}

# Batch routes
@router.post("/batches", response_model=schemas.Batch)
def create_batch(
    batch: schemas.BatchCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Create a new batch."""
    db_batch = models.Batch(**batch.dict())
    db.add(db_batch)
    db.commit()
    db.refresh(db_batch)
    return db_batch

@router.get("/batches", response_model=List[schemas.Batch])
def get_batches(
    skip: int = 0,
    limit: int = 100,
    division_id: int = None,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """Get all batches, optionally filtered by division."""
    query = db.query(models.Batch)
    if division_id:
        query = query.filter(models.Batch.division_id == division_id)
    
    batches = query.offset(skip).limit(limit).all()
    return batches

@router.get("/batches/{batch_id}", response_model=schemas.Batch)
def get_batch(
    batch_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """Get batch by ID."""
    batch = db.query(models.Batch).filter(models.Batch.id == batch_id).first()
    if not batch:
        raise HTTPException(status_code=404, detail="Batch not found")
    return batch

@router.put("/batches/{batch_id}", response_model=schemas.Batch)
def update_batch(
    batch_id: int,
    batch: schemas.BatchCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Update batch."""
    db_batch = db.query(models.Batch).filter(models.Batch.id == batch_id).first()
    if not db_batch:
        raise HTTPException(status_code=404, detail="Batch not found")
    
    for field, value in batch.dict().items():
        setattr(db_batch, field, value)
    
    db.commit()
    db.refresh(db_batch)
    return db_batch

@router.delete("/batches/{batch_id}")
def delete_batch(
    batch_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Delete batch."""
    db_batch = db.query(models.Batch).filter(models.Batch.id == batch_id).first()
    if not db_batch:
        raise HTTPException(status_code=404, detail="Batch not found")
    
    db.delete(db_batch)
    db.commit()
    return {"message": "Batch deleted"}

# Subject routes
@router.post("/subjects", response_model=schemas.Subject)
def create_subject(
    subject: schemas.SubjectCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Create a new subject."""
    db_subject = models.Subject(**subject.dict())
    db.add(db_subject)
    db.commit()
    db.refresh(db_subject)
    return db_subject

@router.get("/subjects", response_model=List[schemas.Subject])
def get_subjects(
    skip: int = 0,
    limit: int = 100,
    class_id: int = None,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """Get all subjects, optionally filtered by class."""
    query = db.query(models.Subject)
    if class_id:
        query = query.filter(models.Subject.class_id == class_id)
    
    subjects = query.offset(skip).limit(limit).all()
    return subjects

@router.get("/subjects/{subject_id}", response_model=schemas.Subject)
def get_subject(
    subject_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """Get subject by ID."""
    subject = db.query(models.Subject).filter(models.Subject.id == subject_id).first()
    if not subject:
        raise HTTPException(status_code=404, detail="Subject not found")
    return subject

@router.put("/subjects/{subject_id}", response_model=schemas.Subject)
def update_subject(
    subject_id: int,
    subject: schemas.SubjectCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Update subject."""
    db_subject = db.query(models.Subject).filter(models.Subject.id == subject_id).first()
    if not db_subject:
        raise HTTPException(status_code=404, detail="Subject not found")
    
    for field, value in subject.dict().items():
        setattr(db_subject, field, value)
    
    db.commit()
    db.refresh(db_subject)
    return db_subject

@router.delete("/subjects/{subject_id}")
def delete_subject(
    subject_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Delete subject."""
    db_subject = db.query(models.Subject).filter(models.Subject.id == subject_id).first()
    if not db_subject:
        raise HTTPException(status_code=404, detail="Subject not found")
    
    db.delete(db_subject)
    db.commit()
    return {"message": "Subject deleted"}

# Room routes
@router.post("/rooms", response_model=schemas.Room)
def create_room(
    room: schemas.RoomCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Create a new room."""
    db_room = models.Room(**room.dict())
    db.add(db_room)
    db.commit()
    db.refresh(db_room)
    return db_room

@router.get("/rooms", response_model=List[schemas.Room])
def get_rooms(
    skip: int = 0,
    limit: int = 100,
    department_id: int = None,
    room_type: str = None,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """Get all rooms, optionally filtered by department and type."""
    query = db.query(models.Room)
    if department_id:
        query = query.filter(models.Room.department_id == department_id)
    if room_type:
        query = query.filter(models.Room.type == room_type)
    
    rooms = query.offset(skip).limit(limit).all()
    return rooms

@router.get("/rooms/{room_id}", response_model=schemas.Room)
def get_room(
    room_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """Get room by ID."""
    room = db.query(models.Room).filter(models.Room.id == room_id).first()
    if not room:
        raise HTTPException(status_code=404, detail="Room not found")
    return room

@router.put("/rooms/{room_id}", response_model=schemas.Room)
def update_room(
    room_id: int,
    room: schemas.RoomCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Update room."""
    db_room = db.query(models.Room).filter(models.Room.id == room_id).first()
    if not db_room:
        raise HTTPException(status_code=404, detail="Room not found")
    
    for field, value in room.dict().items():
        setattr(db_room, field, value)
    
    db.commit()
    db.refresh(db_room)
    return db_room

@router.delete("/rooms/{room_id}")
def delete_room(
    room_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Delete room."""
    db_room = db.query(models.Room).filter(models.Room.id == room_id).first()
    if not db_room:
        raise HTTPException(status_code=404, detail="Room not found")
    
    db.delete(db_room)
    db.commit()
    return {"message": "Room deleted"}

# Subject-Teacher Assignment routes
@router.post("/subject-teachers", response_model=schemas.SubjectTeacher)
def create_subject_teacher_assignment(
    assignment: schemas.SubjectTeacherCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Assign a teacher to a subject for a division/batch."""
    # Validate that subject, teacher, division exist
    subject = db.query(models.Subject).filter(models.Subject.id == assignment.subject_id).first()
    if not subject:
        raise HTTPException(status_code=404, detail="Subject not found")
    
    teacher = db.query(models.Teacher).filter(models.Teacher.id == assignment.teacher_id).first()
    if not teacher:
        raise HTTPException(status_code=404, detail="Teacher not found")
    
    if assignment.division_id:
        division = db.query(models.Division).filter(models.Division.id == assignment.division_id).first()
        if not division:
            raise HTTPException(status_code=404, detail="Division not found")
    
    # Check for existing assignment
    existing = db.query(models.SubjectTeacher).filter(
        models.SubjectTeacher.subject_id == assignment.subject_id,
        models.SubjectTeacher.division_id == assignment.division_id,
        models.SubjectTeacher.batch_id == assignment.batch_id
    ).first()
    
    if existing:
        raise HTTPException(
            status_code=400, 
            detail="Teacher already assigned to this subject for this division/batch"
        )
    
    db_assignment = models.SubjectTeacher(**assignment.dict())
    db.add(db_assignment)
    db.commit()
    db.refresh(db_assignment)
    return db_assignment

@router.get("/subject-teachers", response_model=List[schemas.SubjectTeacher])
def get_subject_teacher_assignments(
    skip: int = 0,
    limit: int = 100,
    subject_id: int = None,
    teacher_id: int = None,
    division_id: int = None,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """Get all subject-teacher assignments with optional filters."""
    query = db.query(models.SubjectTeacher)
    
    if subject_id:
        query = query.filter(models.SubjectTeacher.subject_id == subject_id)
    if teacher_id:
        query = query.filter(models.SubjectTeacher.teacher_id == teacher_id)
    if division_id:
        query = query.filter(models.SubjectTeacher.division_id == division_id)
    
    assignments = query.offset(skip).limit(limit).all()
    return assignments

@router.delete("/subject-teachers/{assignment_id}")
def delete_subject_teacher_assignment(
    assignment_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Delete a subject-teacher assignment."""
    assignment = db.query(models.SubjectTeacher).filter(
        models.SubjectTeacher.id == assignment_id
    ).first()
    
    if not assignment:
        raise HTTPException(status_code=404, detail="Assignment not found")
    
    db.delete(assignment)
    db.commit()
    return {"message": "Assignment deleted"}

# Timetable Slots Configuration routes
@router.post("/timetable-slots", response_model=schemas.TimetableSlotsConfig)
def create_timetable_slot(
    slot: schemas.TimetableSlotsCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Create a timetable slot configuration."""
    db_slot = models.TimetableSlots(**slot.dict())
    db.add(db_slot)
    db.commit()
    db.refresh(db_slot)
    return db_slot

@router.get("/timetable-slots", response_model=List[schemas.TimetableSlotsConfig])
def get_timetable_slots(
    skip: int = 0,
    limit: int = 100,
    department_id: int = None,
    class_id: int = None,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """Get timetable slots configuration."""
    query = db.query(models.TimetableSlots).filter(models.TimetableSlots.is_active == True)
    
    if department_id:
        query = query.filter(models.TimetableSlots.department_id == department_id)
    if class_id:
        query = query.filter(models.TimetableSlots.class_id == class_id)
    
    slots = query.offset(skip).limit(limit).all()
    return slots

# User routes
@router.post("/users", response_model=schemas.User)
def create_user(
    user: schemas.UserCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Create a new user."""
    from app.auth import hash_password
    
    # Hash the password
    hashed_password = hash_password(user.password)
    user_data = user.dict(exclude={'password', 'confirmPassword'})
    user_data['password_hash'] = hashed_password
    
    db_user = models.User(**user_data)
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

@router.get("/users", response_model=List[schemas.User])
def get_users(
    skip: int = 0,
    limit: int = 100,
    role: str = None,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Get all users, optionally filtered by role."""
    query = db.query(models.User)
    if role:
        query = query.filter(models.User.role == role)
    
    users = query.offset(skip).limit(limit).all()
    return users

@router.get("/users/{user_id}", response_model=schemas.User)
def get_user(
    user_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Get user by ID."""
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

@router.put("/users/{user_id}", response_model=schemas.User)
def update_user(
    user_id: int,
    user: schemas.UserUpdate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Update user."""
    db_user = db.query(models.User).filter(models.User.id == user_id).first()
    if not db_user:
        raise HTTPException(status_code=404, detail="User not found")
    
    for field, value in user.dict(exclude_unset=True).items():
        setattr(db_user, field, value)
    
    db.commit()
    db.refresh(db_user)
    return db_user

@router.delete("/users/{user_id}")
def delete_user(
    user_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Delete user."""
    db_user = db.query(models.User).filter(models.User.id == user_id).first()
    if not db_user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Don't allow deleting yourself
    if db_user.id == current_user.id:
        raise HTTPException(status_code=400, detail="Cannot delete your own account")
    
    db.delete(db_user)
    db.commit()
    return {"message": "User deleted"}

# Schedule Entry routes
@router.post("/schedule-entries", response_model=schemas.ScheduleEntry)
def create_schedule_entry(
    entry: schemas.ScheduleEntryCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Create a new schedule entry."""
    db_entry = models.ScheduleEntry(**entry.dict())
    db.add(db_entry)
    db.commit()
    db.refresh(db_entry)
    return db_entry

@router.get("/schedule-entries", response_model=List[schemas.ScheduleEntry])
def get_schedule_entries(
    skip: int = 0,
    limit: int = 100,
    timetable_id: int = None,
    day_index: int = None,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """Get all schedule entries with optional filters."""
    query = db.query(models.ScheduleEntry)
    
    if timetable_id:
        query = query.filter(models.ScheduleEntry.timetable_id == timetable_id)
    if day_index is not None:
        query = query.filter(models.ScheduleEntry.day_index == day_index)
    
    entries = query.offset(skip).limit(limit).all()
    return entries

@router.get("/schedule-entries/{entry_id}", response_model=schemas.ScheduleEntry)
def get_schedule_entry(
    entry_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """Get schedule entry by ID."""
    entry = db.query(models.ScheduleEntry).filter(models.ScheduleEntry.id == entry_id).first()
    if not entry:
        raise HTTPException(status_code=404, detail="Schedule entry not found")
    return entry

@router.put("/schedule-entries/{entry_id}", response_model=schemas.ScheduleEntry)
def update_schedule_entry(
    entry_id: int,
    entry: schemas.ScheduleEntryCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Update schedule entry."""
    db_entry = db.query(models.ScheduleEntry).filter(models.ScheduleEntry.id == entry_id).first()
    if not db_entry:
        raise HTTPException(status_code=404, detail="Schedule entry not found")
    
    for field, value in entry.dict().items():
        setattr(db_entry, field, value)
    
    db.commit()
    db.refresh(db_entry)
    return db_entry

@router.delete("/schedule-entries/{entry_id}")
def delete_schedule_entry(
    entry_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Delete schedule entry."""
    db_entry = db.query(models.ScheduleEntry).filter(models.ScheduleEntry.id == entry_id).first()
    if not db_entry:
        raise HTTPException(status_code=404, detail="Schedule entry not found")
    
    db.delete(db_entry)
    db.commit()
    return {"message": "Schedule entry deleted"}

# Timetable CRUD routes (basic operations, generation is in timetable.py)
@router.post("/timetables", response_model=schemas.Timetable)
def create_timetable(
    timetable: schemas.TimetableCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Create a new timetable."""
    timetable_data = timetable.dict()
    timetable_data['created_by_user_id'] = current_user.id
    
    db_timetable = models.Timetable(**timetable_data)
    db.add(db_timetable)
    db.commit()
    db.refresh(db_timetable)
    return db_timetable

@router.get("/timetables", response_model=List[schemas.Timetable])
def get_timetables(
    skip: int = 0,
    limit: int = 100,
    class_id: int = None,
    is_published: bool = None,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """Get all timetables with optional filters."""
    query = db.query(models.Timetable)
    
    if class_id:
        query = query.filter(models.Timetable.class_id == class_id)
    if is_published is not None:
        query = query.filter(models.Timetable.is_published == is_published)
    
    timetables = query.offset(skip).limit(limit).all()
    return timetables

@router.get("/timetables/{timetable_id}", response_model=schemas.Timetable)
def get_timetable_by_id(
    timetable_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_active_user)
):
    """Get timetable by ID."""
    timetable = db.query(models.Timetable).filter(models.Timetable.id == timetable_id).first()
    if not timetable:
        raise HTTPException(status_code=404, detail="Timetable not found")
    return timetable

@router.put("/timetables/{timetable_id}", response_model=schemas.Timetable)
def update_timetable(
    timetable_id: int,
    timetable: schemas.TimetableUpdate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Update timetable."""
    db_timetable = db.query(models.Timetable).filter(models.Timetable.id == timetable_id).first()
    if not db_timetable:
        raise HTTPException(status_code=404, detail="Timetable not found")
    
    for field, value in timetable.dict(exclude_unset=True).items():
        setattr(db_timetable, field, value)
    
    db.commit()
    db.refresh(db_timetable)
    return db_timetable

@router.delete("/timetables/{timetable_id}")
def delete_timetable(
    timetable_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Delete timetable."""
    db_timetable = db.query(models.Timetable).filter(models.Timetable.id == timetable_id).first()
    if not db_timetable:
        raise HTTPException(status_code=404, detail="Timetable not found")
    
    # Delete related schedule entries first
    db.query(models.ScheduleEntry).filter(models.ScheduleEntry.timetable_id == timetable_id).delete()
    
    db.delete(db_timetable)
    db.commit()
    return {"message": "Timetable deleted"}

@router.put("/timetables/{timetable_id}/publish")
def publish_timetable(
    timetable_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Publish a timetable."""
    timetable = db.query(models.Timetable).filter(models.Timetable.id == timetable_id).first()
    if not timetable:
        raise HTTPException(status_code=404, detail="Timetable not found")
    
    timetable.is_published = True
    db.commit()
    return {"message": "Timetable published successfully"}

@router.put("/timetables/{timetable_id}/unpublish")
def unpublish_timetable(
    timetable_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_coordinator_or_admin)
):
    """Unpublish a timetable."""
    timetable = db.query(models.Timetable).filter(models.Timetable.id == timetable_id).first()
    if not timetable:
        raise HTTPException(status_code=404, detail="Timetable not found")
    
    timetable.is_published = False
    db.commit()
    return {"message": "Timetable unpublished successfully"}
