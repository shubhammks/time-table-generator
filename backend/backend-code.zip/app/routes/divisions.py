from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.models import Division
from app.dependencies import get_db
from pydantic import BaseModel

router = APIRouter()

class DivisionCreate(BaseModel):
    name: str
    class_id: int

class DivisionUpdate(BaseModel):
    name: str
    class_id: int

@router.post("/")
def create_division(div: DivisionCreate, db: Session = Depends(get_db)):
    new_div = Division(**div.dict())
    db.add(new_div)
    db.commit()
    db.refresh(new_div)
    return new_div

@router.get("/")
def get_divisions(db: Session = Depends(get_db)):
    return db.query(Division).all()

@router.get("/{div_id}")
def get_division(div_id: int, db: Session = Depends(get_db)):
    div = db.query(Division).get(div_id)
    if not div:
        raise HTTPException(status_code=404, detail="Division not found")
    return div

@router.put("/{div_id}")
def update_division(div_id: int, div_update: DivisionUpdate, db: Session = Depends(get_db)):
    div = db.query(Division).get(div_id)
    if not div:
        raise HTTPException(status_code=404, detail="Division not found")
    for key, value in div_update.dict().items():
        setattr(div, key, value)
    db.commit()
    db.refresh(div)
    return div

@router.delete("/{div_id}")
def delete_division(div_id: int, db: Session = Depends(get_db)):
    div = db.query(Division).get(div_id)
    if not div:
        raise HTTPException(status_code=404, detail="Division not found")
    db.delete(div)
    db.commit()
    return {"detail": "Division deleted"}
