from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.models import Teacher
from app.dependencies import get_db

router = APIRouter()

@router.get("/teachers")
def get_teachers(db: Session = Depends(get_db)):
    teachers = db.query(Teacher).all()
    return [{"id": t.id, "name": t.name, "department_id": t.department_id} for t in teachers]

@router.get("/teachers/{teacher_id}")
def get_teacher_by_id(teacher_id: int, db: Session = Depends(get_db)):
    teacher = db.query(Teacher).filter(Teacher.id == teacher_id).first()
    if not teacher:
        raise HTTPException(status_code=404, detail="Teacher not found")
    return teacher