"""
Greedy Optimization Algorithm for Timetable Generation - Phase 2

This module implements local search optimization to improve timetable quality
by optimizing soft constraints while maintaining hard constraint satisfaction.
"""

from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass
from enum import Enum
import random
import math
import time
import logging
from collections import defaultdict

from sqlalchemy.orm import Session
from app import models
from app.config import settings
from app.services.csp_solver import CSPSolution, Assignment, Variable, Domain, CSPSolver

# Set up logging
logger = logging.getLogger(__name__)

class OptimizationType(Enum):
    """Types of optimization moves."""
    SWAP_SAME_DAY = "swap_same_day"
    SWAP_DIFFERENT_DAYS = "swap_different_days"
    MOVE_TO_EARLIER = "move_to_earlier"
    MOVE_TO_LATER = "move_to_later"
    SWAP_LAB_BLOCKS = "swap_lab_blocks"

@dataclass
class OptimizationMove:
    """Represents a potential optimization move."""
    move_type: OptimizationType
    assignment1: Assignment
    assignment2: Optional[Assignment] = None
    new_domain1: Optional[Domain] = None
    new_domain2: Optional[Domain] = None
    score_improvement: float = 0.0

@dataclass
class OptimizationResult:
    """Result of optimization process."""
    solution: CSPSolution
    initial_score: float
    final_score: float
    moves_applied: int
    iterations: int
    time_taken: float
    convergence_history: List[float]

class TimetableOptimizer:
    """Greedy optimization algorithm for timetable improvement."""
    
    def __init__(self, db: Session, mode: str = 'school'):
        self.db = db
        self.mode = mode
        self.max_iterations = settings.OPTIMIZER_MAX_ITERATIONS
        self.temperature = 100.0  # For simulated annealing (optional)
        self.cooling_rate = 0.95
        self.break_slots = set()  # Will be initialized during optimization
        self.stats = {
            'moves_evaluated': 0,
            'moves_applied': 0,
            'score_improvements': 0,
            'local_maxima_escaped': 0
        }
        
        # Scoring weights (can be made configurable)
        self.weights = {
            'teacher_gaps': 10.0,
            'student_gaps': 15.0,
            'uneven_distribution': 8.0,
            'late_heavy_schedule': 5.0,
            'core_subjects_morning': 3.0,
            'lab_spacing': 7.0,
            'teacher_workload_balance': 6.0
        }
        
        random.seed(settings.RANDOM_SEED)
    
    def optimize(self, solution: CSPSolution, class_id: int, department_id: int) -> OptimizationResult:
        """Main optimization method."""
        if not solution.is_complete or solution.conflicts:
            logger.warning("Cannot optimize incomplete or conflicted solution")
            return OptimizationResult(
                solution=solution,
                initial_score=0,
                final_score=0,
                moves_applied=0,
                iterations=0,
                time_taken=0,
                convergence_history=[]
            )
        
        # Initialize break slots (load from CSP solver or create defaults)
        self._initialize_break_slots(department_id, class_id)
        
        start_time = time.time()
        logger.info(f"Starting timetable optimization for class_id={class_id}")
        
        # Calculate initial score
        initial_score = self._calculate_score(solution, class_id, department_id)
        current_score = initial_score
        
        convergence_history = [current_score]
        moves_applied = 0
        
        # Main optimization loop
        for iteration in range(self.max_iterations):
            # Find best improving move
            best_move = self._find_best_move(solution, class_id, department_id)
            
            if not best_move or best_move.score_improvement <= 0:
                # Try simulated annealing to escape local maxima
                if self.temperature > 1.0:
                    best_move = self._find_random_move(solution, class_id, department_id)
                    if best_move and self._accept_move(best_move.score_improvement):
                        self.stats['local_maxima_escaped'] += 1
                    else:
                        best_move = None
                else:
                    # No improving moves found, converged
                    break
            
            if best_move:
                # Apply the move
                self._apply_move(solution, best_move)
                current_score += best_move.score_improvement
                convergence_history.append(current_score)
                moves_applied += 1
                self.stats['moves_applied'] += 1
                
                if best_move.score_improvement > 0:
                    self.stats['score_improvements'] += 1
            
            # Cool down temperature for simulated annealing
            self.temperature *= self.cooling_rate
            
            # Early termination if score hasn't improved in many iterations
            if len(convergence_history) > 20:
                recent_scores = convergence_history[-20:]
                if max(recent_scores) - min(recent_scores) < 0.01:
                    logger.info(f"Converged at iteration {iteration}")
                    break
        
        time_taken = time.time() - start_time
        
        logger.info(f"Optimization completed: {moves_applied} moves, "
                   f"score {initial_score:.2f} -> {current_score:.2f}, "
                   f"time: {time_taken:.2f}s")
        
        return OptimizationResult(
            solution=solution,
            initial_score=initial_score,
            final_score=current_score,
            moves_applied=moves_applied,
            iterations=iteration + 1,
            time_taken=time_taken,
            convergence_history=convergence_history
        )
    
    def _calculate_score(self, solution: CSPSolution, class_id: int, department_id: int) -> float:
        """Calculate the overall quality score of a timetable."""
        score = 0.0
        
        # Get all teachers and divisions for scoring
        teachers = self._get_teachers(department_id)
        divisions = self._get_divisions(class_id)
        
        # Teacher gaps penalty
        score -= self.weights['teacher_gaps'] * self._calculate_teacher_gaps(solution, teachers)
        
        # Student gaps penalty
        score -= self.weights['student_gaps'] * self._calculate_student_gaps(solution, divisions)
        
        # Uneven distribution penalty
        score -= self.weights['uneven_distribution'] * self._calculate_uneven_distribution(solution)
        
        # Late-heavy schedule penalty
        score -= self.weights['late_heavy_schedule'] * self._calculate_late_heavy_penalty(solution)
        
        # Core subjects in morning bonus
        score += self.weights['core_subjects_morning'] * self._calculate_morning_core_bonus(solution)
        
        # Lab spacing penalty
        score -= self.weights['lab_spacing'] * self._calculate_lab_spacing_penalty(solution)
        
        # Teacher workload balance
        score -= self.weights['teacher_workload_balance'] * self._calculate_workload_imbalance(solution, teachers)
        
        return score
    
    def _calculate_teacher_gaps(self, solution: CSPSolution, teachers: List[models.Teacher]) -> float:
        """Calculate penalty for gaps in teacher schedules."""
        total_penalty = 0.0
        
        for teacher in teachers:
            teacher_assignments = [a for a in solution.assignments 
                                 if a.variable.teacher_id == teacher.id]
            
            # Group by day
            daily_assignments = defaultdict(list)
            for assignment in teacher_assignments:
                daily_assignments[assignment.domain.day_index].append(assignment)
            
            # Calculate gaps for each day
            for day_assignments in daily_assignments.values():
                if len(day_assignments) <= 1:
                    continue
                
                # Sort by period
                day_assignments.sort(key=lambda a: a.domain.period_index)
                
                # Count gaps between assignments
                for i in range(len(day_assignments) - 1):
                    current_end = (day_assignments[i].domain.period_index + 
                                 day_assignments[i].variable.consecutive_slots_needed)
                    next_start = day_assignments[i + 1].domain.period_index
                    
                    gap_size = next_start - current_end
                    if gap_size > 0:
                        total_penalty += gap_size
        
        return total_penalty
    
    def _calculate_student_gaps(self, solution: CSPSolution, divisions: List[models.Division]) -> float:
        """Calculate penalty for gaps in student schedules."""
        total_penalty = 0.0
        
        for division in divisions:
            division_assignments = [a for a in solution.assignments 
                                  if a.variable.division_id == division.id]
            
            # Group by day
            daily_assignments = defaultdict(list)
            for assignment in division_assignments:
                daily_assignments[assignment.domain.day_index].append(assignment)
            
            # Calculate gaps for each day
            for day_assignments in daily_assignments.values():
                if len(day_assignments) <= 1:
                    continue
                
                # Sort by period
                day_assignments.sort(key=lambda a: a.domain.period_index)
                
                # Count gaps between assignments
                for i in range(len(day_assignments) - 1):
                    current_end = (day_assignments[i].domain.period_index + 
                                 day_assignments[i].variable.consecutive_slots_needed)
                    next_start = day_assignments[i + 1].domain.period_index
                    
                    gap_size = next_start - current_end
                    if gap_size > 0:
                        # Student gaps are more penalized than teacher gaps
                        total_penalty += gap_size * 1.5
        
        return total_penalty
    
    def _calculate_uneven_distribution(self, solution: CSPSolution) -> float:
        """Calculate penalty for uneven distribution of periods across days."""
        # Group assignments by division and day
        division_daily_count = defaultdict(lambda: defaultdict(int))
        
        for assignment in solution.assignments:
            if assignment.variable.division_id:
                division_daily_count[assignment.variable.division_id][assignment.domain.day_index] += 1
        
        total_penalty = 0.0
        for division_id, daily_counts in division_daily_count.items():
            if not daily_counts:
                continue
            
            counts = list(daily_counts.values())
            if len(counts) <= 1:
                continue
            
            # Calculate standard deviation
            mean_count = sum(counts) / len(counts)
            variance = sum((c - mean_count) ** 2 for c in counts) / len(counts)
            std_dev = math.sqrt(variance)
            
            total_penalty += std_dev
        
        return total_penalty
    
    def _calculate_late_heavy_penalty(self, solution: CSPSolution) -> float:
        """Calculate penalty for having too many classes in late periods."""
        total_penalty = 0.0
        
        for assignment in solution.assignments:
            # Penalize periods after 4th period more heavily
            if assignment.domain.period_index >= 4:
                penalty_factor = (assignment.domain.period_index - 3) * 0.5
                total_penalty += penalty_factor
        
        return total_penalty
    
    def _calculate_morning_core_bonus(self, solution: CSPSolution) -> float:
        """Calculate bonus for having core subjects in morning periods."""
        core_subjects = {'Mathematics', 'Science', 'English', 'Physics', 'Chemistry', 'Biology'}
        total_bonus = 0.0
        
        for assignment in solution.assignments:
            if (assignment.variable.subject_name in core_subjects and
                assignment.domain.period_index <= 2):  # First 3 periods
                total_bonus += 1.0
        
        return total_bonus
    
    def _calculate_lab_spacing_penalty(self, solution: CSPSolution) -> float:
        """Calculate penalty for poor lab spacing."""
        total_penalty = 0.0
        
        # Group lab assignments by subject and division
        lab_groups = defaultdict(list)
        for assignment in solution.assignments:
            if assignment.variable.is_lab:
                key = (assignment.variable.subject_id, assignment.variable.division_id)
                lab_groups[key].append(assignment)
        
        # Check spacing within each group
        for lab_assignments in lab_groups.values():
            if len(lab_assignments) <= 1:
                continue
            
            # Sort by day and period
            lab_assignments.sort(key=lambda a: (a.domain.day_index, a.domain.period_index))
            
            for i in range(len(lab_assignments) - 1):
                current = lab_assignments[i]
                next_lab = lab_assignments[i + 1]
                
                # Penalty for labs on consecutive days
                if next_lab.domain.day_index - current.domain.day_index == 1:
                    total_penalty += 2.0
                
                # Penalty for labs on the same day
                elif next_lab.domain.day_index == current.domain.day_index:
                    total_penalty += 5.0
        
        return total_penalty
    
    def _calculate_workload_imbalance(self, solution: CSPSolution, teachers: List[models.Teacher]) -> float:
        """Calculate penalty for uneven teacher workload distribution."""
        # Count assignments per teacher per day
        teacher_daily_load = defaultdict(lambda: defaultdict(int))
        
        for assignment in solution.assignments:
            teacher_daily_load[assignment.variable.teacher_id][assignment.domain.day_index] += 1
        
        total_penalty = 0.0
        for teacher_id, daily_loads in teacher_daily_load.items():
            if not daily_loads:
                continue
            
            loads = list(daily_loads.values())
            if len(loads) <= 1:
                continue
            
            # Calculate imbalance
            mean_load = sum(loads) / len(loads)
            variance = sum((load - mean_load) ** 2 for load in loads) / len(loads)
            total_penalty += math.sqrt(variance)
        
        return total_penalty
    
    def _find_best_move(self, solution: CSPSolution, class_id: int, department_id: int) -> Optional[OptimizationMove]:
        """Find the best improving move."""
        best_move = None
        best_improvement = 0
        
        current_score = self._calculate_score(solution, class_id, department_id)
        
        # Try different types of moves
        assignments = solution.assignments
        
        # Try swapping assignments on the same day
        for i, assignment1 in enumerate(assignments):
            for j, assignment2 in enumerate(assignments[i+1:], i+1):
                if assignment1.domain.day_index == assignment2.domain.day_index:
                    # Try swapping their time slots
                    move = self._create_swap_move(assignment1, assignment2)
                    if move and self._is_move_valid(solution, move):
                        improvement = self._evaluate_move(solution, move, class_id, department_id)
                        if improvement > best_improvement:
                            best_improvement = improvement
                            best_move = move
        
        # Try moving assignments to earlier/later slots
        for assignment in assignments:
            # Try moving to earlier periods in the same day
            for earlier_period in range(assignment.domain.period_index):
                if (assignment.domain.day_index, earlier_period) not in self.break_slots:
                    new_domain = Domain(
                        day_index=assignment.domain.day_index,
                        period_index=earlier_period,
                        room_id=assignment.domain.room_id,
                        room_type=assignment.domain.room_type
                    )
                    move = OptimizationMove(
                        move_type=OptimizationType.MOVE_TO_EARLIER,
                        assignment1=assignment,
                        new_domain1=new_domain
                    )
                    
                    if self._is_move_valid(solution, move):
                        improvement = self._evaluate_move(solution, move, class_id, department_id)
                        if improvement > best_improvement:
                            best_improvement = improvement
                            best_move = move
        
        if best_move:
            best_move.score_improvement = best_improvement
            self.stats['moves_evaluated'] += 1
        
        return best_move
    
    def _find_random_move(self, solution: CSPSolution, class_id: int, department_id: int) -> Optional[OptimizationMove]:
        """Find a random move for simulated annealing."""
        assignments = solution.assignments
        if len(assignments) < 2:
            return None
        
        # Random swap move
        assignment1, assignment2 = random.sample(assignments, 2)
        
        # Only swap if they're on the same day to avoid major disruption
        if assignment1.domain.day_index == assignment2.domain.day_index:
            move = self._create_swap_move(assignment1, assignment2)
            if move and self._is_move_valid(solution, move):
                improvement = self._evaluate_move(solution, move, class_id, department_id)
                move.score_improvement = improvement
                return move
        
        return None
    
    def _accept_move(self, score_improvement: float) -> bool:
        """Decide whether to accept a move using simulated annealing."""
        if score_improvement >= 0:
            return True
        
        if self.temperature <= 0:
            return False
        
        probability = math.exp(score_improvement / self.temperature)
        return random.random() < probability
    
    def _apply_move(self, solution: CSPSolution, move: OptimizationMove):
        """Apply an optimization move to the solution."""
        if move.move_type == OptimizationType.SWAP_SAME_DAY:
            # Swap the domains of two assignments
            if move.assignment2:
                temp_domain = move.assignment1.domain
                move.assignment1.domain = move.assignment2.domain
                move.assignment2.domain = temp_domain
        
        elif move.move_type in [OptimizationType.MOVE_TO_EARLIER, OptimizationType.MOVE_TO_LATER]:
            # Move assignment to new domain
            if move.new_domain1:
                move.assignment1.domain = move.new_domain1
        
        # Update any other assignments if needed
        if move.assignment2 and move.new_domain2:
            move.assignment2.domain = move.new_domain2
    
    def _get_teachers(self, department_id: int) -> List[models.Teacher]:
        """Get all teachers for the department."""
        return self.db.query(models.Teacher).filter(
            models.Teacher.department_id == department_id
        ).all()
    
    def _get_divisions(self, class_id: int) -> List[models.Division]:
        """Get all divisions for the class."""
        return self.db.query(models.Division).filter(
            models.Division.class_id == class_id
        ).all()
    
    def _create_swap_move(self, assignment1: Assignment, assignment2: Assignment) -> Optional[OptimizationMove]:
        """Create a swap move between two assignments."""
        # Don't swap if assignments would create conflicts
        if (assignment1.variable.teacher_id == assignment2.variable.teacher_id or
            assignment1.variable.division_id == assignment2.variable.division_id):
            return None
        
        return OptimizationMove(
            move_type=OptimizationType.SWAP_SAME_DAY,
            assignment1=assignment1,
            assignment2=assignment2
        )
    
    def _is_move_valid(self, solution: CSPSolution, move: OptimizationMove) -> bool:
        """Check if a move would create conflicts."""
        # Create temporary assignments to test
        temp_assignment1 = Assignment(move.assignment1.variable, move.new_domain1 or move.assignment2.domain)
        
        # Check conflicts with other assignments
        for assignment in solution.assignments:
            if assignment != move.assignment1 and assignment != move.assignment2:
                conflicts = temp_assignment1.conflicts_with(assignment)
                if conflicts:
                    return False
        
        # If it's a swap, check the second assignment too
        if move.assignment2:
            temp_assignment2 = Assignment(move.assignment2.variable, move.new_domain2 or move.assignment1.domain)
            for assignment in solution.assignments:
                if assignment != move.assignment1 and assignment != move.assignment2:
                    conflicts = temp_assignment2.conflicts_with(assignment)
                    if conflicts:
                        return False
        
        return True
    
    def _evaluate_move(self, solution: CSPSolution, move: OptimizationMove, class_id: int, department_id: int) -> float:
        """Evaluate the score improvement of a move."""
        # Calculate current score
        current_score = self._calculate_score(solution, class_id, department_id)
        
        # Apply move temporarily
        original_domain1 = move.assignment1.domain
        original_domain2 = move.assignment2.domain if move.assignment2 else None
        
        # Apply the move
        self._apply_move(solution, move)
        
        # Calculate new score
        new_score = self._calculate_score(solution, class_id, department_id)
        
        # Restore original state
        move.assignment1.domain = original_domain1
        if move.assignment2 and original_domain2:
            move.assignment2.domain = original_domain2
        
        return new_score - current_score
    
    def _initialize_break_slots(self, department_id: int, class_id: int):
        """Initialize break slots from timetable slots configuration."""
        slots = self.db.query(models.TimetableSlots).filter(
            models.TimetableSlots.department_id == department_id,
            models.TimetableSlots.is_active == True
        ).all()
        
        # If no slots configured, use default breaks
        if not slots:
            # Default breaks at period 2 (short break) and period 5 (lunch)
            for day in range(6):
                self.break_slots.add((day, 2))
                self.break_slots.add((day, 5))
        else:
            # Load configured break slots
            for slot in slots:
                if slot.is_break:
                    self.break_slots.add((slot.day_index, slot.period_index))

# Legacy functions for backward compatibility
def score_timetable(schedule):
    """Legacy function - simplified scoring"""
    score = 0
    for day in set(entry["day"] for entry in schedule):
        periods = sorted([entry["period"] for entry in schedule if entry["day"] == day])
        # Penalize large gaps
        for i in range(1, len(periods)):
            if periods[i] - periods[i - 1] > 1:
                score -= 2
        # Reward balanced load
        score += len(periods)
    return score

def optimize_timetable(schedule, iterations=1000):
    """Legacy function - simplified optimization"""
    best_schedule = schedule[:]
    best_score = score_timetable(best_schedule)

    for _ in range(iterations):
        new_schedule = best_schedule[:]
        # Random swap
        if len(new_schedule) > 2:
            i, j = random.sample(range(len(new_schedule)), 2)
            new_schedule[i], new_schedule[j] = new_schedule[j], new_schedule[i]

        new_score = score_timetable(new_schedule)
        if new_score > best_score:
            best_schedule, best_score = new_schedule, new_score

    return best_schedule
