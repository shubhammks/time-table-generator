"""
Constraint Satisfaction Problem (CSP) Solver for Timetable Generation - Phase 1

This module implements the backtracking algorithm with constraint satisfaction
to ensure all hard constraints are satisfied for timetable generation.
"""

from typing import Dict, List, Set, Tuple, Optional, Any
from dataclasses import dataclass, field
from enum import Enum
import random
import time
import logging
from collections import defaultdict

from sqlalchemy.orm import Session
from app import models
from app.config import settings

# Set up logging
logger = logging.getLogger(__name__)

class ConstraintType(Enum):
    """Types of constraints in timetable generation."""
    TEACHER_CONFLICT = "teacher_conflict"
    ROOM_CONFLICT = "room_conflict"
    DIVISION_CONFLICT = "division_conflict"
    LAB_CONSECUTIVE = "lab_consecutive"
    LAB_PER_DAY_LIMIT = "lab_per_day_limit"
    BREAK_SLOTS = "break_slots"
    FIXED_CLASSROOM = "fixed_classroom"
    PERIOD_LIMITS = "period_limits"
    TWICE_IN_DAY = "twice_in_day"

@dataclass
class Variable:
    """Represents a variable in the CSP - a single subject occurrence to be scheduled."""
    id: str
    subject_id: int
    teacher_id: int
    division_id: Optional[int]
    batch_id: Optional[int]
    subject_type: str  # 'lecture', 'lab', 'tutorial'
    is_lab: bool = False
    consecutive_slots_needed: int = 1
    subject_name: str = ""
    teacher_name: str = ""
    
    def __post_init__(self):
        self.is_lab = self.subject_type == 'lab'
        if self.is_lab:
            self.consecutive_slots_needed = 2

@dataclass
class Domain:
    """Represents the domain of possible assignments for a variable."""
    day_index: int
    period_index: int
    room_id: int
    room_type: str
    
    def __hash__(self):
        return hash((self.day_index, self.period_index, self.room_id))

@dataclass
class Assignment:
    """Represents an assignment of a variable to a domain value."""
    variable: Variable
    domain: Domain
    
    def conflicts_with(self, other: 'Assignment') -> List[ConstraintType]:
        """Check if this assignment conflicts with another."""
        conflicts = []
        
        # Teacher conflict
        if (self.variable.teacher_id == other.variable.teacher_id and
            self.domain.day_index == other.domain.day_index and
            self._periods_overlap(other)):
            conflicts.append(ConstraintType.TEACHER_CONFLICT)
        
        # Room conflict
        if (self.domain.room_id == other.domain.room_id and
            self.domain.day_index == other.domain.day_index and
            self._periods_overlap(other)):
            conflicts.append(ConstraintType.ROOM_CONFLICT)
        
        # Division conflict (same division can't have two subjects at same time)
        if (self.variable.division_id and other.variable.division_id and
            self.variable.division_id == other.variable.division_id and
            self.domain.day_index == other.domain.day_index and
            self._periods_overlap(other)):
            conflicts.append(ConstraintType.DIVISION_CONFLICT)
        
        return conflicts
    
    def _periods_overlap(self, other: 'Assignment') -> bool:
        """Check if the periods of two assignments overlap."""
        self_periods = set(range(
            self.domain.period_index,
            self.domain.period_index + self.variable.consecutive_slots_needed
        ))
        other_periods = set(range(
            other.domain.period_index,
            other.domain.period_index + other.variable.consecutive_slots_needed
        ))
        return bool(self_periods & other_periods)

@dataclass
class CSPSolution:
    """Represents a solution to the CSP."""
    assignments: List[Assignment] = field(default_factory=list)
    is_complete: bool = False
    conflicts: List[Tuple[Assignment, Assignment, List[ConstraintType]]] = field(default_factory=list)
    stats: Dict[str, Any] = field(default_factory=dict)

class CSPSolver:
    """Constraint Satisfaction Problem solver for timetable generation."""
    
    def __init__(self, db: Session, mode: str = 'school'):
        self.db = db
        self.mode = mode
        self.variables: List[Variable] = []
        self.domains: Dict[str, Set[Domain]] = {}
        self.assignments: Dict[str, Assignment] = {}
        self.break_slots: Set[Tuple[int, int]] = set()  # (day_index, period_index)
        self.class_period_limits: Dict[int, Dict[int, int]] = {}  # class_id -> {day_index: max_periods}
        self.fixed_classrooms: Dict[int, int] = {}  # division_id -> room_id
        self.subjects_cache: Dict[int, Any] = {}  # Cache for subject data
        self.max_recursion_depth = settings.CSP_MAX_ITERATIONS
        self.timeout_seconds = settings.CSP_TIME_LIMIT_SECONDS
        self.start_time = 0
        self.stats = {
            'assignments_tried': 0,
            'backtracks': 0,
            'constraint_checks': 0,
            'time_taken': 0
        }
        
        # Set random seed for reproducible behavior
        random.seed(settings.RANDOM_SEED)
    
    def solve(self, class_id: int, department_id: int, division_id: int = None) -> CSPSolution:
        """Main solving method."""
        logger.info(f"Starting CSP solver for class_id={class_id}, department_id={department_id}, mode={self.mode}")
        self.start_time = time.time()
        
        try:
            # Initialize the problem
            self._initialize_problem(class_id, department_id, division_id)
            
            # Solve using backtracking
            solution = self._backtrack()
            
            # Calculate statistics
            self.stats['time_taken'] = time.time() - self.start_time
            solution.stats = self.stats.copy()
            
            logger.info(f"CSP solver completed. Success: {solution.is_complete}, Time: {self.stats['time_taken']:.2f}s")
            return solution
            
        except Exception as e:
            logger.error(f"CSP solver error: {str(e)}")
            solution = CSPSolution()
            solution.stats = self.stats.copy()
            solution.stats['error'] = str(e)
            return solution
    
    def _initialize_problem(self, class_id: int, department_id: int, division_id: int = None):
        """Initialize variables, domains, and constraints."""
        # Load timetable slots configuration
        self._load_timetable_slots(department_id, class_id)
        
        # Generate variables from subject-teacher assignments
        self._generate_variables(class_id, division_id)
        
        # Cache subject data to avoid repeated queries
        self._cache_subject_data(class_id)
        
        # Generate domains for each variable
        self._generate_domains(department_id)
        
        # Apply initial constraint filtering
        self._filter_domains_by_constraints()
        
        logger.info(f"Problem initialized: {len(self.variables)} variables, "
                   f"avg domain size: {self._average_domain_size():.1f}")
    
    def _load_timetable_slots(self, department_id: int, class_id: int):
        """Load timetable slot configuration and identify breaks."""
        slots = self.db.query(models.TimetableSlots).filter(
            models.TimetableSlots.department_id == department_id,
            models.TimetableSlots.is_active == True
        ).all()
        
        # If no slots configured, create default schedule
        if not slots:
            logger.info("No timetable slots found, creating default schedule")
            # Create default 6-period schedule with breaks
            default_periods = 8  # 0-7, with breaks at 2 and 5
            for day in range(6):  # Monday to Saturday
                for period in range(default_periods):
                    if period == 2:  # Short break
                        self.break_slots.add((day, period))
                    elif period == 5:  # Lunch break
                        self.break_slots.add((day, period))
            
            # Set default period limits (6 actual periods per day)
            self.class_period_limits[class_id] = {day: 8 for day in range(6)}
            return
        
        # If class-specific slots exist, use those; otherwise use department-wide
        class_slots = [s for s in slots if s.class_id == class_id]
        if class_slots:
            slots = class_slots
        
        # Identify break slots
        for slot in slots:
            if slot.is_break:
                self.break_slots.add((slot.day_index, slot.period_index))
        
        # Build period limits per day per class
        day_periods = defaultdict(int)
        for slot in slots:
            if not slot.is_break:
                day_periods[slot.day_index] = max(day_periods[slot.day_index], slot.period_index + 1)
        
        # Ensure we have at least some periods per day
        for day in range(6):
            if day not in day_periods:
                day_periods[day] = 6  # Default 6 periods per day
        
        self.class_period_limits[class_id] = dict(day_periods)
        
        # Load fixed classroom assignments for school mode
        if self.mode == 'school':
            divisions = self.db.query(models.Division).filter(
                models.Division.class_id == class_id
            ).all()
            
            # For now, assign classroom based on a simple rule
            # In a real system, this would be configured
            classrooms = self.db.query(models.Room).filter(
                models.Room.type == models.RoomType.classroom,
                models.Room.department_id == department_id
            ).all()
            
            for i, division in enumerate(divisions):
                if i < len(classrooms):
                    self.fixed_classrooms[division.id] = classrooms[i].id
    
    def _generate_variables(self, class_id: int, division_id: int = None):
        """Generate CSP variables from subject-teacher assignments."""
        # Get all subject-teacher assignments for this class and division
        query = self.db.query(models.SubjectTeacher).join(
            models.Subject
        ).filter(
            models.Subject.class_id == class_id
        )
        
        if division_id:
            query = query.filter(models.SubjectTeacher.division_id == division_id)
        
        assignments = query.all()
        
        variable_id = 0
        for assignment in assignments:
            subject = assignment.subject
            teacher = assignment.teacher
            
            # Create variables for each hour per week
            for hour in range(subject.hours_per_week):
                variable_id += 1
                var = Variable(
                    id=f"var_{variable_id}",
                    subject_id=subject.id,
                    teacher_id=teacher.id,
                    division_id=assignment.division_id,
                    batch_id=assignment.batch_id,
                    subject_type=subject.type.value,
                    subject_name=subject.name,
                    teacher_name=teacher.name
                )
                self.variables.append(var)
        
        logger.info(f"Generated {len(self.variables)} variables for division {division_id}")
        
        # Ensure each batch gets lab/tutorial time
        if division_id:
            self._ensure_batch_lab_allocation(division_id)
    
    def _ensure_batch_lab_allocation(self, division_id: int):
        """Ensure each batch gets 3 lab/tutorial sessions per week with proper conflict management.
        
        Uses the enhanced batch scheduler to ensure:
        1. If batch A1 has lab at 9-11 AM, then A2 and A3 are FREE during that time
        2. A2 and A3 can be assigned to OTHER labs/tutorials at DIFFERENT times
        3. Each batch gets exactly 3 lab/tutorial sessions per week
        4. No batch can have multiple labs on the same day
        """
        from .enhanced_batch_scheduler import EnhancedBatchScheduler
        
        # Get all batches for this division
        batches = self.db.query(models.Batch).filter(
            models.Batch.division_id == division_id
        ).all()
        
        # Get lab and tutorial subjects for this division
        lab_subjects = self.db.query(models.Subject).join(
            models.SubjectTeacher
        ).filter(
            models.Subject.class_id == self.db.query(models.Division).filter(
                models.Division.id == division_id
            ).first().class_id,
            models.Subject.type == 'lab',
            models.SubjectTeacher.division_id == division_id
        ).all()
        
        tutorial_subjects = self.db.query(models.Subject).join(
            models.SubjectTeacher
        ).filter(
            models.Subject.class_id == self.db.query(models.Division).filter(
                models.Division.id == division_id
            ).first().class_id,
            models.Subject.type == 'tutorial',
            models.SubjectTeacher.division_id == division_id
        ).all()
        
        if not batches:
            logger.warning(f"No batches found for division {division_id}")
            return
        
        logger.info(f"Setting up enhanced lab allocation for {len(batches)} batches")
        logger.info(f"Available lab subjects: {len(lab_subjects)}")
        logger.info(f"Available tutorial subjects: {len(tutorial_subjects)}")
        
        # Use the enhanced batch scheduler
        scheduler = EnhancedBatchScheduler(self.db, division_id)
        batch_schedules = scheduler.schedule_batches(batches, lab_subjects, tutorial_subjects)
        
        # Convert the enhanced schedule to CSP variables
        self._convert_schedule_to_variables(batch_schedules, division_id)
        
        # Log final distribution
        logger.info("=== FINAL BATCH SCHEDULE ===")
        for batch_id, schedule in batch_schedules.items():
            logger.info(f"Batch {schedule.batch_number}: {schedule.total_sessions} total sessions")
            logger.info(f"  - Labs: {len(schedule.lab_sessions)}")
            logger.info(f"  - Tutorials: {len(schedule.tutorial_sessions)}")
    
    def _convert_schedule_to_variables(self, batch_schedules: Dict, division_id: int):
        """Convert the enhanced batch schedule to CSP variables."""
        logger.info("Converting enhanced schedule to CSP variables...")
        
        for batch_id, schedule in batch_schedules.items():
            # Process lab sessions
            for day, period in schedule.lab_sessions:
                # Get lab subject for this batch
                lab_subjects = self.db.query(models.Subject).join(
                    models.SubjectTeacher
                ).filter(
                    models.Subject.class_id == self.db.query(models.Division).filter(
                        models.Division.id == division_id
                    ).first().class_id,
                    models.Subject.type == 'lab',
                    models.SubjectTeacher.division_id == division_id
                ).all()
                
                if lab_subjects:
                    lab_subject = lab_subjects[0]  # Use first available lab subject
                    
                    # Get teacher for this subject
                    teacher = self.db.query(models.Teacher).join(
                        models.SubjectTeacher
                    ).filter(
                        models.SubjectTeacher.subject_id == lab_subject.id,
                        models.SubjectTeacher.division_id == division_id
                    ).first()
                    
                    if teacher:
                        var_id = f"enhanced_lab_{batch_id}_{day}_{period}"
                        var = Variable(
                            id=var_id,
                            subject_id=lab_subject.id,
                            teacher_id=teacher.id,
                            division_id=division_id,
                            batch_id=batch_id,
                            subject_type='lab',
                            subject_name=f"{lab_subject.name} (Batch {schedule.batch_number})",
                            teacher_name=teacher.name
                        )
                        self.variables.append(var)
                        logger.info(f"  ✅ Created lab variable for Batch {schedule.batch_number} at Day {day}, Period {period}")
            
            # Process tutorial sessions
            for day, period in schedule.tutorial_sessions:
                # Get tutorial subject for this batch
                tutorial_subjects = self.db.query(models.Subject).join(
                    models.SubjectTeacher
                ).filter(
                    models.Subject.class_id == self.db.query(models.Division).filter(
                        models.Division.id == division_id
                    ).first().class_id,
                    models.Subject.type == 'tutorial',
                    models.SubjectTeacher.division_id == division_id
                ).all()
                
                if tutorial_subjects:
                    tutorial_subject = tutorial_subjects[0]  # Use first available tutorial subject
                    
                    # Get teacher for this subject
                    teacher = self.db.query(models.Teacher).join(
                        models.SubjectTeacher
                    ).filter(
                        models.SubjectTeacher.subject_id == tutorial_subject.id,
                        models.SubjectTeacher.division_id == division_id
                    ).first()
                    
                    if teacher:
                        var_id = f"enhanced_tutorial_{batch_id}_{day}_{period}"
                        var = Variable(
                            id=var_id,
                            subject_id=tutorial_subject.id,
                            teacher_id=teacher.id,
                            division_id=division_id,
                            batch_id=batch_id,
                            subject_type='tutorial',
                            subject_name=f"{tutorial_subject.name} (Batch {schedule.batch_number})",
                            teacher_name=teacher.name
                        )
                        self.variables.append(var)
                        logger.info(f"  ✅ Created tutorial variable for Batch {schedule.batch_number} at Day {day}, Period {period}")
    
    def _generate_domains(self, department_id: int):
        """Generate possible domain values for each variable."""
        # Get all available rooms
        rooms = self.db.query(models.Room).filter(
            models.Room.department_id == department_id
        ).all()
        
        # Pre-load subject class_ids to avoid repeated queries
        subject_ids = {var.subject_id for var in self.variables}
        subjects_map = {}
        if subject_ids:
            subjects = self.db.query(models.Subject).filter(
                models.Subject.id.in_(subject_ids)
            ).all()
            subjects_map = {s.id: s.class_id for s in subjects}
        
        for variable in self.variables:
            domains = set()
            
            # Filter rooms by type
            suitable_rooms = []
            if variable.is_lab:
                suitable_rooms = [r for r in rooms if r.type == models.RoomType.lab]
            elif variable.subject_type == 'tutorial':
                suitable_rooms = [r for r in rooms if r.type == models.RoomType.tutorial]
            else:
                # For lectures, prefer fixed classroom in school mode
                if (self.mode == 'school' and 
                    variable.division_id and 
                    variable.division_id in self.fixed_classrooms):
                    fixed_room_id = self.fixed_classrooms[variable.division_id]
                    suitable_rooms = [r for r in rooms if r.id == fixed_room_id]
                else:
                    suitable_rooms = [r for r in rooms if r.type == models.RoomType.classroom]
            
            # Get class_id from pre-loaded map
            class_id = subjects_map.get(variable.subject_id)
            
            # Use the correct class period limits
            available_limits = {}
            if class_id and class_id in self.class_period_limits:
                available_limits = self.class_period_limits[class_id]
            elif self.class_period_limits:
                # Use the first available class limits as fallback
                available_limits = next(iter(self.class_period_limits.values()))
            else:
                # Default fallback
                available_limits = {day: 8 for day in range(6)}
            
            # Generate domain values
            for day_index in range(6):  # Monday to Saturday
                if day_index in available_limits:
                    max_periods = available_limits[day_index]
                    
                    for period_index in range(max_periods - variable.consecutive_slots_needed + 1):
                        # Skip break slots
                        if any((day_index, period_index + i) in self.break_slots 
                               for i in range(variable.consecutive_slots_needed)):
                            continue
                        
                        for room in suitable_rooms:
                            domain = Domain(
                                day_index=day_index,
                                period_index=period_index,
                                room_id=room.id,
                                room_type=room.type.value
                            )
                            domains.add(domain)
            
            self.domains[variable.id] = domains
        
        logger.info(f"Generated domains with average size: {self._average_domain_size():.1f}")
    
    def _filter_domains_by_constraints(self):
        """Apply initial constraint filtering to reduce domain sizes."""
        # For now, implement basic filtering
        # More sophisticated arc consistency could be added here
        pass
    
    def _backtrack(self) -> CSPSolution:
        """Main backtracking search algorithm with optimizations."""
        if self._is_complete():
            return CSPSolution(
                assignments=list(self.assignments.values()),
                is_complete=True,
                stats=self.stats.copy()
            )
        
        # Check timeout
        if time.time() - self.start_time > self.timeout_seconds:
            logger.warning("CSP solver timed out")
            return self._create_partial_solution()
        
        # Check if we've tried too many assignments
        if self.stats['assignments_tried'] > self.max_recursion_depth:
            logger.warning("CSP solver reached max iterations")
            return self._create_partial_solution()
        
        # Select unassigned variable using MRV heuristic
        variable = self._select_unassigned_variable()
        if not variable:
            return self._create_partial_solution()
        
        # Order domain values using degree heuristic
        domain_values = self._order_domain_values(variable)
        
        # Limit domain exploration to prevent infinite loops
        max_domain_tries = min(10, len(domain_values))
        
        for i, domain_value in enumerate(domain_values[:max_domain_tries]):
            self.stats['assignments_tried'] += 1
            
            # Try assignment
            assignment = Assignment(variable, domain_value)
            
            if self._is_consistent(assignment):
                # Make assignment
                self.assignments[variable.id] = assignment
                
                # Forward checking: remove inconsistent values from other domains
                removed_values = self._forward_check(assignment)
                
                # Recurse
                result = self._backtrack()
                if result.is_complete:
                    return result
                
                # Backtrack
                self.stats['backtracks'] += 1
                del self.assignments[variable.id]
                self._restore_domains(removed_values)
                
                # Early termination if we have a reasonable solution
                if len(self.assignments) >= len(self.variables) * 0.8:  # 80% complete
                    logger.info(f"Early termination with {len(self.assignments)}/{len(self.variables)} assignments")
                    return self._create_partial_solution()
        
        return self._create_partial_solution()
    
    def _is_complete(self) -> bool:
        """Check if all variables are assigned."""
        return len(self.assignments) == len(self.variables)
    
    def _select_unassigned_variable(self) -> Optional[Variable]:
        """Select next unassigned variable using MRV (Minimum Remaining Values) heuristic."""
        unassigned = [v for v in self.variables if v.id not in self.assignments]
        
        if not unassigned:
            return None
        
        # MRV: Choose variable with smallest domain
        min_domain_size = float('inf')
        best_variable = None
        
        for variable in unassigned:
            domain_size = len(self.domains[variable.id])
            
            if domain_size < min_domain_size:
                min_domain_size = domain_size
                best_variable = variable
            elif domain_size == min_domain_size:
                # Tie-breaking: choose variable that constrains others most (degree heuristic)
                if self._count_constraining_relationships(variable) > \
                   self._count_constraining_relationships(best_variable):
                    best_variable = variable
        
        return best_variable
    
    def _order_domain_values(self, variable: Variable) -> List[Domain]:
        """Order domain values using least constraining value heuristic."""
        domain_list = list(self.domains[variable.id])
        
        # For now, use random ordering to ensure variety
        # Could implement least constraining value heuristic
        random.shuffle(domain_list)
        return domain_list
    
    def _is_consistent(self, assignment: Assignment) -> bool:
        """Check if assignment is consistent with existing assignments."""
        self.stats['constraint_checks'] += 1
        
        for existing_assignment in self.assignments.values():
            conflicts = assignment.conflicts_with(existing_assignment)
            if conflicts:
                return False
        
        # Additional constraint checks
        if not self._check_twice_in_day_constraint(assignment):
            return False
        
        return True
    
    def _cache_subject_data(self, class_id: int):
        """Cache subject data to avoid repeated database queries."""
        subjects = self.db.query(models.Subject).filter(
            models.Subject.class_id == class_id
        ).all()
        
        for subject in subjects:
            self.subjects_cache[subject.id] = {
                'can_be_twice_in_day': subject.can_be_twice_in_day,
                'type': subject.type.value,
                'class_id': subject.class_id
            }
    
    def _check_twice_in_day_constraint(self, assignment: Assignment) -> bool:
        """Check if subject can appear twice in the same day."""
        try:
            subject_data = self.subjects_cache.get(assignment.variable.subject_id)
            
            if not subject_data:
                return True  # If subject not found, allow assignment
            
            if subject_data['can_be_twice_in_day']:
                return True
            
            # Count existing assignments of this subject on the same day for same division
            same_day_count = sum(1 for a in self.assignments.values()
                               if (a.variable.subject_id == assignment.variable.subject_id and
                                   a.variable.division_id == assignment.variable.division_id and
                                   a.domain.day_index == assignment.domain.day_index))
            
            return same_day_count == 0
        except Exception as e:
            logger.error(f"Error in twice_in_day constraint check: {e}")
            return True  # Allow assignment on error to prevent blocking
    
    def _forward_check(self, assignment: Assignment) -> Dict[str, Set[Domain]]:
        """Remove inconsistent values from domains of unassigned variables."""
        removed_values = defaultdict(set)
        
        for variable in self.variables:
            if variable.id in self.assignments:
                continue
            
            to_remove = set()
            for domain_value in self.domains[variable.id]:
                test_assignment = Assignment(variable, domain_value)
                if assignment.conflicts_with(test_assignment):
                    to_remove.add(domain_value)
            
            removed_values[variable.id] = to_remove
            self.domains[variable.id] -= to_remove
        
        return removed_values
    
    def _restore_domains(self, removed_values: Dict[str, Set[Domain]]):
        """Restore domain values that were removed during forward checking."""
        for variable_id, values in removed_values.items():
            self.domains[variable_id] |= values
    
    def _count_constraining_relationships(self, variable: Variable) -> int:
        """Count how many other variables this variable constrains."""
        count = 0
        for other_variable in self.variables:
            if other_variable.id != variable.id:
                if (other_variable.teacher_id == variable.teacher_id or
                    other_variable.division_id == variable.division_id):
                    count += 1
        return count
    
    def _average_domain_size(self) -> float:
        """Calculate average domain size."""
        if not self.domains:
            return 0
        return sum(len(domain) for domain in self.domains.values()) / len(self.domains)
    
    def _create_partial_solution(self) -> CSPSolution:
        """Create a partial solution with current assignments."""
        conflicts = []
        
        # Detect conflicts in current assignments
        assignments_list = list(self.assignments.values())
        for i, assignment1 in enumerate(assignments_list):
            for assignment2 in assignments_list[i+1:]:
                conflict_types = assignment1.conflicts_with(assignment2)
                if conflict_types:
                    conflicts.append((assignment1, assignment2, conflict_types))
        
        return CSPSolution(
            assignments=assignments_list,
            is_complete=False,
            conflicts=conflicts,
            stats=self.stats.copy()
        )
