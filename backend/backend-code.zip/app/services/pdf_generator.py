"""
PDF Generation Service for Timetable Export

This module generates PDF reports for timetables using ReportLab.
"""

import io
from typing import Optional, List, Dict, Any
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, A4, landscape
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.pdfgen import canvas
import logging

from sqlalchemy.orm import Session
from app import models

logger = logging.getLogger(__name__)

class TimetablePDFGenerator:
    """Generate PDF reports for timetables."""
    
    def __init__(self):
        self.styles = getSampleStyleSheet()
        self.title_style = ParagraphStyle(
            'CustomTitle',
            parent=self.styles['Heading1'],
            fontSize=16,
            spaceAfter=30,
            alignment=1  # Center alignment
        )
        
    def generate_timetable_pdf(self, db: Session, timetable_id: int, 
                               division_id: Optional[int] = None) -> bytes:
        """Generate PDF for a specific timetable."""
        try:
            # Create PDF buffer
            buffer = io.BytesIO()
            
            # Get timetable data
            timetable = db.query(models.Timetable).filter(
                models.Timetable.id == timetable_id
            ).first()
            
            if not timetable:
                raise ValueError("Timetable not found")
            
            # Get timetable entries
            query = db.query(models.ScheduleEntry).filter(
                models.ScheduleEntry.timetable_id == timetable_id
            )
            
            if division_id:
                query = query.filter(models.ScheduleEntry.division_id == division_id)
            
            entries = query.order_by(
                models.ScheduleEntry.day_index,
                models.ScheduleEntry.period_index
            ).all()
            
            # Create PDF document
            doc = SimpleDocTemplate(
                buffer,
                pagesize=landscape(A4),
                rightMargin=0.5*inch,
                leftMargin=0.5*inch,
                topMargin=1*inch,
                bottomMargin=0.5*inch
            )
            
            # Build PDF content
            story = []
            
            # Title
            title_text = f"Timetable: {timetable.name}"
            if division_id:
                division = db.query(models.Division).filter(
                    models.Division.id == division_id
                ).first()
                if division:
                    title_text += f" - Division {division.name}"
            
            title = Paragraph(title_text, self.title_style)
            story.append(title)
            story.append(Spacer(1, 0.2*inch))
            
            # Create timetable grid
            timetable_table = self._create_timetable_table(db, entries)
            story.append(timetable_table)
            
            # Build PDF
            doc.build(story)
            
            # Return PDF bytes
            pdf_bytes = buffer.getvalue()
            buffer.close()
            
            return pdf_bytes
            
        except Exception as e:
            logger.error(f"PDF generation failed: {str(e)}")
            raise
    
    def _create_timetable_table(self, db: Session, entries: List[models.ScheduleEntry]) -> Table:
        """Create the main timetable table."""
        days = ["Time", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
        
        # Determine the maximum number of periods
        max_periods = 8  # Default
        if entries:
            max_periods = max(entry.period_index for entry in entries) + 1
        
        # Initialize table data
        table_data = []
        
        # Header row
        table_data.append(days)
        
        # Create grid data structure
        grid = {}
        for entry in entries:
            day_idx = entry.day_index
            period_idx = entry.period_index
            
            if day_idx not in grid:
                grid[day_idx] = {}
            
            # Get related data
            subject = db.query(models.Subject).filter(
                models.Subject.id == entry.subject_id
            ).first()
            teacher = db.query(models.Teacher).filter(
                models.Teacher.id == entry.teacher_id
            ).first()
            room = db.query(models.Room).filter(
                models.Room.id == entry.room_id
            ).first()
            
            grid[day_idx][period_idx] = {\
                'subject': subject.name if subject else 'Unknown',
                'teacher': teacher.name if teacher else 'Unknown',
                'room': room.room_number if room else 'Unknown'
            }
        
        # Fill table rows
        for period in range(max_periods):
            row = [f"Period {period + 1}"]
            
            for day_idx in range(6):  # Monday to Saturday
                cell_content = ""
                if day_idx in grid and period in grid[day_idx]:
                    entry_data = grid[day_idx][period]
                    cell_content = f"{entry_data['subject']}\\n{entry_data['teacher']}\\n{entry_data['room']}"
                
                row.append(cell_content)
            
            table_data.append(row)
        
        # Create table
        table = Table(table_data, colWidths=[1.2*inch] + [1.5*inch]*6)
        
        # Apply table styling
        table_style = TableStyle([
            # Header styling
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            
            # Content styling
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            
            # Row styling
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.lightgrey]),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ])
        
        table.setStyle(table_style)
        return table
    
    def generate_teacher_schedule_pdf(self, db: Session, teacher_id: int) -> bytes:
        """Generate PDF for a specific teacher's schedule."""
        try:
            buffer = io.BytesIO()
            
            # Get teacher information
            teacher = db.query(models.Teacher).filter(
                models.Teacher.id == teacher_id
            ).first()
            
            if not teacher:
                raise ValueError("Teacher not found")
            
            # Get teacher's schedule entries from published timetables
            entries = db.query(models.ScheduleEntry).join(
                models.Timetable
            ).filter(
                models.ScheduleEntry.teacher_id == teacher_id,
                models.Timetable.is_published == True
            ).order_by(
                models.ScheduleEntry.day_index,
                models.ScheduleEntry.period_index
            ).all()
            
            # Create PDF document
            doc = SimpleDocTemplate(
                buffer,
                pagesize=landscape(A4),
                rightMargin=0.5*inch,
                leftMargin=0.5*inch,
                topMargin=1*inch,
                bottomMargin=0.5*inch
            )
            
            story = []
            
            # Title
            title = Paragraph(f"Schedule for {teacher.name}", self.title_style)
            story.append(title)
            story.append(Spacer(1, 0.2*inch))
            
            # Create teacher schedule table
            schedule_table = self._create_teacher_schedule_table(db, entries)
            story.append(schedule_table)
            
            # Build PDF
            doc.build(story)
            
            pdf_bytes = buffer.getvalue()
            buffer.close()
            
            return pdf_bytes
            
        except Exception as e:
            logger.error(f"Teacher schedule PDF generation failed: {str(e)}")
            raise
    
    def _create_teacher_schedule_table(self, db: Session, 
                                       entries: List[models.ScheduleEntry]) -> Table:
        """Create schedule table for a teacher."""
        days = ["Time", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
        
        # Determine max periods
        max_periods = 8
        if entries:
            max_periods = max(entry.period_index for entry in entries) + 1
        
        table_data = [days]
        
        # Create grid
        grid = {}
        for entry in entries:
            day_idx = entry.day_index
            period_idx = entry.period_index
            
            if day_idx not in grid:
                grid[day_idx] = {}
            
            # Get related data
            subject = db.query(models.Subject).filter(
                models.Subject.id == entry.subject_id
            ).first()
            division = db.query(models.Division).filter(
                models.Division.id == entry.division_id
            ).first() if entry.division_id else None
            room = db.query(models.Room).filter(
                models.Room.id == entry.room_id
            ).first()
            
            grid[day_idx][period_idx] = {
                'subject': subject.name if subject else 'Unknown',
                'division': division.name if division else 'N/A',
                'room': room.room_number if room else 'Unknown'
            }
        
        # Fill rows
        for period in range(max_periods):
            row = [f"Period {period + 1}"]
            
            for day_idx in range(6):
                cell_content = ""
                if day_idx in grid and period in grid[day_idx]:
                    data = grid[day_idx][period]
                    cell_content = f"{data['subject']}\\n{data['division']}\\n{data['room']}"
                
                row.append(cell_content)
            
            table_data.append(row)
        
        table = Table(table_data, colWidths=[1.2*inch] + [1.5*inch]*6)
        
        # Styling
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.darkblue),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.lightblue]),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ]))\
        
        return table
