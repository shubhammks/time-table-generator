"""
Enhanced Batch Scheduling Algorithm

This module implements an improved algorithm for scheduling labs and tutorials
for multiple batches within a division, ensuring proper conflict management.

Key Features:
1. If batch A1 has lab at 9-11 AM, then A2 and A3 are FREE during that time
2. A2 and A3 can be assigned to OTHER labs/tutorials at DIFFERENT times
3. Each batch gets exactly 3 lab/tutorial sessions per week
4. No batch can have multiple labs on the same day
5. Proper conflict detection and resolution
"""

import logging
from typing import List, Dict, Set, Tuple, Optional
from dataclasses import dataclass
from sqlalchemy.orm import Session
import random

logger = logging.getLogger(__name__)

@dataclass
class BatchSchedule:
    """Represents a batch's schedule for a week."""
    batch_id: int
    batch_number: int
    lab_sessions: List[Tuple[int, int]]  # (day, period) tuples
    tutorial_sessions: List[Tuple[int, int]]
    total_sessions: int = 0
    
    def add_session(self, day: int, period: int, session_type: str):
        """Add a session to the batch schedule."""
        if session_type == 'lab':
            self.lab_sessions.append((day, period))
        elif session_type == 'tutorial':
            self.tutorial_sessions.append((day, period))
        self.total_sessions += 1
    
    def has_session_on_day(self, day: int) -> bool:
        """Check if batch has any session on a given day."""
        return any(d == day for d, p in self.lab_sessions + self.tutorial_sessions)
    
    def has_session_at_time(self, day: int, period: int) -> bool:
        """Check if batch has a session at a specific time."""
        return (day, period) in self.lab_sessions or (day, period) in self.tutorial_sessions

@dataclass
class TimeSlot:
    """Represents a time slot in the schedule."""
    day: int
    period: int
    is_available: bool = True
    assigned_batches: Set[int] = None
    
    def __post_init__(self):
        if self.assigned_batches is None:
            self.assigned_batches = set()

class EnhancedBatchScheduler:
    """Enhanced batch scheduling algorithm with proper conflict management."""
    
    def __init__(self, db: Session, division_id: int):
        self.db = db
        self.division_id = division_id
        self.days = 6  # Monday to Saturday
        self.periods_per_day = 8
        self.break_periods = {2, 6}  # Break and lunch periods
        
        # Initialize schedule tracking
        self.batch_schedules: Dict[int, BatchSchedule] = {}
        self.time_slots: Dict[Tuple[int, int], TimeSlot] = {}
        self.available_slots: List[Tuple[int, int]] = []
        
        # Initialize time slots
        self._initialize_time_slots()
    
    def _initialize_time_slots(self):
        """Initialize all time slots for the week."""
        for day in range(self.days):
            for period in range(self.periods_per_day):
                if period not in self.break_periods:
                    self.time_slots[(day, period)] = TimeSlot(day=day, period=period)
                    self.available_slots.append((day, period))
    
    def schedule_batches(self, batches: List, lab_subjects: List, tutorial_subjects: List) -> Dict[int, BatchSchedule]:
        """
        Main scheduling algorithm that supports concurrent batch scheduling.
        
        Algorithm (Updated for Concurrent Scheduling):
        1. For each batch, assign 3 lab/tutorial sessions per week
        2. Allow different batches to have DIFFERENT labs at the SAME time
        3. Example: TY A1 CAD lab + TY A2 ML lab at 9-11 AM (concurrent)
        4. Only prevent if the SAME batch has multiple sessions on the same day
        5. Support multi-period sessions (2-hour labs, 1-hour tutorials)
        """
        logger.info(f"Starting enhanced batch scheduling for {len(batches)} batches")
        
        # Initialize batch schedules
        for batch in batches:
            self.batch_schedules[batch.id] = BatchSchedule(
                batch_id=batch.id,
                batch_number=batch.number,
                lab_sessions=[],
                tutorial_sessions=[]
            )
        
        # Shuffle available slots for random distribution
        random.shuffle(self.available_slots)
        
        # Phase 1: Assign labs to batches with conflict management
        self._assign_labs_with_conflicts(batches, lab_subjects)
        
        # Phase 2: Assign tutorials to remaining free slots
        self._assign_tutorials_with_conflicts(batches, tutorial_subjects)
        
        # Phase 3: Verify and report conflicts
        self._verify_schedule_conflicts()
        
        return self.batch_schedules
    
    def _assign_labs_with_conflicts(self, batches: List, lab_subjects: List):
        """Assign labs to batches ensuring proper conflict management."""
        logger.info("=== PHASE 1: LAB ASSIGNMENT ===")
        
        for batch in batches:
            batch_schedule = self.batch_schedules[batch.id]
            labs_assigned = 0
            target_labs = 3  # 3 labs per week per batch
            subject_index = 0
            
            logger.info(f"Processing Batch {batch.number} for lab assignment...")
            
            for day, period in self.available_slots:
                if labs_assigned >= target_labs:
                    break
                
                # Check if this batch already has a session on this day
                if batch_schedule.has_session_on_day(day):
                    continue
                
                # Check if this batch already has a session at this time
                if batch_schedule.has_session_at_time(day, period):
                    continue
                
                # UPDATED LOGIC: Allow concurrent scheduling - different batches can have 
                # different labs at the same time (like TY A1 CAD + TY A2 ML at 9-11 AM)
                # Only check if THIS batch already has a session at this time
                this_batch_has_session_here = self._check_other_batches_at_time(day, period, batch.id)
                
                if this_batch_has_session_here:
                    logger.debug(f"  Batch {batch.number} already has session at Day {day}, Period {period}")
                    continue
                
                # Check for time conflicts with this batch's existing sessions
                if self._has_time_conflict(batch_schedule, day, period, 'lab'):
                    continue
                
                # Assign lab to this batch
                self._assign_lab_to_batch(batch, day, period, lab_subjects, subject_index)
                subject_index += 1
                labs_assigned += 1
                
                logger.info(f"  ✅ Assigned lab to Batch {batch.number} at Day {day}, Period {period}")
        
        # Log lab assignment summary
        self._log_assignment_summary("LABS")
    
    def _assign_tutorials_with_conflicts(self, batches: List, tutorial_subjects: List):
        """Assign tutorials to batches ensuring proper conflict management."""
        logger.info("=== PHASE 2: TUTORIAL ASSIGNMENT ===")
        
        for batch in batches:
            batch_schedule = self.batch_schedules[batch.id]
            tutorials_assigned = 0
            target_tutorials = 1  # 1 tutorial per week per batch (adjust as needed)
            subject_index = 0
            
            logger.info(f"Processing Batch {batch.number} for tutorial assignment...")
            
            for day, period in self.available_slots:
                if tutorials_assigned >= target_tutorials:
                    break
                
                # Check if this batch already has a session on this day
                if batch_schedule.has_session_on_day(day):
                    continue
                
                # Check if this batch already has a session at this time
                if batch_schedule.has_session_at_time(day, period):
                    continue
                
                # UPDATED LOGIC: Allow concurrent scheduling for tutorials too
                # Only check if THIS batch already has a session at this time
                this_batch_has_session_here = self._check_other_batches_at_time(day, period, batch.id)
                
                if this_batch_has_session_here:
                    logger.debug(f"  Batch {batch.number} already has session at Day {day}, Period {period}")
                    continue
                
                # Check for time conflicts with this batch's existing sessions
                if self._has_time_conflict(batch_schedule, day, period, 'tutorial'):
                    continue
                
                # Assign tutorial to this batch
                self._assign_tutorial_to_batch(batch, day, period, tutorial_subjects, subject_index)
                subject_index += 1
                tutorials_assigned += 1
                
                logger.info(f"  ✅ Assigned tutorial to Batch {batch.number} at Day {day}, Period {period}")
        
        # Log tutorial assignment summary
        self._log_assignment_summary("TUTORIALS")
    
    def _check_other_batches_at_time(self, day: int, period: int, current_batch_id: int) -> bool:
        """Check if any other batch has a session at the given time.
        
        UPDATED LOGIC: Allow concurrent scheduling - different batches can have 
        different labs at the same time (like TY A1 CAD + TY A2 ML at 9-11 AM).
        Only prevent if the SAME batch already has a session at this time.
        """
        # Only check if THIS specific batch already has a session at this time
        current_schedule = self.batch_schedules.get(current_batch_id)
        if current_schedule and current_schedule.has_session_at_time(day, period):
            return True
        return False
    
    def _has_time_conflict(self, batch_schedule: BatchSchedule, day: int, period: int, session_type: str) -> bool:
        """Check if assigning a session would create a time conflict."""
        # For labs, check if there's a conflict with existing sessions
        if session_type == 'lab':
            # Labs need 2 consecutive periods
            for existing_day, existing_period in batch_schedule.lab_sessions + batch_schedule.tutorial_sessions:
                if existing_day == day:
                    # Check for time overlap
                    if abs(existing_period - period) < 2:
                        return True
        return False
    
    def _assign_lab_to_batch(self, batch, day: int, period: int, lab_subjects: List, subject_index: int):
        """Assign a lab to a batch at the specified time."""
        batch_schedule = self.batch_schedules[batch.id]
        
        # Get lab subject
        lab_subject = lab_subjects[subject_index % len(lab_subjects)]
        
        # Assign the lab session (2 hours = 120 minutes for labs)
        batch_schedule.add_session(day, period, 'lab')
        
        # For labs, also assign the next period (2-hour duration = 120 minutes)
        next_period = period + 1
        if next_period < self.periods_per_day and next_period not in self.break_periods:
            batch_schedule.add_session(day, next_period, 'lab')
    
    def _assign_tutorial_to_batch(self, batch, day: int, period: int, tutorial_subjects: List, subject_index: int):
        """Assign a tutorial to a batch at the specified time."""
        batch_schedule = self.batch_schedules[batch.id]
        
        # Get tutorial subject
        tutorial_subject = tutorial_subjects[subject_index % len(tutorial_subjects)]
        
        # Assign the tutorial session (1 hour = 60 minutes for tutorials)
        batch_schedule.add_session(day, period, 'tutorial')
    
    def _verify_schedule_conflicts(self):
        """Verify the final schedule for conflicts and report results."""
        logger.info("=== PHASE 3: CONFLICT VERIFICATION ===")
        
        conflicts_found = 0
        
        for day in range(self.days):
            for period in range(self.periods_per_day):
                if period not in self.break_periods:
                    batches_at_this_time = []
                    
                    for batch_id, schedule in self.batch_schedules.items():
                        if schedule.has_session_at_time(day, period):
                            batches_at_this_time.append(schedule.batch_number)
                    
                    if len(batches_at_this_time) > 1:
                        logger.info(f"✅ Day {day}, Period {period}: CONCURRENT SESSIONS - Batches {batches_at_this_time} have different labs/tutorials")
                    elif len(batches_at_this_time) == 1:
                        logger.info(f"✅ Day {day}, Period {period}: Batch {batches_at_this_time[0]} has session")
                    else:
                        logger.info(f"🆓 Day {day}, Period {period}: All batches are FREE")
        
        if conflicts_found == 0:
            logger.info("🎉 SUCCESS: No conflicts found in the schedule!")
        else:
            logger.warning(f"⚠️  WARNING: {conflicts_found} conflicts found in the schedule")
    
    def _log_assignment_summary(self, session_type: str):
        """Log a summary of session assignments."""
        logger.info(f"=== {session_type} ASSIGNMENT SUMMARY ===")
        for batch_id, schedule in self.batch_schedules.items():
            if session_type == "LABS":
                sessions = schedule.lab_sessions
            else:
                sessions = schedule.tutorial_sessions
            
            logger.info(f"Batch {schedule.batch_number}: {len(sessions)} {session_type.lower()} assigned")
            for day, period in sessions:
                logger.info(f"  - Day {day}, Period {period}")
    
    def get_schedule_matrix(self) -> Dict[Tuple[int, int], List[int]]:
        """Get the final schedule matrix showing which batches are assigned to each time slot."""
        schedule_matrix = {}
        
        for day in range(self.days):
            for period in range(self.periods_per_day):
                if period not in self.break_periods:
                    batches_at_time = []
                    for batch_id, schedule in self.batch_schedules.items():
                        if schedule.has_session_at_time(day, period):
                            batches_at_time.append(batch_id)
                    schedule_matrix[(day, period)] = batches_at_time
        
        return schedule_matrix
