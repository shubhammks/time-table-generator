def is_teacher_available(schedule, teacher_id, day, period):
    """Check if teacher is free at a given slot"""
    return all(
        not (entry["teacher_id"] == teacher_id and entry["day"] == day and entry["period"] == period)
        for entry in schedule
    )

def is_room_available(schedule, room_id, day, period):
    """Check if room is free at a given slot"""
    return all(
        not (entry["room_id"] == room_id and entry["day"] == day and entry["period"] == period)
        for entry in schedule
    )

def is_consecutive(slot1, slot2):
    """Check if two slots are consecutive"""
    return slot2["period"] == slot1["period"] + 1 and slot2["day"] == slot1["day"]
