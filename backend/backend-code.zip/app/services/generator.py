"""
Timetable Generation Service

This module orchestrates the complete timetable generation process,
combining Phase 1 (CSP) and Phase 2 (Optimization) algorithms.
"""

from typing import Dict, List, Optional, Any
from dataclasses import dataclass
import logging
import time
from datetime import datetime

from sqlalchemy.orm import Session
from app import models, schemas
from app.services.csp_solver import CSPSolver, CSPSolution, Variable, Domain, Assignment
from app.services.optimizer import TimetableOptimizer, OptimizationResult
from app.services import utils

# Set up logging
logger = logging.getLogger(__name__)

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]

@dataclass
class SubjectAssignment:
    """Subject assignment for timetable generation."""
    subject_id: int
    teacher_id: int
    subject_type: str
    subject_name: str
    hours_per_week: int

@dataclass
class GenerationRequest:
    """Request parameters for timetable generation."""
    name: str
    class_id: Optional[int]
    department_id: Optional[int]
    mode: str  # 'school' or 'college'
    user_id: int
    subject_assignments: List[SubjectAssignment]
    options: Dict[str, Any]

@dataclass
class GenerationResult:
    """Result of timetable generation process."""
    success: bool
    timetable_id: Optional[int] = None
    message: str = ""
    diagnostics: List[schemas.ConflictDiagnostic] = None
    csp_stats: Dict[str, Any] = None
    optimization_stats: Dict[str, Any] = None
    total_time: float = 0.0
    
    def __post_init__(self):
        if self.diagnostics is None:
            self.diagnostics = []
        if self.csp_stats is None:
            self.csp_stats = {}
        if self.optimization_stats is None:
            self.optimization_stats = {}

class TimetableGenerator:
    """Main timetable generation orchestrator."""
    
    def __init__(self, db: Session):
        self.db = db
        self.validator = TimetableValidator(db)
    
    def generate_timetable(self, request: GenerationRequest) -> GenerationResult:
        """Main entry point for timetable generation."""
        start_time = time.time()
        
        try:
            logger.info(f"Starting timetable generation: {request.name} ({request.mode} mode)")
            
            # Pre-generation validation
            validation_result = self.validator.validate_pre_generation(
                request.class_id, request.department_id, request.mode
            )
            
            if not validation_result.is_valid:
                return GenerationResult(
                    success=False,
                    message="Pre-generation validation failed",
                    diagnostics=[schemas.ConflictDiagnostic(
                        type="validation_error",
                        message=error
                    ) for error in validation_result.errors]
                )
            
            # Get divisions for the class
            divisions = self.db.query(models.Division).filter(
                models.Division.class_id == request.class_id
            ).all()
            
            if not divisions:
                return GenerationResult(
                    success=False,
                    message="No divisions found for the selected class",
                    diagnostics=[schemas.ConflictDiagnostic(
                        type="validation_error",
                        message="Please create divisions for this class first"
                    )]
                )
            
            # Generate separate timetables for each division
            generated_timetables = []
            all_diagnostics = []
            
            for division in divisions:
                logger.info(f"Generating timetable for division: {division.name}")
                
                # Try CSP solving first
                csp_solver = CSPSolver(self.db, request.mode)
                csp_solution = csp_solver.solve(
                    class_id=request.class_id or 0,
                    department_id=request.department_id or 0,
                    division_id=division.id
                )
                
                # If CSP fails or is incomplete, use simple generation
                if not csp_solution.is_complete or len(csp_solution.assignments) < 5:
                    logger.info(f"CSP failed for {division.name}, using simple generation")
                    csp_solution = self._generate_simple_timetable(
                        request, division.id
                    )
                
                if not csp_solution or len(csp_solution.assignments) == 0:
                    logger.warning(f"Failed to generate timetable for {division.name}")
                    continue
                
                # Phase 2: Quick optimization (skip if CSP was simple)
                if csp_solution.is_complete:
                    optimizer = TimetableOptimizer(self.db, request.mode)
                    optimization_result = optimizer.optimize(
                        csp_solution, 
                        class_id=request.class_id or 0,
                        department_id=request.department_id or 0
                    )
                else:
                    # Create a simple optimization result
                    optimization_result = OptimizationResult(
                        initial_score=0,
                        final_score=0,
                        moves_applied=0,
                        iterations=0,
                        convergence_history=[]
                    )
                
                # Save timetable for this division
                division_request = GenerationRequest(
                    name=f"{request.name} - {division.name}",
                    class_id=request.class_id,
                    department_id=request.department_id,
                    mode=request.mode,
                    user_id=request.user_id,
                    subject_assignments=request.subject_assignments,
                    options=request.options
                )
                
                timetable_id = self._save_timetable(
                    division_request, csp_solution, optimization_result, division.id
                )
                
                generated_timetables.append({
                    'timetable_id': timetable_id,
                    'division_name': division.name,
                    'assignments_count': len(csp_solution.assignments)
                })
                
                logger.info(f"Generated timetable for {division.name}: {timetable_id}")
            
            total_time = time.time() - start_time
            
            if not generated_timetables:
                return GenerationResult(
                    success=False,
                    message="Failed to generate timetables for any division",
                    diagnostics=all_diagnostics,
                    total_time=total_time
                )
            
            logger.info(f"Timetable generation completed successfully in {total_time:.2f}s")
            logger.info(f"Generated {len(generated_timetables)} timetables")
            
            return GenerationResult(
                success=True,
                timetable_id=generated_timetables[0]['timetable_id'],  # Return first timetable ID for compatibility
                message=f"Generated {len(generated_timetables)} timetables successfully",
                diagnostics=all_diagnostics,
                total_time=total_time,
                csp_stats={'divisions_processed': len(generated_timetables)},
                optimization_stats={'total_timetables': len(generated_timetables)}
            )
            
        except Exception as e:
            logger.error(f"Timetable generation failed: {str(e)}", exc_info=True)
            return GenerationResult(
                success=False,
                message=f"Generation failed: {str(e)}",
                total_time=time.time() - start_time
            )
    
    def _convert_csp_conflicts_to_diagnostics(self, solution: CSPSolution) -> List[schemas.ConflictDiagnostic]:
        """Convert CSP conflicts to diagnostic format."""
        diagnostics = []
        
        for assignment1, assignment2, conflict_types in solution.conflicts:
            for conflict_type in conflict_types:
                diagnostic = schemas.ConflictDiagnostic(
                    type=conflict_type.value,
                    message=self._format_conflict_message(assignment1, assignment2, conflict_type),
                    subject_id=assignment1.variable.subject_id,
                    teacher_id=assignment1.variable.teacher_id,
                    division_id=assignment1.variable.division_id,
                    day_index=assignment1.domain.day_index,
                    period_index=assignment1.domain.period_index,
                    suggestions=self._generate_conflict_suggestions(assignment1, assignment2, conflict_type)
                )
                diagnostics.append(diagnostic)
        
        return diagnostics
    
    def _format_conflict_message(self, assignment1, assignment2, conflict_type) -> str:
        """Format a human-readable conflict message."""
        day_names = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
        day1 = day_names[assignment1.domain.day_index]
        period1 = assignment1.domain.period_index + 1
        
        if conflict_type.value == "teacher_conflict":
            return (f"Teacher {assignment1.variable.teacher_name} is double-booked on "
                   f"{day1} period {period1}")
        elif conflict_type.value == "room_conflict":
            return (f"Room conflict on {day1} period {period1}")
        elif conflict_type.value == "division_conflict":
            return (f"Division has multiple subjects scheduled on {day1} period {period1}")
        else:
            return f"Conflict of type {conflict_type.value} on {day1} period {period1}"
    
    def _generate_conflict_suggestions(self, assignment1, assignment2, conflict_type) -> List[str]:
        """Generate suggestions for resolving conflicts."""
        suggestions = []
        
        if conflict_type.value == "teacher_conflict":
            suggestions.extend([
                "Assign a different teacher to one of the subjects",
                "Move one of the assignments to a different time slot",
                "Consider splitting the teacher's load across multiple days"
            ])
        elif conflict_type.value == "room_conflict":
            suggestions.extend([
                "Assign a different room to one of the subjects",
                "Move one assignment to a different time slot",
                "Check if room capacity can accommodate both activities"
            ])
        elif conflict_type.value == "division_conflict":
            suggestions.extend([
                "Move one subject to a different time slot",
                "Check if subjects can be combined or rescheduled"
            ])
        
        return suggestions
    
    def _generate_simple_timetable(self, request: GenerationRequest, division_id: int) -> CSPSolution:
        """Generate a simple timetable without complex constraints."""
        logger.info(f"Generating simple timetable for division {division_id}")
        
        # Get subjects for this division
        subjects = self.db.query(models.Subject).join(
            models.SubjectTeacher
        ).filter(
            models.SubjectTeacher.division_id == division_id
        ).all()
        
        if not subjects:
            logger.warning(f"No subjects found for division {division_id}")
            return CSPSolution(assignments=[], is_complete=False)
        
        logger.info(f"Found {len(subjects)} subjects for division {division_id}")
        
        # Get rooms
        rooms = self.db.query(models.Room).filter(
            models.Room.department_id == request.department_id
        ).all()
        
        if not rooms:
            logger.warning("No rooms found")
            return CSPSolution(assignments=[], is_complete=False)
        
        # Get batches for this division
        batches = self.db.query(models.Batch).filter(
            models.Batch.division_id == division_id
        ).all()
        
        assignments = []
        days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
        periods_per_day = 8
        
        # Separate lab/tutorial subjects from regular subjects
        lab_subjects = [s for s in subjects if s.type.value in ['lab', 'tutorial']]
        regular_subjects = [s for s in subjects if s.type.value == 'lecture']
        
        # Use enhanced batch scheduler for proper conflict management
        if lab_subjects and batches:
            logger.info(f"Using enhanced batch scheduler for {len(batches)} batches with {len(lab_subjects)} lab subjects")
            
            from .enhanced_batch_scheduler import EnhancedBatchScheduler
            
            # Separate lab and tutorial subjects
            lab_subjects_list = [s for s in lab_subjects if s.type.value == 'lab']
            tutorial_subjects_list = [s for s in lab_subjects if s.type.value == 'tutorial']
            
            # Use enhanced batch scheduler
            scheduler = EnhancedBatchScheduler(self.db, division_id)
            batch_schedules = scheduler.schedule_batches(batches, lab_subjects_list, tutorial_subjects_list)
            
            # Convert enhanced schedule to assignments
            for batch_id, schedule in batch_schedules.items():
                # Process lab sessions
                for day_idx, period_idx in schedule.lab_sessions:
                    # Get lab subject
                    lab_subject = lab_subjects_list[0] if lab_subjects_list else None
                    if not lab_subject:
                        continue
                    
                    # Get teacher
                    teacher = self.db.query(models.Teacher).join(
                        models.SubjectTeacher
                    ).filter(
                        models.SubjectTeacher.subject_id == lab_subject.id,
                        models.SubjectTeacher.division_id == division_id
                    ).first()
                    
                    if teacher:
                        # Get appropriate room for lab
                        lab_rooms = [r for r in rooms if r.type.value == 'lab']
                        room = lab_rooms[0] if lab_rooms else rooms[0]
                        
                        variable = Variable(
                            id=f"enhanced_lab_{batch_id}_{day_idx}_{period_idx}",
                            subject_id=lab_subject.id,
                            teacher_id=teacher.id,
                            division_id=division_id,
                            batch_id=batch_id,
                            subject_type='lab',
                            subject_name=f"{lab_subject.name} (Batch {schedule.batch_number})",
                            teacher_name=teacher.name
                        )
                        
                        domain = Domain(
                            day_index=day_idx,
                            period_index=period_idx,
                            room_id=room.id,
                            room_type=room.type.value if hasattr(room.type, 'value') else str(room.type)
                        )
                        
                        assignment = Assignment(variable, domain)
                        assignments.append(assignment)
                        logger.info(f"✅ Enhanced: Assigned {lab_subject.name} to Batch {schedule.batch_number} on {days[day_idx]}, period {period_idx}")
                
                # Process tutorial sessions
                for day_idx, period_idx in schedule.tutorial_sessions:
                    # Get tutorial subject
                    tutorial_subject = tutorial_subjects_list[0] if tutorial_subjects_list else None
                    if not tutorial_subject:
                        continue
                    
                    # Get teacher
                    teacher = self.db.query(models.Teacher).join(
                        models.SubjectTeacher
                    ).filter(
                        models.SubjectTeacher.subject_id == tutorial_subject.id,
                        models.SubjectTeacher.division_id == division_id
                    ).first()
                    
                    if teacher:
                        # Get appropriate room for tutorial
                        tutorial_rooms = [r for r in rooms if r.type.value == 'tutorial']
                        room = tutorial_rooms[0] if tutorial_rooms else rooms[0]
                        
                        variable = Variable(
                            id=f"enhanced_tutorial_{batch_id}_{day_idx}_{period_idx}",
                            subject_id=tutorial_subject.id,
                            teacher_id=teacher.id,
                            division_id=division_id,
                            batch_id=batch_id,
                            subject_type='tutorial',
                            subject_name=f"{tutorial_subject.name} (Batch {schedule.batch_number})",
                            teacher_name=teacher.name
                        )
                        
                        domain = Domain(
                            day_index=day_idx,
                            period_index=period_idx,
                            room_id=room.id,
                            room_type=room.type.value if hasattr(room.type, 'value') else str(room.type)
                        )
                        
                        assignment = Assignment(variable, domain)
                        assignments.append(assignment)
                        logger.info(f"✅ Enhanced: Assigned {tutorial_subject.name} to Batch {schedule.batch_number} on {days[day_idx]}, period {period_idx}")
            
            logger.info(f"Enhanced batch scheduling completed: {len(assignments)} assignments created")
        
        # Then assign regular subjects to remaining slots
        for day_idx, day in enumerate(days):
            for period_idx in range(periods_per_day):
                # Skip break periods
                if period_idx in [2, 6]:
                    continue
                
                # Skip if this slot is already assigned to a batch for lab
                # Note: schedule_matrix is not used in enhanced mode, so we skip this check
                # The enhanced scheduler already handles all lab/tutorial assignments
                
                # Assign regular subjects
                if regular_subjects:
                    subject_idx = (day_idx * periods_per_day + period_idx) % len(regular_subjects)
                    subject = regular_subjects[subject_idx]
                    
                    # Get teacher for this subject
                    teacher = self.db.query(models.Teacher).join(
                        models.SubjectTeacher
                    ).filter(
                        models.SubjectTeacher.subject_id == subject.id,
                        models.SubjectTeacher.division_id == division_id
                    ).first()
                    
                    if not teacher:
                        logger.warning(f"No teacher found for subject {subject.name} in division {division_id}")
                        continue
                    
                    # Get appropriate room
                    room = rooms[subject_idx % len(rooms)]
                    
                    # Get batch (for regular subjects, assign to all batches)
                    batch = batches[0] if batches else None
                    
                    variable = Variable(
                        id=f"simple_{day_idx}_{period_idx}",
                        subject_id=subject.id,
                        teacher_id=teacher.id,
                        division_id=division_id,
                        batch_id=batch.id if batch else None,
                        subject_type=subject.type.value,
                        subject_name=subject.name,
                        teacher_name=teacher.name
                    )
                    
                    domain = Domain(
                        day_index=day_idx,
                        period_index=period_idx,
                        room_id=room.id,
                        room_type=room.type.value if hasattr(room.type, 'value') else str(room.type)
                    )
                    
                    assignment = Assignment(variable, domain)
                    assignments.append(assignment)
        
        logger.info(f"Generated {len(assignments)} simple assignments for division {division_id}")
        return CSPSolution(assignments=assignments, is_complete=True)
    
    def _save_timetable(self, request: GenerationRequest, 
                       csp_solution: CSPSolution, 
                       optimization_result: OptimizationResult,
                       division_id: int = None) -> int:
        """Save the generated timetable to database."""
        # Create timetable record
        timetable = models.Timetable(
            name=request.name,
            class_id=request.class_id,
            is_published=False,
            created_by_user_id=request.user_id,
            created_at=datetime.now()
        )
        
        self.db.add(timetable)
        self.db.flush()  # Get the ID
        
        # Create schedule entries
        for assignment in csp_solution.assignments:
            schedule_entry = models.ScheduleEntry(
                timetable_id=timetable.id,
                day_index=assignment.domain.day_index,
                period_index=assignment.domain.period_index,
                subject_id=assignment.variable.subject_id,
                teacher_id=assignment.variable.teacher_id,
                room_id=assignment.domain.room_id,
                division_id=assignment.variable.division_id,
                batch_id=assignment.variable.batch_id
            )
            self.db.add(schedule_entry)
        
        self.db.commit()
        return timetable.id

class TimetableValidator:
    """Validator for timetable generation prerequisites."""
    
    def __init__(self, db: Session):
        self.db = db
    
    def validate_pre_generation(self, class_id: Optional[int], 
                               department_id: Optional[int], 
                               mode: str) -> schemas.ValidationResult:
        """Validate prerequisites before generation."""
        errors = []
        warnings = []
        suggestions = []
        
        try:
            # Infer department from class if not provided
            inferred_department_id = department_id
            if class_id and not inferred_department_id:
                cls = self.db.query(models.Class).filter(models.Class.id == class_id).first()
                if cls and getattr(cls, 'department_id', None):
                    inferred_department_id = cls.department_id

            if mode == 'school' and not class_id:
                errors.append("Class ID required for school mode")
            
            if mode == 'college' and not inferred_department_id:
                errors.append("Department ID required for college mode")
            
            # Check if teachers are assigned in DB (relaxed: allow frontend-provided assignments)
            # We no longer block generation on missing DB SubjectTeacher rows because
            # the UI provides assignments in the request payload.
            
            # Check room availability (College only; School uses fixed classrooms per division)
            if mode == 'college' and inferred_department_id:
                rooms = self.db.query(models.Room).filter(
                    models.Room.department_id == inferred_department_id
                ).all()
                
                if not rooms:
                    errors.append("No rooms configured for this department")
                    suggestions.append("Please add rooms before generating timetable")
                
                # Check lab room availability for lab subjects
                lab_rooms = [r for r in rooms if r.type == models.RoomType.lab]
                if class_id:
                    lab_subjects = self.db.query(models.Subject).filter(
                        models.Subject.class_id == class_id,
                        models.Subject.type == models.SubjectType.lab
                    ).all()
                    
                    if lab_subjects and not lab_rooms:
                        errors.append("Lab subjects exist but no lab rooms available")
                        suggestions.append("Add lab rooms or change subject types")
            
            # Check timetable slots configuration (best-effort; warn if absent)
            if inferred_department_id:
                slots = self.db.query(models.TimetableSlots).filter(
                    models.TimetableSlots.department_id == inferred_department_id,
                    models.TimetableSlots.is_active == True
                ).all()
                
                if not slots:
                    warnings.append("No timetable slots configured, using default schedule")
                    suggestions.append("Configure timetable slots for better control")
        
        except Exception as e:
            errors.append(f"Validation error: {str(e)}")
        
        return schemas.ValidationResult(
            is_valid=len(errors) == 0,
            errors=errors,
            warnings=warnings,
            suggestions=suggestions
        )

# Legacy function for backward compatibility
def generate_valid_timetable(db):
    """
    Legacy function - simplified generation for backward compatibility.
    """
    schedule = []
    
    try:
        # This is a simplified placeholder
        subjects = db.query(models.Subject).all()
        teachers = db.query(models.Teacher).all()
        rooms = db.query(models.Room).all()
        
        if not subjects or not teachers or not rooms:
            return schedule
        
        # Simple random assignment for backward compatibility
        import random
        
        for subject in subjects:
            hours = subject.hours_per_week
            teacher_assignments = db.query(models.SubjectTeacher).filter(
                models.SubjectTeacher.subject_id == subject.id
            ).first()
            
            if not teacher_assignments:
                continue
            
            teacher_id = teacher_assignments.teacher_id
            room = random.choice(rooms)
            
            for _ in range(hours):
                day = random.choice(DAYS)
                period = random.randint(1, 6)
                
                if utils.is_teacher_available(schedule, teacher_id, day, period) and \
                   utils.is_room_available(schedule, room.id, day, period):
                    schedule.append({
                        "day": day,
                        "period": period,
                        "subject_id": subject.id,
                        "teacher_id": teacher_id,
                        "room_id": room.id
                    })
    
    except Exception as e:
        logger.error(f"Legacy generation failed: {str(e)}")
    
    return schedule
