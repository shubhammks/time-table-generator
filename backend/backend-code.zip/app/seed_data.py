"""
Sample data population script for testing the timetable management system.

This script creates sample data for both school and college scenarios.
"""

from sqlalchemy.orm import Session
from app import models
from app.database import SessionLocal, engine
from app.auth import hash_password
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_sample_users(db: Session):
    """Create sample users."""
    users = [
        {
            "email": "admin@timetable.com",
            "password_hash": hash_password("admin123"),
            "role": models.UserRole.admin
        },
        {
            "email": "coordinator@school.edu",
            "password_hash": hash_password("coord123"),
            "role": models.UserRole.coordinator
        },
        {
            "email": "coordinator@college.edu", 
            "password_hash": hash_password("coord123"),
            "role": models.UserRole.coordinator
        }
    ]
    
    for user_data in users:
        existing_user = db.query(models.User).filter(
            models.User.email == user_data["email"]
        ).first()
        
        if not existing_user:
            user = models.User(**user_data)
            db.add(user)
            logger.info(f"Created user: {user_data['email']}")
    
    db.commit()

def create_school_data(db: Session):
    """Create sample school data."""
    # Create school department
    school_dept = models.Department(
        name="ABC Public School",
        type=models.DepartmentType.school
    )
    db.add(school_dept)
    db.flush()
    
    # Create sample teachers
    teachers_data = [
        {"name": "Dr. Priya Sharma", "email": "priya@school.edu", "phone": "9876543210"},
        {"name": "Prof. Rajesh Kumar", "email": "rajesh@school.edu", "phone": "9876543211"},
        {"name": "Ms. Anita Verma", "email": "anita@school.edu", "phone": "9876543212"},
        {"name": "Mr. Suresh Patel", "email": "suresh@school.edu", "phone": "9876543213"},
        {"name": "Dr. Kavita Singh", "email": "kavita@school.edu", "phone": "9876543214"},
        {"name": "Prof. Amit Gupta", "email": "amit@school.edu", "phone": "9876543215"},
        {"name": "Ms. Neha Joshi", "email": "neha@school.edu", "phone": "9876543216"},
        {"name": "Mr. Vikram Rao", "email": "vikram@school.edu", "phone": "9876543217"},
    ]
    
    teachers = []
    for teacher_data in teachers_data:
        teacher = models.Teacher(department_id=school_dept.id, **teacher_data)
        db.add(teacher)
        teachers.append(teacher)
    
    db.flush()
    
    # Create classes for standards 9 and 10
    classes_data = [
        {"name": "Class 9", "number_of_divisions": 3},
        {"name": "Class 10", "number_of_divisions": 3},
    ]
    
    classes = []
    for class_data in classes_data:
        class_obj = models.Class(department_id=school_dept.id, **class_data)
        db.add(class_obj)
        classes.append(class_obj)
    
    db.flush()
    
    # Create divisions (auto-created by the class creation, but let's ensure they exist)
    divisions = []
    for class_obj in classes:
        for i in range(class_obj.number_of_divisions):
            division_name = f"{class_obj.name}{chr(65 + i)}"  # A, B, C
            existing_division = db.query(models.Division).filter(
                models.Division.class_id == class_obj.id,
                models.Division.name == division_name
            ).first()
            
            if not existing_division:
                division = models.Division(
                    name=division_name,
                    class_id=class_obj.id
                )
                db.add(division)
                divisions.append(division)
            else:
                divisions.append(existing_division)
    
    db.flush()
    
    # Create subjects
    subjects_data = [
        # Class 9 subjects
        {"name": "Mathematics", "type": models.SubjectType.lecture, "hours_per_week": 6, "class_id": classes[0].id},
        {"name": "Science", "type": models.SubjectType.lecture, "hours_per_week": 6, "class_id": classes[0].id},
        {"name": "English", "type": models.SubjectType.lecture, "hours_per_week": 5, "class_id": classes[0].id},
        {"name": "Hindi", "type": models.SubjectType.lecture, "hours_per_week": 4, "class_id": classes[0].id},
        {"name": "Social Studies", "type": models.SubjectType.lecture, "hours_per_week": 4, "class_id": classes[0].id},
        {"name": "Computer Lab", "type": models.SubjectType.lab, "hours_per_week": 2, "class_id": classes[0].id},
        
        # Class 10 subjects  
        {"name": "Mathematics", "type": models.SubjectType.lecture, "hours_per_week": 6, "class_id": classes[1].id},
        {"name": "Science", "type": models.SubjectType.lecture, "hours_per_week": 6, "class_id": classes[1].id},
        {"name": "English", "type": models.SubjectType.lecture, "hours_per_week": 5, "class_id": classes[1].id},
        {"name": "Hindi", "type": models.SubjectType.lecture, "hours_per_week": 4, "class_id": classes[1].id},
        {"name": "Social Studies", "type": models.SubjectType.lecture, "hours_per_week": 4, "class_id": classes[1].id},
        {"name": "Physics Lab", "type": models.SubjectType.lab, "hours_per_week": 2, "class_id": classes[1].id},
        {"name": "Chemistry Lab", "type": models.SubjectType.lab, "hours_per_week": 2, "class_id": classes[1].id},
    ]
    
    subjects = []
    for subject_data in subjects_data:
        subject = models.Subject(**subject_data)
        db.add(subject)
        subjects.append(subject)
    
    db.flush()
    
    # Create rooms
    rooms_data = [
        # Classrooms
        {"room_number": "101", "type": models.RoomType.classroom, "capacity": 40, "floor": 1},
        {"room_number": "102", "type": models.RoomType.classroom, "capacity": 40, "floor": 1},
        {"room_number": "103", "type": models.RoomType.classroom, "capacity": 40, "floor": 1},
        {"room_number": "201", "type": models.RoomType.classroom, "capacity": 40, "floor": 2},
        {"room_number": "202", "type": models.RoomType.classroom, "capacity": 40, "floor": 2},
        {"room_number": "203", "type": models.RoomType.classroom, "capacity": 40, "floor": 2},
        
        # Labs
        {"room_number": "Lab-1", "type": models.RoomType.lab, "capacity": 30, "floor": 1},
        {"room_number": "Lab-2", "type": models.RoomType.lab, "capacity": 30, "floor": 1},
        {"room_number": "Computer Lab", "type": models.RoomType.lab, "capacity": 35, "floor": 2},
    ]
    
    for room_data in rooms_data:
        room = models.Room(department_id=school_dept.id, **room_data)
        db.add(room)
    
    db.flush()
    
    # Create subject-teacher assignments
    import random
    
    # Assign teachers to subjects for each division
    for subject in subjects:
        class_divisions = db.query(models.Division).filter(
            models.Division.class_id == subject.class_id
        ).all()
        
        for division in class_divisions:
            # Assign a random teacher (in real scenario, this would be carefully planned)
            teacher = random.choice(teachers)
            
            assignment = models.SubjectTeacher(
                subject_id=subject.id,
                teacher_id=teacher.id,
                division_id=division.id
            )
            db.add(assignment)
    
    db.commit()
    logger.info("School sample data created successfully")

def create_college_data(db: Session):
    """Create sample college data."""
    # Create college department
    college_dept = models.Department(
        name="Engineering College",
        type=models.DepartmentType.college
    )
    db.add(college_dept)
    db.flush()
    
    # Create sample teachers
    teachers_data = [
        {"name": "Dr. Ashok Kumar", "email": "ashok@college.edu", "phone": "9876540001"},
        {"name": "Prof. Sunita Rani", "email": "sunita@college.edu", "phone": "9876540002"},
        {"name": "Dr. Rahul Mehta", "email": "rahul@college.edu", "phone": "9876540003"},
        {"name": "Prof. Deepika Sharma", "email": "deepika@college.edu", "phone": "9876540004"},
        {"name": "Dr. Manoj Agarwal", "email": "manoj@college.edu", "phone": "9876540005"},
        {"name": "Prof. Ritu Singh", "email": "ritu@college.edu", "phone": "9876540006"},
    ]
    
    teachers = []
    for teacher_data in teachers_data:
        teacher = models.Teacher(department_id=college_dept.id, **teacher_data)
        db.add(teacher)
        teachers.append(teacher)
    
    db.flush()
    
    # Create college years
    years_data = [
        {"name": "First Year", "number_of_divisions": 2},
        {"name": "Second Year", "number_of_divisions": 2},
    ]
    
    years = []
    for year_data in years_data:
        year = models.Class(department_id=college_dept.id, **year_data)
        db.add(year)
        years.append(year)
    
    db.flush()
    
    # Create divisions
    divisions = []
    for year in years:
        for i in range(year.number_of_divisions):
            division_name = f"{year.name} Div-{i+1}"
            division = models.Division(
                name=division_name,
                class_id=year.id
            )
            db.add(division)
            divisions.append(division)
    
    db.flush()
    
    # Create subjects
    subjects_data = [
        # First Year
        {"name": "Engineering Mathematics I", "type": models.SubjectType.lecture, "hours_per_week": 4, "class_id": years[0].id},
        {"name": "Physics", "type": models.SubjectType.lecture, "hours_per_week": 3, "class_id": years[0].id},
        {"name": "Chemistry", "type": models.SubjectType.lecture, "hours_per_week": 3, "class_id": years[0].id},
        {"name": "Programming Lab", "type": models.SubjectType.lab, "hours_per_week": 4, "class_id": years[0].id},
        {"name": "Physics Lab", "type": models.SubjectType.lab, "hours_per_week": 2, "class_id": years[0].id},
        
        # Second Year
        {"name": "Data Structures", "type": models.SubjectType.lecture, "hours_per_week": 4, "class_id": years[1].id},
        {"name": "Database Systems", "type": models.SubjectType.lecture, "hours_per_week": 4, "class_id": years[1].id},
        {"name": "Computer Networks", "type": models.SubjectType.lecture, "hours_per_week": 3, "class_id": years[1].id},
        {"name": "DBMS Lab", "type": models.SubjectType.lab, "hours_per_week": 4, "class_id": years[1].id},
        {"name": "Networks Lab", "type": models.SubjectType.lab, "hours_per_week": 2, "class_id": years[1].id},
    ]
    
    subjects = []
    for subject_data in subjects_data:
        subject = models.Subject(**subject_data)
        db.add(subject)
        subjects.append(subject)
    
    db.flush()
    
    # Create college rooms
    rooms_data = [
        # Lecture halls
        {"room_number": "LH-1", "type": models.RoomType.classroom, "capacity": 60, "floor": 1},
        {"room_number": "LH-2", "type": models.RoomType.classroom, "capacity": 60, "floor": 1},
        {"room_number": "CR-301", "type": models.RoomType.classroom, "capacity": 50, "floor": 3},
        {"room_number": "CR-302", "type": models.RoomType.classroom, "capacity": 50, "floor": 3},
        
        # Labs
        {"room_number": "CSL-1", "type": models.RoomType.lab, "capacity": 40, "floor": 2},
        {"room_number": "CSL-2", "type": models.RoomType.lab, "capacity": 40, "floor": 2},
        {"room_number": "Physics Lab", "type": models.RoomType.lab, "capacity": 30, "floor": 1},
        {"room_number": "Network Lab", "type": models.RoomType.lab, "capacity": 35, "floor": 3},
    ]
    
    for room_data in rooms_data:
        room = models.Room(department_id=college_dept.id, **room_data)
        db.add(room)
    
    db.flush()
    
    # Create subject-teacher assignments
    import random
    
    for subject in subjects:
        year_divisions = db.query(models.Division).filter(
            models.Division.class_id == subject.class_id
        ).all()
        
        for division in year_divisions:
            teacher = random.choice(teachers)
            
            assignment = models.SubjectTeacher(
                subject_id=subject.id,
                teacher_id=teacher.id,
                division_id=division.id
            )
            db.add(assignment)
    
    db.commit()
    logger.info("College sample data created successfully")

def create_sample_timetable_slots(db: Session):
    """Create sample timetable slot configurations."""
    # Get departments
    departments = db.query(models.Department).all()
    
    for dept in departments:
        # Create standard time slots (8 periods, 6 days)
        periods_per_day = 8
        days = 6  # Monday to Saturday
        
        for day_idx in range(days):
            for period_idx in range(periods_per_day):
                # Calculate time slots
                start_hour = 9 + (period_idx // 2)  # 9:00, 9:50, 10:40, etc.
                start_minute = 0 if period_idx % 2 == 0 else 50
                end_hour = start_hour if period_idx % 2 == 0 else start_hour + 1
                end_minute = 50 if period_idx % 2 == 0 else 40
                
                # Handle lunch break
                is_break = False
                break_type = None
                if period_idx == 4:  # 5th period is lunch
                    is_break = True
                    break_type = "lunch_break"
                    start_hour = 13
                    start_minute = 0
                    end_hour = 13
                    end_minute = 50
                elif period_idx == 2:  # 3rd period is short break  
                    # Add short break after 2nd period
                    pass  # Keep regular timing
                
                start_time = f"{start_hour:02d}:{start_minute:02d}"
                end_time = f"{end_hour:02d}:{end_minute:02d}"
                
                slot = models.TimetableSlots(
                    department_id=dept.id,
                    day_index=day_idx,
                    period_index=period_idx,
                    start_time=start_time,
                    end_time=end_time,
                    is_break=is_break,
                    break_type=break_type,
                    is_active=True
                )
                db.add(slot)
    
    db.commit()
    logger.info("Sample timetable slots created successfully")

def populate_sample_data():
    """Main function to populate all sample data."""
    # Create tables
    models.Base.metadata.create_all(bind=engine)
    
    # Create database session
    db = SessionLocal()
    
    try:
        logger.info("Starting sample data population...")
        
        # Create sample data
        create_sample_users(db)
        create_school_data(db)
        create_college_data(db)
        create_sample_timetable_slots(db)
        
        logger.info("Sample data population completed successfully!")
        
    except Exception as e:
        logger.error(f"Error populating sample data: {str(e)}")
        db.rollback()
        raise
    finally:
        db.close()

if __name__ == "__main__":
    populate_sample_data()
