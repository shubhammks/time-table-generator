from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import logging

from app import models
from app.database import engine
from app.config import settings
from app.routes import (
    auth,
    crud,
    timetable
)

# Set up logging
logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL),
    format=settings.LOG_FORMAT
)
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan events."""
    # Startup
    logger.info("Starting Timetable Management System")
    
    # Create database tables
    try:
        models.Base.metadata.create_all(bind=engine)
        logger.info("Database tables created successfully")
    except Exception as e:
        logger.error(f"Failed to create database tables: {e}")
    
    yield
    
    # Shutdown
    logger.info("Shutting down Timetable Management System")

app = FastAPI(
    title="Timetable Management System",
    description="A comprehensive timetable generation and management system for schools and colleges",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)

# Include API routes
api_prefix = settings.API_V1_STR

# Authentication routes
app.include_router(
    auth.router,
    prefix=f"{api_prefix}/auth",
    tags=["Authentication"]
)

# CRUD routes for all entities
app.include_router(
    crud.router,
    prefix=f"{api_prefix}",
    tags=["CRUD Operations"]
)

# Timetable generation and management routes
app.include_router(
    timetable.router,
    prefix=f"{api_prefix}/timetable",
    tags=["Timetable Generation"]
)

@app.get("/")
def root():
    """Root endpoint with system information."""
    return {
        "message": "Welcome to Timetable Management System",
        "version": "1.0.0",
        "environment": settings.ENVIRONMENT,
        "docs_url": "/docs",
        "api_prefix": api_prefix
    }

@app.get("/health")
def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "environment": settings.ENVIRONMENT,
        "debug": settings.DEBUG
    }
