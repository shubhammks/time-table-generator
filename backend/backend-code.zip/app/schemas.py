from pydantic import BaseModel, EmailStr
from typing import List, Optional, Dict, Any
from datetime import datetime
from enum import Enum

# Enums for Pydantic models
class UserRoleEnum(str, Enum):
    teacher = "teacher"
    admin = "admin"
    coordinator = "coordinator"

class DepartmentTypeEnum(str, Enum):
    school = "school"
    college = "college"

class SubjectTypeEnum(str, Enum):
    lecture = "lecture"
    lab = "lab"
    tutorial = "tutorial"

class RoomTypeEnum(str, Enum):
    classroom = "classroom"
    lab = "lab"
    tutorial = "tutorial"

# Base Schemas
class UserBase(BaseModel):
    email: EmailStr
    full_name: Optional[str] = None
    role: UserRoleEnum

class UserCreate(UserBase):
    password: str
    confirmPassword: Optional[str] = None

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserUpdate(BaseModel):
    email: Optional[EmailStr] = None
    full_name: Optional[str] = None
    role: Optional[UserRoleEnum] = None

class User(UserBase):
    id: int
    created_at: datetime
    
    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"

class TokenData(BaseModel):
    email: Optional[str] = None
    user_id: Optional[int] = None

# Department Schemas
class DepartmentBase(BaseModel):
    name: str
    type: DepartmentTypeEnum

class DepartmentCreate(DepartmentBase):
    pass

class Department(DepartmentBase):
    id: int
    
    class Config:
        from_attributes = True

# Teacher Schemas
class TeacherBase(BaseModel):
    name: str
    department_id: int
    email: Optional[EmailStr] = None
    phone: Optional[str] = None

class TeacherCreate(TeacherBase):
    pass

class Teacher(TeacherBase):
    id: int
    
    class Config:
        from_attributes = True

# Class Schemas
class ClassBase(BaseModel):
    name: str
    number_of_divisions: int
    department_id: int

class ClassCreate(ClassBase):
    pass

class Class(ClassBase):
    id: int
    
    class Config:
        from_attributes = True

# Division Schemas
class DivisionBase(BaseModel):
    name: str
    class_id: int

class DivisionCreate(DivisionBase):
    pass

class Division(DivisionBase):
    id: int
    
    class Config:
        from_attributes = True

# Batch Schemas
class BatchBase(BaseModel):
    number: int
    division_id: int

class BatchCreate(BatchBase):
    pass

class Batch(BatchBase):
    id: int
    
    class Config:
        from_attributes = True

# Subject Schemas
class SubjectBase(BaseModel):
    name: str
    type: SubjectTypeEnum
    hours_per_week: int
    class_id: int
    can_be_twice_in_day: bool = False

class SubjectCreate(SubjectBase):
    pass

class Subject(SubjectBase):
    id: int
    
    class Config:
        from_attributes = True

# Room Schemas
class RoomBase(BaseModel):
    room_number: str
    type: RoomTypeEnum
    capacity: Optional[int] = None
    floor: Optional[int] = None
    department_id: int

class RoomCreate(RoomBase):
    pass

class Room(RoomBase):
    id: int
    
    class Config:
        from_attributes = True

# SubjectTeacher Schemas
class SubjectTeacherBase(BaseModel):
    subject_id: int
    teacher_id: int
    division_id: Optional[int] = None
    batch_id: Optional[int] = None

class SubjectTeacherCreate(SubjectTeacherBase):
    pass

class SubjectTeacher(SubjectTeacherBase):
    id: int
    
    class Config:
        from_attributes = True

# Timetable Schemas
class TimetableBase(BaseModel):
    name: str
    class_id: int

class TimetableCreate(TimetableBase):
    pass

class TimetableUpdate(BaseModel):
    name: Optional[str] = None
    class_id: Optional[int] = None
    is_published: Optional[bool] = None

class Timetable(TimetableBase):
    id: int
    is_published: bool
    created_at: datetime
    created_by_user_id: int
    
    class Config:
        from_attributes = True

# ScheduleEntry Schemas
class ScheduleEntryBase(BaseModel):
    timetable_id: int
    day_index: int
    period_index: int
    subject_id: int
    teacher_id: int
    room_id: int
    division_id: Optional[int] = None
    batch_id: Optional[int] = None

class ScheduleEntryCreate(ScheduleEntryBase):
    pass

class ScheduleEntry(ScheduleEntryBase):
    id: int
    
    class Config:
        from_attributes = True

# TimetableSlots Schemas
class TimetableSlotsBase(BaseModel):
    department_id: int
    class_id: Optional[int] = None
    day_index: int
    period_index: int
    start_time: str
    end_time: str
    is_break: bool = False
    break_type: Optional[str] = None
    is_active: bool = True

class TimetableSlotsCreate(TimetableSlotsBase):
    pass

class TimetableSlotsConfig(TimetableSlotsBase):
    id: int
    
    class Config:
        from_attributes = True

# Timetable Generation Schemas
class SubjectAssignment(BaseModel):
    subject_id: int
    teacher_id: int
    subject_type: str
    subject_name: str
    hours_per_week: int

class TimetableGenerationRequest(BaseModel):
    name: str
    class_id: Optional[int] = None
    department_id: Optional[int] = None
    mode: str  # 'school' or 'college'
    subject_assignments: Optional[List[SubjectAssignment]] = []
    options: Dict[str, Any] = {}

class ConflictDiagnostic(BaseModel):
    type: str
    message: str
    subject_id: Optional[int] = None
    teacher_id: Optional[int] = None
    room_id: Optional[int] = None
    division_id: Optional[int] = None
    day_index: Optional[int] = None
    period_index: Optional[int] = None
    suggestions: List[str] = []

class TimetableGenerationResult(BaseModel):
    timetable_id: Optional[int] = None
    success: bool
    message: str
    diagnostics: List[ConflictDiagnostic] = []
    generation_stats: Dict[str, Any] = {}

# Validation Schemas
class ValidationResult(BaseModel):
    is_valid: bool
    warnings: List[str] = []
    errors: List[str] = []
    suggestions: List[str] = []
