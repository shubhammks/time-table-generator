# app/populate_db.py

from sqlalchemy.orm import Session
from app.models import Department, Teacher, Class, Division, Batch, Subject, Room, SubjectTeacher
from app.dependencies import get_db
from fastapi import FastAPI, Depends

app = FastAPI()

@app.on_event("startup")
def populate_db():
    db: Session = next(get_db())

    # Check if data already exists
    if db.query(Department).first():
        return  # Already populated

    # Departments
    cs_dept = Department(name="Computer Science", type="college")
    math_dept = Department(name="Mathematics", type="college")
    db.add_all([cs_dept, math_dept])
    db.commit()

    # Teachers
    t1 = Teacher(name="John Doe", department_id=cs_dept.id)
    t2 = Teacher(name="Jane Smith", department_id=cs_dept.id)
    t3 = Teacher(name="Alice Johnson", department_id=math_dept.id)
    db.add_all([t1, t2, t3])
    db.commit()

    # Classes
    c1 = Class(name="CS101", number_of_divisions=2, department_id=cs_dept.id)
    c2 = Class(name="MATH101", number_of_divisions=1, department_id=math_dept.id)
    db.add_all([c1, c2])
    db.commit()

    # Divisions
    d1 = Division(name="A", class_id=c1.id)
    d2 = Division(name="B", class_id=c1.id)
    d3 = Division(name="A", class_id=c2.id)
    db.add_all([d1, d2, d3])
    db.commit()

    # Batches
    b1 = Batch(number=1, division_id=d1.id)
    b2 = Batch(number=2, division_id=d2.id)
    b3 = Batch(number=1, division_id=d3.id)
    db.add_all([b1, b2, b3])
    db.commit()

    # Subjects
    s1 = Subject(name="Data Structures", type="lecture", hours_per_week=4, class_id=c1.id)
    s2 = Subject(name="Algorithms Lab", type="lab", hours_per_week=2, class_id=c1.id)
    s3 = Subject(name="Calculus", type="lecture", hours_per_week=3, class_id=c2.id)
    db.add_all([s1, s2, s3])
    db.commit()

    # Rooms
    r1 = Room(room_number="101", type="classroom", capacity=40, floor=1, department_id=cs_dept.id)
    r2 = Room(room_number="102", type="lab", capacity=30, floor=1, department_id=cs_dept.id)
    r3 = Room(room_number="201", type="classroom", capacity=50, floor=2, department_id=math_dept.id)
    db.add_all([r1, r2, r3])
    db.commit()

    # Subject-Teacher mapping
    st1 = SubjectTeacher(subject_id=s1.id, teacher_id=t1.id, division_id=d1.id, batch_id=b1.id)
    st2 = SubjectTeacher(subject_id=s2.id, teacher_id=t2.id, division_id=d2.id, batch_id=b2.id)
    st3 = SubjectTeacher(subject_id=s3.id, teacher_id=t3.id, division_id=d3.id, batch_id=b3.id)
    db.add_all([st1, st2, st3])
    db.commit()

    print("Database populated successfully!")
