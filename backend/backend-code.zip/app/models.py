from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Enum, func
from sqlalchemy.orm import relationship
from app.database import Base
import enum
from datetime import datetime


# Enum types
class UserRole(enum.Enum):
    teacher = "teacher"
    admin = "admin"
    coordinator = "coordinator"

class DepartmentType(enum.Enum):
    school = "school"
    college = "college"

class SubjectType(enum.Enum):
    lecture = "lecture"
    lab = "lab"
    tutorial = "tutorial"

class RoomType(enum.Enum):
    classroom = "classroom"
    lab = "lab"
    tutorial = "tutorial"


# User model
class User(Base):
    __tablename__ = "USER"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    full_name = Column(String(255), nullable=True)
    password_hash = Column(String(255), nullable=False)
    role = Column(Enum(UserRole), nullable=False)
    created_at = Column(DateTime, nullable=False, default=func.now())
    
    # Relationships
    created_timetables = relationship("Timetable", back_populates="created_by_user")


# Department model
class Department(Base):
    __tablename__ = "DEPARTMENT"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    type = Column(Enum(DepartmentType), nullable=False)

    teachers = relationship("Teacher", back_populates="department")
    classes = relationship("Class", back_populates="department")
    rooms = relationship("Room", back_populates="department")


# Teacher model
class Teacher(Base):
    __tablename__ = "TEACHER"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, index=True)
    department_id = Column(Integer, ForeignKey("DEPARTMENT.id"), nullable=False)
    email = Column(String(255), unique=True, nullable=True)
    phone = Column(String(20), nullable=True)

    department = relationship("Department", back_populates="teachers")
    subject_teacher = relationship("SubjectTeacher", back_populates="teacher")
    schedule_entries = relationship("ScheduleEntry", back_populates="teacher")


# Class model
class Class(Base):
    __tablename__ = "CLASS"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(50), nullable=False)
    number_of_divisions = Column(Integer, nullable=False)
    department_id = Column(Integer, ForeignKey("DEPARTMENT.id"))

    department = relationship("Department", back_populates="classes")
    divisions = relationship("Division", back_populates="class_")
    subjects = relationship("Subject", back_populates="class_")
    timetables = relationship("Timetable", back_populates="class_")


# Division model
class Division(Base):
    __tablename__ = "DIVISION"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(50), nullable=False)
    class_id = Column(Integer, ForeignKey("CLASS.id"))

    class_ = relationship("Class", back_populates="divisions")
    batches = relationship("Batch", back_populates="division")
    subject_teacher = relationship("SubjectTeacher", back_populates="division")
    schedule_entries = relationship("ScheduleEntry", back_populates="division")


# Batch model
class Batch(Base):
    __tablename__ = "BATCH"

    id = Column(Integer, primary_key=True, index=True)
    number = Column(Integer, nullable=False)
    division_id = Column(Integer, ForeignKey("DIVISION.id"))

    division = relationship("Division", back_populates="batches")
    subject_teacher = relationship("SubjectTeacher", back_populates="batch")
    schedule_entries = relationship("ScheduleEntry", back_populates="batch")


# Subject model
class Subject(Base):
    __tablename__ = "SUBJECT"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, index=True)
    type = Column(Enum(SubjectType), nullable=False)
    hours_per_week = Column(Integer, nullable=False)
    class_id = Column(Integer, ForeignKey("CLASS.id"), nullable=False)
    can_be_twice_in_day = Column(Boolean, default=False, nullable=False)

    class_ = relationship("Class", back_populates="subjects")
    subject_teacher = relationship("SubjectTeacher", back_populates="subject")
    schedule_entries = relationship("ScheduleEntry", back_populates="subject")


# SubjectTeacher model
class SubjectTeacher(Base):
    __tablename__ = "SUBJECT_TEACHER"

    id = Column(Integer, primary_key=True, index=True)
    subject_id = Column(Integer, ForeignKey("SUBJECT.id"))
    teacher_id = Column(Integer, ForeignKey("TEACHER.id"))
    division_id = Column(Integer, ForeignKey("DIVISION.id"))
    batch_id = Column(Integer, ForeignKey("BATCH.id"))

    subject = relationship("Subject", back_populates="subject_teacher")
    teacher = relationship("Teacher", back_populates="subject_teacher")
    division = relationship("Division", back_populates="subject_teacher")
    batch = relationship("Batch", back_populates="subject_teacher")


# Room model
class Room(Base):
    __tablename__ = "ROOM"

    id = Column(Integer, primary_key=True, index=True)
    room_number = Column(String(50), nullable=False)
    type = Column(Enum(RoomType), nullable=False)
    capacity = Column(Integer)
    floor = Column(Integer)
    department_id = Column(Integer, ForeignKey("DEPARTMENT.id"))

    department = relationship("Department", back_populates="rooms")
    schedule_entries = relationship("ScheduleEntry", back_populates="room")


# Timetable model
class Timetable(Base):
    __tablename__ = "TIMETABLE"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    class_id = Column(Integer, ForeignKey("CLASS.id"), nullable=False)
    is_published = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime, nullable=False, default=func.now())
    created_by_user_id = Column(Integer, ForeignKey("USER.id"), nullable=False)

    class_ = relationship("Class", back_populates="timetables")
    schedule_entries = relationship("ScheduleEntry", back_populates="timetable")
    created_by_user = relationship("User", back_populates="created_timetables")


# ScheduleEntry model
class ScheduleEntry(Base):
    __tablename__ = "SCHEDULE_ENTRY"

    id = Column(Integer, primary_key=True, index=True)
    timetable_id = Column(Integer, ForeignKey("TIMETABLE.id"), nullable=False)
    day_index = Column(Integer, nullable=False)  # 0=Mon, 1=Tue, ..., 5=Sat
    period_index = Column(Integer, nullable=False)
    subject_id = Column(Integer, ForeignKey("SUBJECT.id"), nullable=False)
    teacher_id = Column(Integer, ForeignKey("TEACHER.id"), nullable=False)
    room_id = Column(Integer, ForeignKey("ROOM.id"), nullable=False)
    division_id = Column(Integer, ForeignKey("DIVISION.id"), nullable=True)
    batch_id = Column(Integer, ForeignKey("BATCH.id"), nullable=True)

    # Relationships
    timetable = relationship("Timetable", back_populates="schedule_entries")
    subject = relationship("Subject", back_populates="schedule_entries")
    teacher = relationship("Teacher", back_populates="schedule_entries")
    room = relationship("Room", back_populates="schedule_entries")
    division = relationship("Division", back_populates="schedule_entries")
    batch = relationship("Batch", back_populates="schedule_entries")


# TimetableSlots configuration model
class TimetableSlots(Base):
    __tablename__ = "TIMETABLE_SLOTS"

    id = Column(Integer, primary_key=True, index=True)
    department_id = Column(Integer, ForeignKey("DEPARTMENT.id"), nullable=False)
    class_id = Column(Integer, ForeignKey("CLASS.id"), nullable=True)  # For class-specific configs
    day_index = Column(Integer, nullable=False)  # 0=Mon, 1=Tue, ..., 5=Sat
    period_index = Column(Integer, nullable=False)
    start_time = Column(String(10), nullable=False)  # Format: "HH:MM"
    end_time = Column(String(10), nullable=False)    # Format: "HH:MM"
    is_break = Column(Boolean, default=False, nullable=False)
    break_type = Column(String(20), nullable=True)   # 'short_break', 'lunch_break', etc.
    is_active = Column(Boolean, default=True, nullable=False)

    # Relationships
    department = relationship("Department")
    class_ = relationship("Class", foreign_keys=[class_id])
