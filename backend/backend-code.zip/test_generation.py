#!/usr/bin/env python3
"""
Test script for timetable generation debugging.
This script tests the complete timetable generation flow.
"""

import sys
import logging
from pathlib import Path
from datetime import datetime

# Add the project root to the Python path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from sqlalchemy.orm import Session
from app.database import SessionLocal, engine
from app import models
from app.services.generator import TimetableGenerator, GenerationRequest, TimetableValidator

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def create_test_data(db: Session):
    """Create minimal test data for timetable generation."""
    
    # Clean up existing test data first
    logger.info("Cleaning up existing test data...")
    db.query(models.SubjectTeacher).delete()
    db.query(models.ScheduleEntry).delete() 
    db.query(models.Timetable).delete()
    db.query(models.TimetableSlots).delete()
    db.query(models.Room).delete()
    db.query(models.Subject).delete()
    db.query(models.Division).delete()
    db.query(models.Teacher).delete()
    db.query(models.Class).delete() 
    db.query(models.User).delete()
    db.query(models.Department).delete()
    db.commit()
    
    logger.info("Creating test data...")
    
    # Create department
    department = models.Department(
        name="Computer Science",
        type=models.DepartmentType.school
    )
    db.add(department)
    db.flush()
    
    # Create class
    class_obj = models.Class(
        name="TY CSE",
        number_of_divisions=2,
        department_id=department.id
    )
    db.add(class_obj)
    db.flush()
    
    # Create divisions
    division_a = models.Division(name="A", class_id=class_obj.id)
    division_b = models.Division(name="B", class_id=class_obj.id)
    db.add_all([division_a, division_b])
    db.flush()
    
    # Create teachers
    teachers = [
        models.Teacher(name="Dr. Smith", department_id=department.id, email="smith@test.com"),
        models.Teacher(name="Prof. Johnson", department_id=department.id, email="johnson@test.com"),
        models.Teacher(name="Dr. Williams", department_id=department.id, email="williams@test.com"),
        models.Teacher(name="Prof. Brown", department_id=department.id, email="brown@test.com"),
    ]
    db.add_all(teachers)
    db.flush()
    
    # Create subjects
    subjects = [
        models.Subject(name="Data Structures", type=models.SubjectType.lecture, hours_per_week=4, class_id=class_obj.id),
        models.Subject(name="Database Systems", type=models.SubjectType.lecture, hours_per_week=3, class_id=class_obj.id),
        models.Subject(name="Programming Lab", type=models.SubjectType.lab, hours_per_week=2, class_id=class_obj.id),
        models.Subject(name="Mathematics", type=models.SubjectType.lecture, hours_per_week=4, class_id=class_obj.id),
        models.Subject(name="Physics", type=models.SubjectType.lecture, hours_per_week=3, class_id=class_obj.id),
    ]
    db.add_all(subjects)
    db.flush()
    
    # Create rooms
    rooms = [
        models.Room(room_number="A101", type=models.RoomType.classroom, capacity=60, department_id=department.id),
        models.Room(room_number="A102", type=models.RoomType.classroom, capacity=60, department_id=department.id),
        models.Room(room_number="LAB1", type=models.RoomType.lab, capacity=30, department_id=department.id),
        models.Room(room_number="LAB2", type=models.RoomType.lab, capacity=30, department_id=department.id),
    ]
    db.add_all(rooms)
    db.flush()
    
    # Create subject-teacher assignments
    assignments = [
        # Data Structures - Dr. Smith
        models.SubjectTeacher(subject_id=subjects[0].id, teacher_id=teachers[0].id, division_id=division_a.id),
        models.SubjectTeacher(subject_id=subjects[0].id, teacher_id=teachers[0].id, division_id=division_b.id),
        
        # Database Systems - Prof. Johnson  
        models.SubjectTeacher(subject_id=subjects[1].id, teacher_id=teachers[1].id, division_id=division_a.id),
        models.SubjectTeacher(subject_id=subjects[1].id, teacher_id=teachers[1].id, division_id=division_b.id),
        
        # Programming Lab - Dr. Williams
        models.SubjectTeacher(subject_id=subjects[2].id, teacher_id=teachers[2].id, division_id=division_a.id),
        models.SubjectTeacher(subject_id=subjects[2].id, teacher_id=teachers[2].id, division_id=division_b.id),
        
        # Mathematics - Prof. Brown
        models.SubjectTeacher(subject_id=subjects[3].id, teacher_id=teachers[3].id, division_id=division_a.id),
        models.SubjectTeacher(subject_id=subjects[3].id, teacher_id=teachers[3].id, division_id=division_b.id),
        
        # Physics - Dr. Smith (teaching multiple subjects)
        models.SubjectTeacher(subject_id=subjects[4].id, teacher_id=teachers[0].id, division_id=division_a.id),
        models.SubjectTeacher(subject_id=subjects[4].id, teacher_id=teachers[0].id, division_id=division_b.id),
    ]
    db.add_all(assignments)
    
    # Create a test user
    user = models.User(
        email="admin@test.com",
        full_name="Test Admin",
        password_hash="dummy_hash",
        role=models.UserRole.admin
    )
    db.add(user)
    
    db.commit()
    logger.info("Test data created successfully!")
    
    return {
        'department': department,
        'class': class_obj,
        'divisions': [division_a, division_b],
        'teachers': teachers,
        'subjects': subjects,
        'rooms': rooms,
        'user': user
    }

def test_validation(db: Session, class_id: int, department_id: int):
    """Test the pre-generation validation."""
    logger.info("Testing validation...")
    
    validator = TimetableValidator(db)
    result = validator.validate_pre_generation(class_id, department_id, "school")
    
    logger.info(f"Validation result: {result.is_valid}")
    if result.errors:
        logger.error(f"Validation errors: {result.errors}")
    if result.warnings:
        logger.warning(f"Validation warnings: {result.warnings}")
    if result.suggestions:
        logger.info(f"Suggestions: {result.suggestions}")
    
    return result

def test_generation(db: Session, class_id: int, department_id: int, user_id: int):
    """Test the complete timetable generation process."""
    logger.info("Testing timetable generation...")
    
    generator = TimetableGenerator(db)
    
    request = GenerationRequest(
        name=f"Test Timetable {datetime.now().strftime('%Y%m%d_%H%M%S')}",
        class_id=class_id,
        department_id=department_id,
        mode="school",
        user_id=user_id,
        options={
            "optimize_for": "balanced",
            "allow_conflicts": False
        }
    )
    
    logger.info(f"Generating timetable with request: {request}")
    
    result = generator.generate_timetable(request)
    
    logger.info(f"Generation result: Success={result.success}")
    logger.info(f"Message: {result.message}")
    logger.info(f"Timetable ID: {result.timetable_id}")
    
    if result.csp_stats:
        logger.info(f"CSP Stats: {result.csp_stats}")
    
    if result.optimization_stats:
        logger.info(f"Optimization Stats: {result.optimization_stats}")
    
    if result.diagnostics:
        logger.warning(f"Diagnostics: {len(result.diagnostics)} issues found")
        for diag in result.diagnostics[:5]:  # Show first 5 diagnostics
            logger.warning(f"  - {diag.type}: {diag.message}")
    
    logger.info(f"Total time: {result.total_time:.2f}s")
    
    return result

def view_generated_timetable(db: Session, timetable_id: int):
    """View the generated timetable structure."""
    logger.info(f"Viewing generated timetable {timetable_id}...")
    
    timetable = db.query(models.Timetable).filter(models.Timetable.id == timetable_id).first()
    if not timetable:
        logger.error("Timetable not found!")
        return
    
    entries = db.query(models.ScheduleEntry).filter(
        models.ScheduleEntry.timetable_id == timetable_id
    ).all()
    
    logger.info(f"Timetable '{timetable.name}' has {len(entries)} schedule entries:")
    
    days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
    
    for day_idx in range(6):
        day_entries = [e for e in entries if e.day_index == day_idx]
        if day_entries:
            logger.info(f"\n{days[day_idx]}:")
            day_entries.sort(key=lambda x: x.period_index)
            
            for entry in day_entries:
                subject = db.query(models.Subject).filter(models.Subject.id == entry.subject_id).first()
                teacher = db.query(models.Teacher).filter(models.Teacher.id == entry.teacher_id).first()
                room = db.query(models.Room).filter(models.Room.id == entry.room_id).first()
                division = db.query(models.Division).filter(models.Division.id == entry.division_id).first()
                
                logger.info(f"  Period {entry.period_index}: {subject.name if subject else 'Unknown'} - "
                          f"{teacher.name if teacher else 'Unknown'} - "
                          f"Room {room.room_number if room else 'Unknown'} - "
                          f"Div {division.name if division else 'Unknown'}")

def main():
    """Main test function."""
    logger.info("Starting timetable generation test...")
    
    # Create database session
    db = SessionLocal()
    
    try:
        # Create or verify test data
        test_data = create_test_data(db)
        
        # Get IDs for testing
        department = db.query(models.Department).first()
        class_obj = db.query(models.Class).first()
        user = db.query(models.User).first()
        
        if not all([department, class_obj, user]):
            logger.error("Required test data not found!")
            return
        
        logger.info(f"Using Department ID: {department.id}, Class ID: {class_obj.id}, User ID: {user.id}")
        
        # Test validation
        validation_result = test_validation(db, class_obj.id, department.id)
        
        if not validation_result.is_valid:
            logger.error("Validation failed, cannot proceed with generation")
            return
        
        # Test generation
        generation_result = test_generation(db, class_obj.id, department.id, user.id)
        
        if generation_result.success and generation_result.timetable_id:
            logger.info("✅ Timetable generation successful!")
            view_generated_timetable(db, generation_result.timetable_id)
        else:
            logger.error("❌ Timetable generation failed!")
            
    except Exception as e:
        logger.error(f"Test failed with exception: {str(e)}", exc_info=True)
    finally:
        db.close()

if __name__ == "__main__":
    main()
