#!/usr/bin/env python3
"""
Simple test for CSP solver only.
"""
import sys
import logging
from pathlib import Path
from datetime import datetime

# Add the project root to the Python path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from sqlalchemy.orm import Session
from app.database import SessionLocal, engine
from app import models

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def test_csp_only():
    """Test CSP solver in isolation."""
    logger.info("Testing CSP solver only...")
    
    # Create database session
    db = SessionLocal()
    
    try:
        from app.services.csp_solver import CSPSolver
        
        # Create CSP solver with short timeout
        solver = CSPSolver(db, mode='school')
        solver.timeout_seconds = 5  # Very short timeout
        
        # Test with existing data
        result = solver.solve(class_id=1, department_id=1)
        
        logger.info(f"CSP Solver finished:")
        logger.info(f"  Complete: {result.is_complete}")
        logger.info(f"  Assignments: {len(result.assignments)}")
        logger.info(f"  Conflicts: {len(result.conflicts)}")
        logger.info(f"  Stats: {result.stats}")
        
        if result.assignments:
            logger.info("First few assignments:")
            for i, assignment in enumerate(result.assignments[:5]):
                logger.info(f"  Assignment {i+1}: {assignment.variable.subject_name} -> {assignment.domain}")
        
    except Exception as e:
        logger.error(f"CSP test failed: {e}", exc_info=True)
    finally:
        db.close()

if __name__ == "__main__":
    test_csp_only()
