# Timetable Management System - Backend

A comprehensive FastAPI-based backend for automated timetable generation and management system for schools and colleges.

## Features

- **RESTful API** with FastAPI
- **JWT Authentication** with refresh tokens
- **Database ORM** with SQLAlchemy
- **Automated Timetable Generation** using CSP (Constraint Satisfaction Problem) solver
- **PDF Export** capabilities
- **CRUD operations** for all entities
- **Testing suite** with pytest
- **Docker support**

## Project Structure

```
backend/
├── app/
│   ├── routes/          # API route definitions
│   ├── services/        # Business logic and algorithms
│   ├── main.py         # FastAPI application instance
│   ├── config.py       # Configuration settings
│   ├── database.py     # Database connection
│   ├── models.py       # SQLAlchemy ORM models
│   ├── schemas.py      # Pydantic schemas
│   └── dependencies.py # Dependency injection
├── tests/              # Test files
├── sql/                # Database schema
├── requirements.txt    # Python dependencies
├── Dockerfile         # Docker configuration
├── .env               # Environment variables
└── run.py             # Application startup script
```

## Quick Start

### Prerequisites

- Python 3.11+
- MySQL/MariaDB database
- pip or conda package manager

### Installation

1. **Clone and navigate to backend directory**
   ```bash
   cd backend
   ```

2. **Create virtual environment**
   ```bash
   python -m venv venv
   
   # On Windows
   venv\Scripts\activate
   
   # On macOS/Linux
   source venv/bin/activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Configure environment variables**
   - Copy `.env` file and modify database settings as needed
   - Update `DATABASE_URL` to match your MySQL configuration

5. **Run the application**
   ```bash
   # Option 1: Using the startup script
   python run.py
   
   # Option 2: Using uvicorn directly
   uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
   ```

6. **Access the API**
   - API Documentation: http://localhost:8000/docs
   - Alternative docs: http://localhost:8000/redoc
   - Health check: http://localhost:8000/health

## API Endpoints

### Authentication
- `POST /api/v1/auth/login` - User login
- `POST /api/v1/auth/register` - User registration
- `POST /api/v1/auth/refresh` - Refresh JWT token

### CRUD Operations
- `GET/POST /api/v1/departments` - Department management
- `GET/POST /api/v1/teachers` - Teacher management
- `GET/POST /api/v1/subjects` - Subject management
- `GET/POST /api/v1/classes` - Class management
- `GET/POST /api/v1/rooms` - Room management
- `GET/POST /api/v1/batches` - Batch management

### Timetable Generation
- `POST /api/v1/timetable/generate` - Generate new timetable
- `GET /api/v1/timetable/{id}` - Get timetable details
- `GET /api/v1/timetable/{id}/pdf` - Export timetable as PDF

## Configuration

Key environment variables in `.env`:

```env
# Database
DATABASE_URL=mysql+pymysql://user:password@localhost:3306/timetable_db

# JWT Security
JWT_SECRET_KEY=your-secret-key
JWT_ACCESS_TOKEN_EXPIRE_MINUTES=30

# CORS (for frontend integration)
CORS_ORIGINS=http://localhost:3000,http://localhost:5173

# Solver Configuration
CSP_MAX_ITERATIONS=1000
CSP_TIME_LIMIT_SECONDS=300
```

## Development

### Running Tests
```bash
pytest tests/ -v
```

### Code Formatting
```bash
black app/ tests/
flake8 app/ tests/
```

### Database Migration
The application automatically creates tables on startup. For production, consider using Alembic for migrations.

## Docker Deployment

```bash
# Build image
docker build -t timetable-backend .

# Run container
docker run -p 8000:8000 --env-file .env timetable-backend
```

## Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Verify MySQL is running
   - Check DATABASE_URL in .env file
   - Ensure database exists

2. **Import Errors**
   - Make sure virtual environment is activated
   - Verify all dependencies are installed

3. **Port Already in Use**
   - Change port in run.py or uvicorn command
   - Kill existing processes on port 8000

## Entity Relationships

The system manages the following entities:

- **Users**: Admin and regular users
- **Departments**: Academic departments
- **Teachers**: Faculty members with availability
- **Subjects**: Course subjects
- **Classes**: Student classes/groups  
- **Rooms**: Physical classrooms and labs
- **Batches**: Academic batches/years
- **Timetables**: Generated schedules
- **Schedule Entries**: Individual time slots

## Algorithm Details

The timetable generation uses a Constraint Satisfaction Problem (CSP) approach with:

- **Hard Constraints**: No conflicts, teacher availability, room capacity
- **Soft Constraints**: Preferences, balanced distribution
- **Optimization**: Minimize gaps, balance workload
- **Backtracking**: Find valid solutions efficiently

## Contributing

1. Create feature branch
2. Make changes with tests  
3. Run test suite
4. Submit pull request
