#!/usr/bin/env python3
"""
Create sample data specifically for testing concurrent batch scheduling
Class A with 3 batches (A1, A2, A3) having different labs at same time
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from sqlalchemy.orm import Session
from app.database import SessionLocal, engine
from app import models
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_concurrent_sample_data():
    """Create sample data for concurrent batch scheduling test"""
    db = SessionLocal()
    
    try:
        logger.info("Creating concurrent batch scheduling sample data...")
        
        # 1. Create coordinator user (skip if exists)
        existing_user = db.query(models.User).filter(models.User.email == "coordinator@example.com").first()
        if not existing_user:
            coordinator = models.User(
                email="coordinator@example.com",
                password_hash="coord123",  # Simple password for demo
                role=models.UserRole.coordinator
            )
            db.add(coordinator)
            db.flush()
            logger.info("Created coordinator user")
        else:
            logger.info("Coordinator user already exists")
        
        # 2. Create department
        dept = models.Department(
            name="Computer Science & Engineering",
            type=models.DepartmentType.college
        )
        db.add(dept)
        db.flush()
        logger.info(f"Created department: {dept.name}")
        
        # 3. Create teachers
        teachers_data = [
            {"name": "Dr. Alice Sharma", "email": "alice@example.com", "phone": "9876543210"},
            {"name": "Prof. Bob Singh", "email": "bob@example.com", "phone": "9876543211"},
            {"name": "Dr. Carol Gupta", "email": "carol@example.com", "phone": "9876543212"},
            {"name": "Prof. David Kumar", "email": "david@example.com", "phone": "9876543213"},
            {"name": "Dr. Emma Patel", "email": "emma@example.com", "phone": "9876543214"},
            {"name": "Prof. Frank Verma", "email": "frank@example.com", "phone": "9876543215"},
        ]
        
        teachers = []
        for teacher_data in teachers_data:
            # Check if teacher already exists
            existing_teacher = db.query(models.Teacher).filter(
                models.Teacher.email == teacher_data["email"]
            ).first()
            
            if not existing_teacher:
                teacher = models.Teacher(
                    name=teacher_data["name"],
                    department_id=dept.id,
                    email=teacher_data["email"],
                    phone=teacher_data["phone"]
                )
                db.add(teacher)
                db.flush()
                teachers.append(teacher)
                logger.info(f"Created teacher: {teacher.name}")
            else:
                teachers.append(existing_teacher)
                logger.info(f"Teacher already exists: {existing_teacher.name}")
        
        # 4. Create class
        class_obj = models.Class(
            name="Third Year (TY)",
            department_id=dept.id,
            number_of_divisions=1
        )
        db.add(class_obj)
        db.flush()
        logger.info(f"Created class: {class_obj.name}")
        
        # 5. Create division
        division = models.Division(
            name="A",
            class_id=class_obj.id
        )
        db.add(division)
        db.flush()
        logger.info(f"Created division: {division.name}")
        
        # 6. Create 3 batches for division A
        batches_data = [
            {"number": 1},
            {"number": 2},
            {"number": 3},
        ]
        
        batches = []
        for batch_data in batches_data:
            # Check if batch already exists
            existing_batch = db.query(models.Batch).filter(
                models.Batch.division_id == division.id,
                models.Batch.number == batch_data["number"]
            ).first()
            
            if not existing_batch:
                batch = models.Batch(
                    number=batch_data["number"],
                    division_id=division.id
                )
                db.add(batch)
                db.flush()
                batches.append(batch)
                logger.info(f"Created batch: A{batch.number}")
            else:
                batches.append(existing_batch)
                logger.info(f"Batch already exists: A{existing_batch.number}")
        
        # 7. Create subjects with lecture + lab combinations
        subjects_data = [
            # CAD (Computer Aided Design)
            {"name": "CAD", "type": "lecture", "hours_per_week": 2},
            {"name": "CAD Lab", "type": "lab", "hours_per_week": 2},
            
            # ML (Machine Learning)
            {"name": "ML", "type": "lecture", "hours_per_week": 2},
            {"name": "ML Lab", "type": "lab", "hours_per_week": 2},
            
            # DAA (Design and Analysis of Algorithms)
            {"name": "DAA", "type": "lecture", "hours_per_week": 2},
            {"name": "DAA Lab", "type": "lab", "hours_per_week": 2},
            
            # Software Engineering
            {"name": "Software Engineering", "type": "lecture", "hours_per_week": 2},
            {"name": "Software Engineering Lab", "type": "lab", "hours_per_week": 2},
            
            # Database Systems
            {"name": "Database Systems", "type": "lecture", "hours_per_week": 2},
            {"name": "Database Systems Lab", "type": "lab", "hours_per_week": 2},
            
            # Tutorial subjects
            {"name": "Programming Tutorial", "type": "tutorial", "hours_per_week": 1},
            {"name": "Math Tutorial", "type": "tutorial", "hours_per_week": 1},
        ]
        
        subjects = []
        for subject_data in subjects_data:
            # Check if subject already exists
            existing_subject = db.query(models.Subject).filter(
                models.Subject.name == subject_data["name"],
                models.Subject.class_id == class_obj.id
            ).first()
            
            if not existing_subject:
                subject = models.Subject(
                    name=subject_data["name"],
                    type=models.SubjectType(subject_data["type"]),
                    class_id=class_obj.id,
                    hours_per_week=subject_data["hours_per_week"]
                )
                db.add(subject)
                db.flush()
                subjects.append(subject)
                logger.info(f"Created subject: {subject.name} ({subject.type.value})")
            else:
                subjects.append(existing_subject)
                logger.info(f"Subject already exists: {existing_subject.name}")
        
        # 8. Create rooms
        rooms_data = [
            # Classrooms
            {"room_number": "D301", "type": "classroom", "capacity": 60},
            {"room_number": "D302", "type": "classroom", "capacity": 60},
            {"room_number": "D303", "type": "classroom", "capacity": 60},
            
            # Labs
            {"room_number": "D307", "type": "lab", "capacity": 30},
            {"room_number": "D306", "type": "lab", "capacity": 30},
            {"room_number": "D311", "type": "lab", "capacity": 30},
            {"room_number": "D308", "type": "lab", "capacity": 30},
            {"room_number": "D309", "type": "lab", "capacity": 30},
            
            # Tutorial rooms
            {"room_number": "D304", "type": "tutorial", "capacity": 20},
            {"room_number": "D305", "type": "tutorial", "capacity": 20},
        ]
        
        rooms = []
        for room_data in rooms_data:
            # Check if room already exists
            existing_room = db.query(models.Room).filter(
                models.Room.room_number == room_data["room_number"],
                models.Room.department_id == dept.id
            ).first()
            
            if not existing_room:
                room = models.Room(
                    room_number=room_data["room_number"],
                    type=models.RoomType(room_data["type"]),
                    department_id=dept.id,
                    capacity=room_data["capacity"]
                )
                db.add(room)
                db.flush()
                rooms.append(room)
                logger.info(f"Created room: {room.room_number} ({room.type.value})")
            else:
                rooms.append(existing_room)
                logger.info(f"Room already exists: {existing_room.room_number}")
        
        # 9. Assign teachers to subjects for each division
        subject_teacher_assignments = [
            # CAD assignments
            {"subject": "CAD", "teacher": "Dr. Alice Sharma"},
            {"subject": "CAD Lab", "teacher": "Dr. Alice Sharma"},
            
            # ML assignments
            {"subject": "ML", "teacher": "Prof. Bob Singh"},
            {"subject": "ML Lab", "teacher": "Prof. Bob Singh"},
            
            # DAA assignments
            {"subject": "DAA", "teacher": "Dr. Carol Gupta"},
            {"subject": "DAA Lab", "teacher": "Dr. Carol Gupta"},
            
            # Software Engineering assignments
            {"subject": "Software Engineering", "teacher": "Prof. David Kumar"},
            {"subject": "Software Engineering Lab", "teacher": "Prof. David Kumar"},
            
            # Database Systems assignments
            {"subject": "Database Systems", "teacher": "Dr. Emma Patel"},
            {"subject": "Database Systems Lab", "teacher": "Dr. Emma Patel"},
            
            # Tutorial assignments
            {"subject": "Programming Tutorial", "teacher": "Prof. Frank Verma"},
            {"subject": "Math Tutorial", "teacher": "Dr. Alice Sharma"},
        ]
        
        for assignment in subject_teacher_assignments:
            # Find subject and teacher
            subject = next((s for s in subjects if s.name == assignment["subject"]), None)
            teacher = next((t for t in teachers if t.name == assignment["teacher"]), None)
            
            if subject and teacher:
                # Check if assignment already exists
                existing_assignment = db.query(models.SubjectTeacher).filter(
                    models.SubjectTeacher.subject_id == subject.id,
                    models.SubjectTeacher.teacher_id == teacher.id,
                    models.SubjectTeacher.division_id == division.id
                ).first()
                
                if not existing_assignment:
                    subject_teacher = models.SubjectTeacher(
                        subject_id=subject.id,
                        teacher_id=teacher.id,
                        division_id=division.id
                    )
                    db.add(subject_teacher)
                    logger.info(f"Assigned {teacher.name} to {subject.name} for division {division.name}")
        
        # 10. Create timetable slots
        days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
        periods = [
            {'start_time': '09:00', 'end_time': '09:50', 'period_index': 0},
            {'start_time': '10:00', 'end_time': '10:50', 'period_index': 1},
            {'start_time': '11:00', 'end_time': '11:50', 'period_index': 2},
            {'start_time': '12:00', 'end_time': '12:50', 'period_index': 3},
            {'start_time': '13:00', 'end_time': '13:50', 'period_index': 4},
            {'start_time': '14:00', 'end_time': '14:50', 'period_index': 5},
            {'start_time': '15:00', 'end_time': '15:50', 'period_index': 6},
            {'start_time': '16:00', 'end_time': '16:50', 'period_index': 7},
        ]
        
        for day_idx, day in enumerate(days):
            for period in periods:
                # Check if slot already exists
                existing_slot = db.query(models.TimetableSlots).filter(
                    models.TimetableSlots.day_index == day_idx,
                    models.TimetableSlots.period_index == period['period_index'],
                    models.TimetableSlots.department_id == dept.id
                ).first()
                
                if not existing_slot:
                    slot = models.TimetableSlots(
                        day_index=day_idx,
                        period_index=period['period_index'],
                        start_time=period['start_time'],
                        end_time=period['end_time'],
                        department_id=dept.id,
                        class_id=class_obj.id
                    )
                    db.add(slot)
        
        db.commit()
        logger.info("✅ Concurrent batch scheduling sample data created successfully!")
        logger.info(f"Created: {len(teachers)} teachers, {len(subjects)} subjects, {len(batches)} batches, {len(rooms)} rooms")
        logger.info("Ready for testing concurrent batch scheduling!")
        
    except Exception as e:
        logger.error(f"Error creating sample data: {str(e)}")
        db.rollback()
        raise
    finally:
        db.close()

if __name__ == "__main__":
    create_concurrent_sample_data()
