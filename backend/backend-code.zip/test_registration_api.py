#!/usr/bin/env python3
"""
Test the registration API endpoint
"""

import requests
import json
import sys

def start_server():
    """Start the FastAPI server in a separate thread"""
    import threading
    import time
    from app.main import app
    import uvicorn
    
    def run_server():
        uvicorn.run(app, host="127.0.0.1", port=8000, log_level="error")
    
    server_thread = threading.Thread(target=run_server, daemon=True)
    server_thread.start()
    
    # Wait for server to start and test connection
    for i in range(10):
        try:
            import requests
            response = requests.get("http://localhost:8000/health", timeout=1)
            if response.status_code == 200:
                print("✅ Server started successfully")
                return True
        except:
            pass
        time.sleep(1)
        print(f"⏳ Waiting for server to start... ({i+1}/10)")
    
    print("❌ Server failed to start")
    return False

def test_registration_api():
    """Test the user registration API"""
    import time
    
    # Test registration endpoint
    url = "http://localhost:8000/api/v1/auth/register"
    
    test_user = {
        "email": "newuser@example.com",
        "password": "password123",
        "confirmPassword": "password123",
        "full_name": "New Test User",
        "role": "teacher"
    }
    
    print("🧪 Testing registration API...")
    print(f"URL: {url}")
    print(f"Payload: {json.dumps(test_user, indent=2)}")
    
    try:
        response = requests.post(url, json=test_user, timeout=10)
        
        print(f"\n📊 Response Status: {response.status_code}")
        print(f"📄 Response Headers: {dict(response.headers)}")
        
        if response.headers.get('content-type', '').startswith('application/json'):
            response_data = response.json()
            print(f"📝 Response Body: {json.dumps(response_data, indent=2)}")
        else:
            print(f"📝 Response Body: {response.text}")
        
        if response.status_code == 201:
            print("✅ Registration successful!")
            return True
        else:
            print(f"❌ Registration failed with status {response.status_code}")
            return False
            
    except requests.exceptions.ConnectionError:
        print("❌ Could not connect to server. Make sure FastAPI is running on port 8000")
        return False
    except requests.exceptions.Timeout:
        print("❌ Request timed out")
        return False
    except Exception as e:
        print(f"❌ Error during request: {e}")
        return False

def test_health_endpoint():
    """Test the health endpoint"""
    url = "http://localhost:8000/health"
    
    print("🧪 Testing health endpoint...")
    
    try:
        response = requests.get(url, timeout=5)
        print(f"📊 Health Status: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            print(f"📄 Health Response: {json.dumps(data, indent=2)}")
            print("✅ Health check passed!")
            return True
        else:
            print(f"❌ Health check failed: {response.status_code}")
            return False
            
    except Exception as e:
        print(f"❌ Health check error: {e}")
        return False

if __name__ == "__main__":
    print("FastAPI Registration API Test")
    print("=" * 40)
    
    # Start server first
    print("🚀 Starting FastAPI server...")
    if not start_server():
        print("❌ Could not start server")
        sys.exit(1)
    
    print("\n" + "=" * 40)
    
    # Test health
    if not test_health_endpoint():
        print("❌ Health check failed")
        sys.exit(1)
    
    print("\n" + "=" * 40)
    
    # Test registration
    success = test_registration_api()
    
    if success:
        print("\n🎉 All API tests passed!")
    else:
        print("\n❌ Some tests failed")
        sys.exit(1)
